
public class Exercise_1_6 {

	public static void main(String[] args) {
		
		// Simple solution.
		System.out.println(1+2+3+4+5+6+7+8+9);

		// Better solution
		//System.out.print("The sum of the first nine positive integers is " + 1+2+3+4+5+6+7+8+9);

	}

}

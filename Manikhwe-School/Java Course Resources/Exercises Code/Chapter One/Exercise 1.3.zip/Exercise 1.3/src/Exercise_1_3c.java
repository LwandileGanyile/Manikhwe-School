
public class Exercise_1_3c {

	public static void main(String[] args) {
		
		/* To Find the reflection about the y-axis(Left & Right), is not as easy
		as finding the reflection about the x-axis(Up & Down). To find the reflection
		about the y-axis(Left & Right) you do it line by line using a grid.*/
		System.out.println("\n    J     A     V     V     A        A     V     V     A     J");
		System.out.println("    J    A A     V   V     A A      A A     V   V     A A    J");
		System.out.println("J   J   AAAAA     V V     AAAAA    AAAAA     V V     AAAAA   J   J");
		System.out.println(" J J   A     A     V     A     A  A     A     V     A     A   J J");
		
		/* The pattern is on a grid so, it better to start by drawing a grid.
		 Once a grid is drawn, we start to count spaces between letters.
	     Here we deal with a pattern line by line. Meaning we only count 
		horizontal spaces. The symmetry is only applied on the bigger letter made
		by small letters.
		*/
		
	}

}

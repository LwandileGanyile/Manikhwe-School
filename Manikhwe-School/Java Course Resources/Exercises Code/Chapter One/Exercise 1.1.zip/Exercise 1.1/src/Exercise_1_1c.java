
public class Exercise_1_1c {

	public static void main(String[] args) {
		
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Computer Science.");
		System.out.println("Programming is fun.");
		
		// We can achieve the same output if we use \n.		
		/*System.out.print("Welcome to Java.\n");
		 * System.out.print("Welcome to Computer Science.\n");
		 System.out.print("Programming is fun.\n");*/
		
		// We can achieve the same output if we use \n.		
		/*System.out.print("Welcome to Java.\nWelcome to 
		 * Computer Science.\nProgramming is fun.");
		 */
		
		/* 
		 * The lesson here is that println can replaced by \n.
		 * \n is used to break a string. 
		*/
	}
}

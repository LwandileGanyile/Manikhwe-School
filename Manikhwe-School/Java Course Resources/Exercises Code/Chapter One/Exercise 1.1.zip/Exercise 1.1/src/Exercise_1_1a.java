
public class Exercise_1_1a {

	public static void main(String[] args) {
		
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Computer Science.");
		System.out.println("Programming is fun.");
		
		// Look what happens if we replace println with print.		
		/*System.out.print("\nWelcome to Java.");
		System.out.print("Welcome to Computer Science.");
		System.out.print("Programming is fun.");*/
		
		// Look what happens if we add a space at the end of the word Java.		
		/*System.out.print("\n\nWelcome to Java. ");
		System.out.print("Welcome to Computer Science.");
		System.out.print("Programming is fun.");*/
		
		// Look what happens if we add a space at the end of the word Java and the word Science.		
		/*System.out.print("\n\nWelcome to Java. ");
		System.out.print("Welcome to Computer Science. ");
		System.out.print("Programming is fun.");*/
		
		/* The Lesson here is that it matters how you put your spaces inside the "".
		 *That is to say how you put your spaces will affect your output.
		 * Another lesson here is that the println will make the next word/string to 
		 * be written on the next line where as print will make it remain on the same line.
		*/
	}
}


public class Exercise_1_1b {

	public static void main(String[] args) {
		
		System.out.println("Welcome to Java.");
		System.out.println("Welcome to Computer Science.");
		System.out.println("Programming is fun.");
		
		// We can achieve the same output if we use by doing the following.		
		/*System.out.print("Welcome to Java.");
		 * System.out.println();
		 * System.out.print("Welcome to Computer Science.");
		 * System.out.println();
		System.out.print("Programming is fun.");*/
		
		/* 
		 * The lesson here is that println can be used without passing it a string
		 * where as print can't. 
		*/
	}
}


public class Exercise_1_2b {

	public static void main(String[] args) {
		
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		
		/* Look what happens if we put something before the 
		* word/string Welcome and after the word Java.
		*/
		System.out.println("\n**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		
		// The lesson here is that what ever you put inside "" will affect your output.
	}

}

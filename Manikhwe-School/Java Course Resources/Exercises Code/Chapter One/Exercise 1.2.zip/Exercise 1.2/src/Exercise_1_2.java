
public class Exercise_1_2 {

	public static void main(String[] args) {
		
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		
		/* Look what happens if we put something before the 
		* word/string Welcome and after the word Java.
		*/
		System.out.println("\n**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		System.out.println("**********Welcome to Java**********");
		
		
		/* Look what happens if we put something before the 
		* word/string Welcome and after the word Java.
		*/
		// Put ten arrows at the beginning and end of the string.
		System.out.println("\n>>>>>>>>>>Welcome to Java<<<<<<<<<<");
		// Put eight arrows at the beginning and end of the string.
		System.out.println(">>>>>>>>Welcome to Java<<<<<<<<");
		// Put six arrows at the beginning and end of the string.
        System.out.println(">>>>>>Welcome to Java<<<<<<");		
		// Put four arrows at the beginning and end of the string.
		System.out.println(">>>>Welcome to Java<<<<");		
		// Put two arrows at the beginning and end of the string.
		System.out.println(">>Welcome to Java<<");
		
		/* Look what happens if we put something before the 
		* word/string Welcome and after the word Java.
		*/
		// Put ten hash tags at the beginning and end of the string.
		System.out.println("\n##Welcome to Java##");
		// Put eight hash tags at the beginning and end of the string.
		System.out.println("####Welcome to Java####");
		// Put six hash tags at the beginning and end of the string.
        System.out.println("######Welcome to Java######");		
		// Put four hash tags at the beginning and end of the string.
		System.out.println("########Welcome to Java########");		
		// Put two hash tags at the beginning and end of the string.
		System.out.println("##########Welcome to Java##########");
		
		
		// The lesson here is that what ever you put inside "" will affect your output.
	}

}

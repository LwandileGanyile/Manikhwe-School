
public class Exercise_1_8a {

	public static void main(String[] args) {
		
		// The question is, which approximation value of PI should we used?
		// The answer is none of the ones we computed in the last episode.
		// We should use the PI from the Math class. In fact every time you
		// want to use PI on your calculations, use the one in Math class.
		
		System.out.println("Simple Solution");
		System.out.println(2*5.5*Math.PI);
		System.out.println(5.5*5.5*Math.PI);
		
		// Again, whenever you have got to perform some mathematical calculations you should first check the math class.
	}

}

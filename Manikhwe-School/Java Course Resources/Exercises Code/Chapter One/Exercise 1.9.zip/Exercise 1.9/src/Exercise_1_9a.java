
public class Exercise_1_9a {

	public static void main(String[] args) {
		
		System.out.println(4.5*7.9);
		
	}

}

import java.util.Scanner;

public class Exercise_2_3 {

	public static void main(String[] args) {
		
		// We need a scanner to capture user input.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts a user to enter a value for feets.
		System.out.print("Enter a value for feet: ");
		// We keep the user input in a variable.
		double numberInFeet = scanner.nextDouble();
		
		// Now we do the math conversion.
		// 1 feet = 0.305 meters
		/* Using the same idea we used in the episode where we were
		 *  converting miles to kilometers we came up with the 
		 *  something like following equation.
		*/ 
		// 1 feet = 0.305 meters
		// nemberInFeets feet = ? meters
		// Let the question mark be x.
		// 1 feet = 0.305 meters
		// nemberInFeet feet = x meters
		// We cross multiple to find x.
		// 1*x = 0.305*numberInFeet
		// x = 0.305*numberInFeet
		
		System.out.printf(numberInFeet+ " feet is %2.4f meters", 0.305*numberInFeet);

		// Close the scanner.
		scanner.close();
	}

}

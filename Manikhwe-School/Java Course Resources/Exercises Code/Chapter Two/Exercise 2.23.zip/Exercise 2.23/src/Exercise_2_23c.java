import java.util.Scanner;

public class Exercise_2_23c {
	// Student C did not comment his code.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner scanner = new Scanner(System.in);

		// Prompts a user to enter the distance.
		System.out.print("Enter the driving distance: ");
		// Assign user user input to a variable called distance.
		double distance = scanner.nextDouble();
		
		// Prompts a user to enter the miles per gallon.
		System.out.print("Enter miles per gallon: ");
		// Assign user user input to a variable called milesPerGallon.
		double milesPerGallon = scanner.nextDouble();
		
		// Prompts a user to enter the price per gallon.
		System.out.print("Enter price per gallon: ");
		// Assign user user input to a variable called pricePerGallon.
		double pricePerGallon = scanner.nextDouble();
		
		// We first find the amount of gallon need for a given distance
		double amountOfGallon = distance/milesPerGallon;
		
		// Display to a console.
		System.out.printf("The cost of driving is $%2.2f", amountOfGallon*pricePerGallon);
		
		// Close scanner
		scanner.close();
	}

}

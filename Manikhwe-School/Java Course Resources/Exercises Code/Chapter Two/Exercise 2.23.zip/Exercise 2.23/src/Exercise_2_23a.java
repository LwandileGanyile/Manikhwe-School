import java.util.Scanner;

public class Exercise_2_23a {

	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);

		
		System.out.print("Enter the driving distance: ");
		
		double d= scanner.nextDouble();
		
		
		System.out.print("Enter miles per gallon: ");
		
		double mpg = scanner.nextDouble();
		
		
		System.out.print("Enter price per gallon: ");
		
		double ppg = scanner.nextDouble();
		
		
		double aog = d/mpg;
		
		double ans = aog*ppg;
		
		
		System.out.print("The cost of driving is $" + ans );
		
		
		scanner.close();
	}

}

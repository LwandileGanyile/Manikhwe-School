import java.util.Scanner;

public class Exercise_2_23b {
	// Student A don't know how to format an output.
	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);

		
		System.out.print("Enter the driving distance: ");
		
		double distance = scanner.nextDouble();
		
		
		System.out.print("Enter miles per gallon: ");
		
		double milesPerGallon = scanner.nextDouble();
		
		
		System.out.print("Enter price per gallon: ");
		
		double pricePerGallon = scanner.nextDouble();
		
		
		double amountOfGallon = distance/milesPerGallon;
		
		
		System.out.printf("The cost of driving is $%2.2f", amountOfGallon*pricePerGallon);
		
		
		scanner.close();
	}

}

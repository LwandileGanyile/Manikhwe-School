
public class Exercise_2_18 {

	public static void main(String[] args) {
		
		// Display heading.
		System.out.println("a\tb\tMath.pow(a,b)");
		
		int one = 1;
		int two = 2;
		int three = 3;
		int four = 4;
		int five = 5;
		int six = 6;
		
		System.out.println(one+"\t"+two+"\t"+(int)(Math.pow(one, two)));
		System.out.println(two+"\t"+three+"\t"+(int)(Math.pow(two, three)));
		System.out.println(three+"\t"+four+"\t"+(int)(Math.pow(three, four)));
		System.out.println(four+"\t"+five+"\t"+(int)(Math.pow(four, five)));
		System.out.println(five+"\t"+six+"\t"+(int)(Math.pow(five, six)));
	}

}

import java.util.Scanner;

public class Exercise_2_12c {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner myScanner = new Scanner(System.in);
		
		// Prompts a user to enter the speed and acceleration.
		System.out.print("Enter speed and acceleration: ");
		double speed = myScanner.nextDouble();
		double acceleration = myScanner.nextDouble();
		
		double length = Math.pow(speed, 2)/(2*acceleration);
		
		// Display a formatted output.
		// % - is always require when formatting a output.
		// 2 - present the number of small spaces after the is word.
		// 3 - after the dot means we want 3 decimal places.
		// f - tells the compiler we formatting float number.
		System.out.printf("The minimum runway length for this airplane is %2.3f", length);
		
		myScanner.close();

	}

}

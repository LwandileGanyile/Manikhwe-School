import java.util.Scanner;

public class Exercise_2_12b {
	// Student A has variables namely that are not a good practice.
	public static void main(String[] args) {
		
		Scanner myScanner = new Scanner(System.in);
		
		System.out.print("Enter speed and acceleration: ");
		double speed = myScanner.nextDouble();
		double acceleration = myScanner.nextDouble();
		
		double length = Math.pow(speed, 2)/(2*acceleration);
		
		System.out.printf("The minimum runway length for this airplane is %2.3f", length);
		
		myScanner.close();

	}

}

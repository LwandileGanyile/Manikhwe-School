import java.util.Scanner;

public class Exercise_2_13c {
	// Student B did not comment his code.
	public static void main(String[] args) {
		
		// Use a scanner to capture user input.
		Scanner in = new Scanner(System.in);
		
		// Prompt a user to enter the initial amount.
		System.out.print("Enter the monthly saving amount: ");
		// Assign user input into a new variable.
		double initialAmount = in.nextDouble();
		
		double monthlyInterestRate = 0.05/12;
		double constantValue = 1 + monthlyInterestRate;
		
		double firstMonthAmount = initialAmount * constantValue;
		double secondMonthAmount = (initialAmount + firstMonthAmount)*constantValue;
		double thirdMonthAmount = (initialAmount + secondMonthAmount)*constantValue;
		double forthMonthAmount = (initialAmount + thirdMonthAmount)*constantValue;
		double fifthMonthAmount = (initialAmount + forthMonthAmount)*constantValue;
		double sixthMonthAmount = (initialAmount + fifthMonthAmount)*constantValue;
		
		
		
		// Display output on the console.
		System.out.printf("After the sixth month, the account value is $%2.2f", sixthMonthAmount);
		
		// Close the scanner.
		in.close();

	}

}

import java.util.Scanner;

public class Exercise_2_13b {
	// The naming conversion for student A's variables is wicked.
	public static void main(String[] args) {
		
		// Use a scanner to capture user input.
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter the monthly saving amount: ");
		double initialAmount = in.nextDouble();
		
		double monthlyInterestRate = 0.05/12;
		double constantValue = 1 + monthlyInterestRate;
		
		double firstMonthAmount = initialAmount * constantValue;
		double secondMonthAmount = (initialAmount + firstMonthAmount)*constantValue;
		double thirdMonthAmount = (initialAmount + secondMonthAmount)*constantValue;
		double forthMonthAmount = (initialAmount + thirdMonthAmount)*constantValue;
		double fifthMonthAmount = (initialAmount + forthMonthAmount)*constantValue;
		double sixthMonthAmount = (initialAmount + fifthMonthAmount)*constantValue;
		
		System.out.printf("After the sixth month, the account value is $%2.2f", sixthMonthAmount);
		
		in.close();

	}

}

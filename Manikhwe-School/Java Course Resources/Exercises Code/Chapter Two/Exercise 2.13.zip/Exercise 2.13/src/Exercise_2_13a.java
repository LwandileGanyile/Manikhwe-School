import java.util.Scanner;

public class Exercise_2_13a {
	// The naming conversion for student A's variables is wicked.
	public static void main(String[] args) {
		
		// Use a scanner to capture user input.
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter the monthly saving amount: ");
		double initAmt = in.nextDouble();
		
		double monthlyInterestRate = 0.05/12;
		double constV = 1 + monthlyInterestRate;
		
		double firstMonAmt = initAmt * constV;
		double secondMonAmt = (initAmt + firstMonAmt)*constV;
		double thirdMonAmt = (initAmt + secondMonAmt)*constV;
		double forthMonAmt = (initAmt + thirdMonAmt)*constV;
		double fifthMonAmt = (initAmt + forthMonAmt)*constV;
		double sixthMonAmt = (initAmt + fifthMonAmt)*constV;
		
		System.out.printf("After the sixth month, the account value is $%2.2f", sixthMonAmt);
		
		in.close();

	}

}

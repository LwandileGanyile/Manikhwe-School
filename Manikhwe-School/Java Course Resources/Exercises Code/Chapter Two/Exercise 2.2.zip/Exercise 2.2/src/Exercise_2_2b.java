import java.util.Scanner;

public class Exercise_2_2b {
	// Student A did not comment his code, and the output is not user friendly.
	public static void main(String[] args) {
		
		// We need to create a scanner in order to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// We need two variables to store a radius and a length
		// We use a double data type for both input because they might have a decimal point.
		double rad;
		double len;
		
		// Prompts a user to enter two numbers for radius and a length.
		System.out.print("Enter the radius and length of a cylinder: ");
		// Store first number in the radius variable declared earlier.
		rad = scanner.nextDouble();
		// Store second number in the length variable declared earlier.
		len = scanner.nextDouble();
		
		// Declare and initialize the area and volume by means of calculations.
		double a = rad * rad * Math.PI;
		// The volume uses the above area variable for its calculations;
		double vol = a*len;
		
		// Display the result in a console.
		System.out.println("The area is " + a);
		// We need to go to the next line before displaying the anything.
		System.out.println("The volume is " + vol);
		
		// Lastly we close the scanner.
		scanner.close();
	}

}

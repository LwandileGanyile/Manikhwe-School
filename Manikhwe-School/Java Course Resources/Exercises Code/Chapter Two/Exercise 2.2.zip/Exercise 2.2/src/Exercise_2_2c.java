import java.util.Scanner;

public class Exercise_2_2c {
	// Student B's variables are not descriptive.
	public static void main(String[] args) {
		
		// We need to create a scanner in order to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// We need two variables to store a radius and a length
		// We use a double data type for both input because they might have a decimal point.
		double radius;
		double length;
		
		// Prompts a user to enter two numbers for radius and a length.
		System.out.print("Enter the radius and length of a cylinder: ");
		// Store first number in the radius variable declared earlier.
		radius = scanner.nextDouble();
		// Store second number in the length variable declared earlier.
		length = scanner.nextDouble();
		
		// Declare and initialize the area and volume by means of calculations.
		double area = radius * radius * Math.PI;
		// The volume uses the above area variable for its calculations;
		double volume = area*length;
		
		// Display the result in a console.
		System.out.printf("The area is %2.3f", area);
		// We need to go to the next line before displaying the anything.
		System.out.printf("\nThe volume is %2.1f", volume);
		
		// Lastly we close the scanner.
		scanner.close();
	}

}

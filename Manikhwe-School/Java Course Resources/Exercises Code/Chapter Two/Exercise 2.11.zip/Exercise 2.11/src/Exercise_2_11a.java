import java.util.Scanner;

public class Exercise_2_11a {

	public static final int SECONDS_IN_A_MINUTE = 60;
	
	public static final int MINUTES_IN_AN_HOUR = 60;
	
	public static final int INITIAL_POPULATION_SIZE = 312032486;
	
	public static void main(String[] args) {
		
		Scanner mySc = new Scanner(System.in);

		System.out.print("Enter the number of years: ");
		
		int numberOfYears = mySc.nextInt();
	
		int secInH = SECONDS_IN_A_MINUTE * MINUTES_IN_AN_HOUR;
				
		int secInD = secInH*24;
				
		int secInY = secInD*365;
		
		int secInYrs = secInY*numberOfYears;
				
		int numOfDeaths = (int)(secInYrs/13.0);
		
		int numOfBirths = secInYrs/7;
		
		int numOfImm = secInYrs/45;
		
		System.out.println("The population in " + numberOfYears + " years is " + (INITIAL_POPULATION_SIZE + numOfBirths + numOfImm - numOfDeaths));
		
		mySc.close();
	}

}

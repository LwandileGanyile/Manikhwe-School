import java.util.Scanner;

public class Exercise_2_11c {

	// Student B doesn't comment his code.
	// We know there are 60 seconds in a minute.
	// This is how we declare and initialize constants.
	/* I know the final keywork is not covered in chapter 3
	* but it is a good thing to use it here. It simply
	* says a variable is a constant.
	*/
	public static final int SECONDS_IN_A_MINUTE = 60;
	
	// We also know that there are 60 minutes in an hour.
	// This is how we declare and initialize constants.
	/* I know the final keyword is not covered in chapter 3
	* but it is a good thing to use it here. It simply
	* says a variable is a constant.
	*/
	public static final int MINUTES_IN_AN_HOUR = 60;
	
	public static final int INITIAL_POPULATION_SIZE = 312032486;
	
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner myScanner = new Scanner(System.in);

		// Prompts a user to enter number of years.
		System.out.print("Enter the number of years: ");
		
		// Keep assign user input into a variable for later use.
		int numberOfYears = myScanner.nextInt();
	
		// Now we need find the number of seconds in an hour.
		// 1 hour = 60 seconds * 60
		// 1 hour = 3600 seconds
		int secondsInAnHour = SECONDS_IN_A_MINUTE * MINUTES_IN_AN_HOUR;
				
		// To find the number of seconds in one day we do the following.
		int secondsInADay = secondsInAnHour*24;
				
		// Now we need to find the number of seconds in 1 year.
		int secondsInAYear = secondsInADay*365;
		
		// Now we need to find the number of seconds in n years.
		// Here n is the user input.
		int secondsInYears = secondsInAYear*numberOfYears;
				
		// Now we must get the number of people died each year.
		// Casting can be replaced by using 13 instead of 13.0.
		int numberOfDeaths = (int)(secondsInYears/13.0);
		
		// Now we must get the number of people born each year.
		int numberOfBirths = secondsInYears/7;
		
		// Lastly we find the number of immigrant each year.
		int numberOfImmigrant = secondsInYears/45;
		
				
		// Final year population = Current population + number of born people + number of immigrants - number of died people.		
		System.out.println("The population in " + numberOfYears + " years is " + (INITIAL_POPULATION_SIZE + numberOfBirths + numberOfImmigrant - numberOfDeaths));
		
		// Close scanner.
		myScanner.close();
	}

}

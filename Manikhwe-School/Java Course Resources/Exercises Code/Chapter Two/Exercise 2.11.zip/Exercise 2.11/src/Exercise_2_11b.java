import java.util.Scanner;

public class Exercise_2_11b {
	// Student A's solution has variable names that are hard to read.
	public static final int SECONDS_IN_A_MINUTE = 60;
	
	public static final int MINUTES_IN_AN_HOUR = 60;
	
	public static final int INITIAL_POPULATION_SIZE = 312032486;
	
	public static void main(String[] args) {
		
		Scanner myScanner = new Scanner(System.in);

		System.out.print("Enter the number of years: ");
		
		int numberOfYears = myScanner.nextInt();
	
		int secondsInAnHour = SECONDS_IN_A_MINUTE * MINUTES_IN_AN_HOUR;
				
		int secondsInADay = secondsInAnHour*24;
				
		int secondsInAYear = secondsInADay*365;
		
		int secondsInYears = secondsInAYear*numberOfYears;
				
		int numberOfDeaths = (int)(secondsInYears/13.0);
		
		int numberOfBirths = secondsInYears/7;
		
		int numberOfImmigrant = secondsInYears/45;
		
		System.out.println("The population in " + numberOfYears + " years is " + (INITIAL_POPULATION_SIZE + numberOfBirths + numberOfImmigrant - numberOfDeaths));
		
		myScanner.close();
	}

}

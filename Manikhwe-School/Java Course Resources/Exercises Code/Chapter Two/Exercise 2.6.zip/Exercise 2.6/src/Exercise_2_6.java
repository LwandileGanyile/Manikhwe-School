import java.util.Scanner;

public class Exercise_2_6 {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);

		// Declare a variable to hold a user input.
		int userInput;
		// Holds the results after performing the division operator.
		int divideableInteger;
		
		// Prompts a user to enter an integer.
		System.out.print("Enter a number between 0 and 1000: ");
		userInput = scanner.nextInt();
				
		// Create a variable to hold the unit digit of a integer.
		int unitsNumber = 0;
		unitsNumber += userInput%10;
		divideableInteger = userInput/10;
		
		// Create a variable to hold the tens digit of a integer.
		int tensNumber = 0;
		tensNumber += divideableInteger%10;
		// This is the same as dividedInteger = dividedInteger/10.
		divideableInteger /= 10;
		
		// Create a variable to hold the hundreds digit of a integer.
		int hundredsNumber = 0;
		hundredsNumber += divideableInteger%10;
		// This is the same as dividedInteger /= 10.
		divideableInteger = divideableInteger/10;
		
		// Display the output on the console.
		System.out.println("The sum of the digits is " + (unitsNumber + tensNumber + hundredsNumber));
		
		
		
		scanner.close();
	}

}

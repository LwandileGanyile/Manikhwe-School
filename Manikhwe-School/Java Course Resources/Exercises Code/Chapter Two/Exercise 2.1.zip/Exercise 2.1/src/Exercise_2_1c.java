import java.util.Scanner;

public class Exercise_2_1c {
	// Student A did not have good names for variables.
	public static void main(String[] args) {
		
		// We need a scanner to read data from the console.
		Scanner scanner = new Scanner(System.in);
		// We next to keep the value entered by a user;
		/* We use a double data type because a user will 
		enter a number with a decimal point.*/
		// We declare the variable to keep user's input.
		double temperatureInCelsius;
		
		// Prompts the user to enter a temperature in celsius.
		/* We use print because we want the inputed number to 
		 * be on the same line as the prompt string.
		 */
		System.out.print("Enter a degree in Celsius : ");
		// Take user input and store it in the variable temperatureInCelsius. 
		// We use nextDouble because a user will enter a number with a decimal point.
		temperatureInCelsius = scanner.nextDouble();
		
		// Perform conversion and store the results in a variable.
		double temperatureInFahrenheit = (9.0 / 5) * temperatureInCelsius + 32;
		
		// Display the result in the console.
		// Before we display anything we new to go to the next line.
		System.out.printf(temperatureInCelsius + " Celsius is %2.1f Fahrenheit",temperatureInFahrenheit );
		
		// Every time you use a scanner you need to close it.
		scanner.close();
	}

}

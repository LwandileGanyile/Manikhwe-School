import java.util.Scanner;

public class Exercise_2_21a {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		// input is the variable name so it can be anything.
		Scanner in = new Scanner(System.in);
		
		// Prompts a user to enter investment amount.
		System.out.print("Enter investment amount: ");
		// Declare and initialize a variable to hold user input.
		double invAmt = in.nextDouble();
		
		// Prompts a user to enter annual interest rate.
		System.out.print("Enter annual interest rate in percentage: ");
		// Declare and initialize a variable to hold user input.
		// We need to convert the given input to percentages.
		double annualIntRate = in.nextDouble()/100;
		
		// Prompts a user to enter number of years.
		System.out.print("Enter number of years: ");
		// Declare and initialize a variable to hold user input.
		int numOfYrs = in.nextInt();
		
		// Declare and initialize future value.
		/* Because there are 12 months in a year we 
		 * need to divide our annual interest rate by 12.
		 */
		double futInvValue = invAmt * 
		Math.pow((1 + (annualIntRate/12)),
		numOfYrs*12);
		
		// Display formatted output to a user.
		System.out.print("Accumulated value is $" + futInvValue);
		
		// Close scanner.
		in.close();
	}

}

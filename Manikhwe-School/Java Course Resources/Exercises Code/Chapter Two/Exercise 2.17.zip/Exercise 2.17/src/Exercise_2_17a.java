import java.util.Scanner;

public class Exercise_2_17a {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the temperature in Fahrenheit between -58�F and 41�F: ");

		double tempInFah = scanner.nextDouble();
		
		System.out.print("Enter the wind speed (>=2) in miles per hour: ");

		double speedInMPH = scanner.nextDouble();
		
		// First term
		double var1 = 35.74;
		// Second term
		double var2 = 0.6215*tempInFah;
		// Third term
		double var3 = 35.75*Math.pow(speedInMPH, 0.16);
		// Forth term
		double var4 = 0.4275*tempInFah;
		// Last term
		double var5 = Math.pow(speedInMPH, 0.16);
		
		double w = var1 + (var2 - var3) + var4*var5;
		
		System.out.printf("The wind chill index is %2.5f", w);
		
		scanner.close();
	}

}

import java.util.Scanner;

public class Exercise_2_17b {
	// Student A used many variables.
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the temperature in Fahrenheit between -58�F and 41�F: ");

		double tempInFah = scanner.nextDouble();
		
		System.out.print("Enter the wind speed (>=2) in miles per hour: ");

		double speedInMPH = scanner.nextDouble();
		
		double var1 = 35.74;

		double var2 = 0.6215*tempInFah - 35.75*Math.pow(speedInMPH, 0.16);

		double var3 = 0.4275*tempInFah * Math.pow(speedInMPH, 0.16);
		
		double w = var1 + var2 + var3;
		
		System.out.printf("The wind chill index is %2.5f", w);
		
		scanner.close();
	}

}

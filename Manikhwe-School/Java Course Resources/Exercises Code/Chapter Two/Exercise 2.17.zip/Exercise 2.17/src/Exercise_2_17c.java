import java.util.Scanner;

public class Exercise_2_17c {
	// Student B had variables that are not descriptive.
	// Student C used as fewer variables as possible.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts a user to enter temperature.
		System.out.print("Enter the temperature in Fahrenheit between -58�F and 41�F: ");
		// Assign user input into a variable.
		double temparatueInFahrenheit = scanner.nextDouble();
		
		// Prompts a user to enter wind speed.
		System.out.print("Enter the wind speed (>=2) in miles per hour: ");
		// Assign user input into a variable.
		double speedInMilesPerHour = scanner.nextDouble();
		
		// twc = 35.74 + 0.6215ta - 35.75v0.16 + 0.4275tav0.16
		double windChillTemperature  = 35.74 + 0.6215*temparatueInFahrenheit - 
		35.75*Math.pow(speedInMilesPerHour, 0.16) + 0.4275*temparatueInFahrenheit*Math.pow(speedInMilesPerHour, 0.16);
		
		// Display wind chill temperature.
		// Use printf to format the output.
		System.out.printf("The wind chill index is %2.5f", windChillTemperature);
		
		
		// Close scanner.
		scanner.close();
	}

}

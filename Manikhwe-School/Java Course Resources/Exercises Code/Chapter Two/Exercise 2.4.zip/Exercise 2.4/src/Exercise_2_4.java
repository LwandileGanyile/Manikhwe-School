import java.util.Scanner;

public class Exercise_2_4 {

	public static void main(String[] args) {
		
		// We need a scanner to capture user input.
		Scanner scanner = new Scanner(System.in);
				
		// Prompts a user to enter a number in pounds.
		System.out.print("Enter a number in pounds: ");
		// We keep the user input in a variable.
		double numberOfPounds = scanner.nextDouble();
				
		// Now we do the math conversion.
		// 1 pound = 0.454 kilogram
		/* Using the same idea we used in the last episode 
		 * we came up with the something like following 
		 * equation.
		*/ 
		// 1 pound = 0.454 kilogram
		// numberOfPounds pounds = ? kilograms
		// Let the question mark be x.
		// 1 pound = 0.454 kilogram
		// numberOfPounds pounds = x kilograms
		// We cross multiple to find x.
		// 1*x = 0.454*numberOfPounds
		// x = 0.454*numberOfPounds
				
		System.out.printf(numberOfPounds+ " pounds is %2.3f kilograms", 0.454*numberOfPounds);

		// Close the scanner.
		scanner.close();
	}

}

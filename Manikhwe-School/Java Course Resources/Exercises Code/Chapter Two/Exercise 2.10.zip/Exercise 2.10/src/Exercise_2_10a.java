import java.util.Scanner;

public class Exercise_2_10a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input;
		Scanner input = new Scanner(System.in);

		// Declare weight of water.
		double ww;
		
		// Declare initial temperature.
		double it;
		
		// Declare final temperature
		double ft;
		
		// Prompts the user to enter amount of water.
		System.out.print("Enter the amount of water in kilograms: ");
		ww = input.nextDouble();
		
		// Prompts the user to enter initial temperature.
		System.out.print("Enter the initial temperature: ");
		it = input.nextDouble();
		
		// Prompts the user to enter final temperature.
		System.out.print("Enter the final temperature: ");
		ft = input.nextDouble();
		
		// Declare and initialize the energy needed.
		// Apply the given formula and replace M with energyNeed.
		double en = ww * (ft - it) * 4184;
		
		// Display the output to the console.
		System.out.printf("The energy needed is %2.1f", en);
		
		// Close the scanner.
		input.close();
	}

}

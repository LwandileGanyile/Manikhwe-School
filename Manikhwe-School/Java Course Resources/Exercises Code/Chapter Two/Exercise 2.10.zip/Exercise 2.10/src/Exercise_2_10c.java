import java.util.Scanner;

public class Exercise_2_10c {

	// Student B did not comment his code.
	public static void main(String[] args) {
		
		// Create a scanner to read user input;
		Scanner input = new Scanner(System.in);

		// Declare weight of water.
		double waterWeight;
		
		// Declare initial temperature.
		double initialTemperature;
		
		// Declare final temperature
		double finalTemperature;
		
		// Prompts the user to enter amount of water.
		System.out.print("Enter the amount of water in kilograms: ");
		waterWeight = input.nextDouble();
		
		// Prompts the user to enter initial temperature.
		System.out.print("Enter the initial temperature: ");
		initialTemperature = input.nextDouble();
		
		// Prompts the user to enter final temperature.
		System.out.print("Enter the final temperature: ");
		finalTemperature = input.nextDouble();
		
		// Declare and initialize the energy needed.
		// Apply the given formula and replace M with energyNeed.
		double energyNeed = waterWeight * (finalTemperature - initialTemperature) * 4184;
		
		// Display the output to the console.
		System.out.printf("The energy needed is %2.1f", energyNeed);
		
		// Close the scanner.
		input.close();
	}

}

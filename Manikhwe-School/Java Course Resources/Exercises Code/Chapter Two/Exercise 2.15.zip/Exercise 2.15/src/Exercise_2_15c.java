import java.util.Scanner;

public class Exercise_2_15c {
	// Student C minimize variables even further.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		// You can put any name for a variable.
		Scanner scanner = new Scanner(System.in);

		// Prompts a user to enter a the first point.
		System.out.print("Enter x1 and y1: ");
		
		// The x-coordinate of the first point.
		double x1 = scanner.nextDouble();
		// The y-coordinate of the first point.
		double y1 = scanner.nextDouble();
		
		// Prompts a user to enter a the first point.
		System.out.print("Enter x2 and y2: ");
		
		// The x-coordinate of the second point.
		double x2 = scanner.nextDouble();
		// The y-coordinate of the second point.
		double y2 = scanner.nextDouble();
		
		// Display distance on a console.
		System.out.println("The distance between the two points is " + Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2)));
		
		// Close scanner.
		scanner.close();
	}

}

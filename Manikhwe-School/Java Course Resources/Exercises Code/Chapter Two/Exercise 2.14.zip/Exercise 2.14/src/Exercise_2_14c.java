import java.util.Scanner;

public class Exercise_2_14c {
	// Student C did not comment his code.
	public static void main(String[] args) {
		
		// Scanner a scanner to get user input.
		Scanner myScanner = new Scanner(System.in);

		// Prompts user to enter weight.
		System.out.print("Enter weight in pounds: ");		
		double weightInPounds = myScanner.nextDouble();
		
		// Prompts user to enter height.
		System.out.print("Enter height in inches: ");		
		double heightInInches = myScanner.nextDouble();
		
		// Convert pounds to kilograms
		// 1 pound = 0.45359237 kilograms
		// weightInPounds pounds = ? kilograms
		// The question mark is what we looking for.
		/* Let the question mark be weightInKilometers. So, we cross 
		 * multiply and get the following.
		 */
		// weightInKilograms = 0.45359237*weightInPounds kilograms.
		
		double weightInKilograms = 0.45359237*weightInPounds;
		
		// Convert inches to meters
		// 1 inch = 0.0254 meters
		// heightInInches inch = ? meters
		// The question mark is what we looking for.
		/* Let the question mark be heightInMeters. So, we cross 
		* multiply and get the following.
		*/
		// heightInMeters = 0.0254*heightInInches meters.
		
		double heightInMeters = 0.0254*heightInInches;
		
		double bmi = weightInKilograms/Math.pow(heightInMeters, 2);
		
		// Display BMI on the console
		System.out.printf("BMI is %2.4f", bmi);
		
		// Close the scanner.
		myScanner.close();
	}

}

import java.util.Scanner;

public class Exercise_2_14b {

	public static void main(String[] args) {
		
		Scanner myScanner = new Scanner(System.in);

		System.out.print("Enter weight in pounds: ");		
		double weightInPounds = myScanner.nextDouble();

		System.out.print("Enter height in inches: ");		
		double heightInInches = myScanner.nextDouble();
		
		double weightInKilograms = 0.45359237*weightInPounds;
		
		double heightInMeters = 0.0254*heightInInches;
		
		double bmi = weightInKilograms/Math.pow(heightInMeters, 2);
		
		System.out.printf("BMI is %2.4f", bmi);
		
		myScanner.close();
	}

}

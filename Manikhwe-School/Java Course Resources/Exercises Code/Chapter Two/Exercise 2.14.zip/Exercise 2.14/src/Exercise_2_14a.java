import java.util.Scanner;

public class Exercise_2_14a {

	public static void main(String[] args) {
		
		Scanner myScanner = new Scanner(System.in);

		System.out.print("Enter weight in pounds: ");		
		double wInP = myScanner.nextDouble();

		System.out.print("Enter height in inches: ");		
		double hInInc= myScanner.nextDouble();
		
		double wInKil= 0.45359237*wInP;
		
		double hInM = 0.0254*hInInc;
		
		double bmi = wInKil/Math.pow(hInM, 2);
		
		System.out.printf("BMI is %2.4f", bmi);
		
		myScanner.close();
	}

}

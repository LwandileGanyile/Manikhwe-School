import java.util.Scanner;

public class Exercise_2_7c {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);

		// Declare a variable to hold minutes that a user input.
		int minutes;
		
		// Declare a variable to hold numbers of years.
		int numberOfYears;
		
		// Declare a variable to hold number of days
		int numberOfDays;
		
		// Declare a variable that will hold the remaining minutes after division.
		int remainingMinutes;
		
		
		// Prompts a user to enter minutes.
		System.out.print("Enter the number of minutes: ");
		minutes = scanner.nextInt();
		
		// Now we convert minutes to years.
		// We know there are 60 minutes in an hours.
		/* We know there are 24 hours in a day, meaning 
		 * there are 60*24 minutes in a day.
		 */
		/* So we have 1440 minutes in a day according 
		 * to our calculation.*/
		/* Because there are 365 days in a year it implies 
		 * we have 1440*365 minutes in a year.
		 */
		// So there are 525600 minutes in a year.
		
		// Find the number of years in the given minutes.
		numberOfYears = minutes/525600;
		
		// Remove the minutes making up the number of years.
		remainingMinutes = minutes%525600;
		
		// Find the number of days in the remaining minutes.
		numberOfDays = remainingMinutes/1440;
		
		// Display out put to the user.
		System.out.println(minutes + " minutes is approximately " + 
		numberOfYears + " years and " + numberOfDays+" days");
		
		// Close the scanner.
		scanner.close();
	}

}

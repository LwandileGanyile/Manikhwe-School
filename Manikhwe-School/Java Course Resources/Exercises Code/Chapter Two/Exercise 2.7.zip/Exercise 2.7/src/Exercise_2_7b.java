import java.util.Scanner;

public class Exercise_2_7b {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		int minutes;
		
		int numberOfYears;
		
		int numberOfDays;
		
		int remainingMinutes;
		
		System.out.print("Enter the number of minutes: ");
		minutes = scanner.nextInt();
		
		numberOfYears = minutes/525600;
		
		remainingMinutes = minutes%525600;
		
		numberOfDays = remainingMinutes/1440;
		
		System.out.println(minutes + " minutes is approximately " + 
		numberOfYears + " years and " + numberOfDays+" days");

		scanner.close();
	}

}

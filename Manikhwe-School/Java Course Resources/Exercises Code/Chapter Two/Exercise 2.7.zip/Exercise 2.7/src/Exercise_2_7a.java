import java.util.Scanner;

public class Exercise_2_7a {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		int min;
		
		int numOfYrs;
		
		int numOfDays;
		
		int remMin;
		
		System.out.print("Enter the number of minutes: ");
		min = scanner.nextInt();
		
		numOfYrs = min/525600;
		
		remMin = min%525600;
		
		numOfDays = remMin/1440;
		
		System.out.println(min + " minutes is approximately " + 
		numOfYrs + " years and " + numOfDays+" days");

		scanner.close();
	}

}

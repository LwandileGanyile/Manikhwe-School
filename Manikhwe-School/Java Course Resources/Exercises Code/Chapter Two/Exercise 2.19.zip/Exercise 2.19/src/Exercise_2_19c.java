import java.util.Scanner;

public class Exercise_2_19c {
	// Student A did not comment his code.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);

		// Prompts a user to enter three points.
		System.out.print("Enter three points for a triangle: ");
		// Declare and initialize variables to hold first point.
		// Read x-axis value for the first point.
		double x1 = scanner.nextDouble();
		// Read y-axis value for the first point.
		double y1 = scanner.nextDouble();
		
		// Declare and initialize variables to hold second point.
		// Read x-axis value for the second point.
		double x2 = scanner.nextDouble();
		// Read y-axis value for the second point.
		double y2 = scanner.nextDouble();
		
		// Declare and initialize variables to hold second point.
		// Read x-axis value for the second point.
		double x3 = scanner.nextDouble();
		// Read y-axis value for the second point.
		double y3 = scanner.nextDouble();
		
		// Declare and initialize a variable to hold side 1 length.
		double side1 = Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2));
		
		// Declare and initialize a variable to hold side 2 length.
		double side2 = Math.sqrt(Math.pow(x2-x3, 2) + Math.pow(y2-y3, 2));
		
		// Declare and initialize a variable to hold side 3 length.
		double side3 = Math.sqrt(Math.pow(x1-x3, 2) + Math.pow(y1-y3, 2));
		
		// Calculate the value of s.
		double s = (side1 + side2 + side3)/2;
		
		// Holds what is inside the square root
		double product = s*(s-side1)*(s-side2)*(s-side3);
		
		// Calculate area.
		double area = Math.sqrt(product);
		
		// Show output to a user.
		System.out.printf("The area of the triangle is %2.1f", area);
		
		// Close the scanner.
		scanner.close();
	}

}

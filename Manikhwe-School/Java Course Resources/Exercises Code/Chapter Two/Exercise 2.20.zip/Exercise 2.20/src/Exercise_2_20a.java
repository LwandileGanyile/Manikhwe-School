import java.util.Scanner;

public class Exercise_2_20a {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter balance and interest rate (e.g., 3 for 3%): ");

		double bal = scanner.nextDouble();
		double intRate = scanner.nextDouble();
		
		double ans = bal*(intRate/1200.0);
		
		System.out.print("The interest is " + ans);
		
		scanner.close();
	}

}

import java.util.Scanner;

public class Exercise_2_20b {
	/* Student B realize there is no need of 
	 * the variable that holds the final answer.
	 * Secondly, student B realize that student
	 * B did not comment his code.*/
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter balance and interest rate (e.g., 3 for 3%): ");

		double balance = scanner.nextDouble();
		double interestRate = scanner.nextDouble();
		
		System.out.printf("The interest is %2.5f", balance*(interestRate/1200.0));
		
		scanner.close();
	}

}

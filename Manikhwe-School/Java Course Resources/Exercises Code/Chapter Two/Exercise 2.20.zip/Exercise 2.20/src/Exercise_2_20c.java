import java.util.Scanner;

public class Exercise_2_20c {
	// Student B did not comment his code.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);

		// Prompts a user to enter balance and interest rate.
		System.out.print("Enter balance and interest rate (e.g., 3 for 3%): ");
		// Assign user input into variables.
		double balance = scanner.nextDouble();
		double interestRate = scanner.nextDouble();
		
		// Display interest to a console.
		System.out.printf("The interest is %2.5f", balance*(interestRate/1200.0));
		
		// Close scanner
		scanner.close();
	}

}

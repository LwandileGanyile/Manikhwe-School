import java.util.Scanner;

public class Exercise_2_5 {

	public static void main(String[] args) {
		
		// We need a scanner to capture user input.
		Scanner scanner = new Scanner(System.in);

		// Prompt a user to enter a sub-total and a gratuity.
		System.out.print("Enter the subtotal and a gratuity rate: ");
		
		// Declare and initialize variables to hold  user input.
		double subTotal = scanner.nextDouble();
		// We need to convert the entered gratuity to percents.
		double gratuity = scanner.nextDouble()/10.0;
		
		// Display the output on the console.
		// The general form of printf is as follows.
		// System.out.printf("string",term1, term2,...termn);
		System.out.printf("The gratuity is $%2.1f and total is $%2.1f",gratuity, subTotal+gratuity);

		// The prntf method is not introduced up to this chapter.
		/* However it is helpful to know it, otherwise you will have
		   difficulties formatting your output.*/
		
		scanner.close();
	}

}

import java.util.Scanner;

public class Exercise_2_9c {

	public static void main(String[] args) {
		
		// Create scanner to enable user input.
		Scanner input = new Scanner(System.in);

		// Declare initial velocity.
		double initialVelocity;
		
		// Declare final velocity.
		double finalVelocity;
		
		// Declare time span.
		double timeSpan;
		
		// Prompts a user to enter a three values.
		System.out.print("Enter v0, v1, and t: ");
		
		// Initialize initial velocity.
		initialVelocity = input.nextDouble();
		
		// Initialize finalVelocity.
		finalVelocity = input.nextDouble();
		
		// Initialize time span.
		timeSpan = input.nextDouble();
		
		// Declare and initialize the average velocity.
		double averageAcceleration = (finalVelocity-initialVelocity)/timeSpan;
		
		System.out.printf("The average acceleration is %2.4f", averageAcceleration);
		
		// Close scanner.
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_2_9b {
	// Student A has a solution that is hard to read.
	public static void main(String[] args) {
		
		// Create scanner to enable user input.
		Scanner input = new Scanner(System.in);

		double initialVelocity;
		
		double finalVelocity;
		
		double timeSpan;
		
		System.out.print("Enter v0, v1, and t: ");
		
		initialVelocity = input.nextDouble();
		
		finalVelocity = input.nextDouble();
		
		timeSpan = input.nextDouble();
		
		double averageAcceleration = (finalVelocity-initialVelocity)/timeSpan;
		
		System.out.printf("The average acceleration is %2.4f", averageAcceleration);
		
		// Close scanner.
		input.close();
	}

}

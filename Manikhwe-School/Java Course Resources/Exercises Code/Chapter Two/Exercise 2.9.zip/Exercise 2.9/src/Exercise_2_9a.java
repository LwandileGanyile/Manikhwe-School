import java.util.Scanner;

public class Exercise_2_9a {

	public static void main(String[] args) {
		
		// Create scanner to enable user input.
		Scanner input = new Scanner(System.in);

		double initVel;
		
		double finVel;
		
		double timeSpan;
		
		System.out.print("Enter v0, v1, and t: ");
		
		initVel = input.nextDouble();
		
		finVel = input.nextDouble();
		
		timeSpan = input.nextDouble();
		
		double avgAcc = (finVel-initVel)/timeSpan;
		
		System.out.printf("The average acceleration is %2.4f", avgAcc);
		
		// Close scanner.
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_2_16 {

	public static void main(String[] args) {
		
		// Create a scanner to read input.
		Scanner scanner = new Scanner(System.in);

		// Prompts a user to enter a side length.
		System.out.print("Enter the side: ");
		double side = scanner.nextDouble();
		
		// We splits the equation into two parts and store each part of a variable.
		double firstPart = (3.0*Math.sqrt(3))/2;
		double secondPart = Math.pow(side, 2.0);
		
		// Display the output on the console.
		System.out.printf("The area of the hexagon is %2.4f",(firstPart*secondPart));
		
		// I seems like my answer is not what is expected.
		// Feel free to tell me where i could have made a mistake.
		
		// Close scanner.
		scanner.close();
	}

}

import java.util.Scanner;

public class Exercise_4_4a {

	public static void main(String[] args) {
		
		// Create scanner
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a side.
		System.out.print("Enter the side ( > 0 ): ");
		double s = input.nextDouble();
		
		if(s >= 0  ) {
			// Store numerator
			double numerator = 6*Math.pow(s,2);
			// Store denominator
			double denominator = 4*Math.tan(Math.PI/6.0);
			
			// Compute area and store it value.
			double area = numerator/denominator;
			
			System.out.printf("The area of the hexagon is %4.2f.",area);
		}
		else
			System.out.print("Invalid input : a side must be non negetive.");
		
		input.close();
	}

}

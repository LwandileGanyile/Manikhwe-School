import java.util.Scanner;

public class Exercise_4_4c {

	// Student A and Bs' solutions over used variables..
	public static void main(String[] args) {
		
		// Create scanner
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a side.
		System.out.print("Enter the side : ");
		double s = input.nextDouble();
		
		System.out.printf("The area of the hexagon is %4.2f.",((6*Math.pow(s,2))/(4*Math.tan(Math.PI/6.0))));
		
		input.close();
	}

}

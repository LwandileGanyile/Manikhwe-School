import java.util.Scanner;

public class Exercise_4_4b {

	//Student A's solution is not user friendly.
	//Student A validate unnecessarily.
	public static void main(String[] args) {
		
		// Create scanner
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a side.
		System.out.print("Enter the side : ");
		double s = input.nextDouble();
		
		// Store numerator
		double numerator = 6*Math.pow(s,2);
		// Store denominator
		double denominator = 4*Math.tan(Math.PI/6.0);
		
		// Compute area and store it value.
		double area = numerator/denominator;
			
		System.out.printf("The area of the hexagon is %4.2f.",area);
			
		input.close();
	}

}

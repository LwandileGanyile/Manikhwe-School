import java.util.Scanner;

//Student A's solution is not user friendly.
//He doesn't validate user input either.
public class Exercise_4_1b {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts user to enter the length from center.
		System.out.print("Enter the length( > 0) from the center to a vertex: ");
		double r = input.nextDouble();
		
		if(r > 0) {
			// Calculate s.
			double s = 2*r*Math.sin(Math.PI/5.0);
			
			// Calculate area's numerator.
			double numerator = 5*Math.pow(s, 2);
			// Calculate area's denominator.
			double denominator = 4*Math.tan(Math.PI/5.0);
			
			double area = numerator/denominator;
			
			System.out.printf("The area of the pentagon is %4.2f", area);
		}
		else {
			System.out.print("Radius cannot be less of equals to zero.");
			System.exit(0);
		}
		
		input.close();
	}

}

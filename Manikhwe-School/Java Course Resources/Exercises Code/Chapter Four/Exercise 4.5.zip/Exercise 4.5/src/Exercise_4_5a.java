import java.util.Scanner;

public class Exercise_4_5a {

	// Student A's output is not user friendly.
	public static void main(String[] args) {
		
		// Create scanner
		Scanner input = new Scanner(System.in);

		// Prompt a user to enter number of sides.
		System.out.print("Enter the number of sides: ");
		int n = input.nextInt();
		
		if(n <= 0) {
			System.out.print("Invalid input : Make sure the number of sides is greater than zero.");
			System.exit(0);
		}
		
		// Prompt a user to enter side length.
		System.out.print("Enter the side: ");
		double s = input.nextDouble();
				
		if(s <= 0) {
			System.out.print("Invalid input : Make sure the number of sides is greater than zero.");
			System.exit(1);
		}
			
		double numerator = n*s*s;
		double denominator = 4*Math.tan(Math.PI/n);
		
		double area = numerator/denominator;
		
		System.out.print("The area of the polygon is " + area);
		
		input.close();
	}

}

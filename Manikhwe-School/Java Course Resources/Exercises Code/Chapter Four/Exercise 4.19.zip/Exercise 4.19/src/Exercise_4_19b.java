import java.util.Scanner;

public class Exercise_4_19b {

	// Student A did not validate user input.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.		
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter nine digits.
		System.out.print("Enter the first 9 digits of an ISBN as integer: ");
		
		// Store user input into a variable for later use.
		String stringISBN = input.next();
		
		
		if(stringISBN.length()==9 && stringISBN.charAt(0)=='0') {
		// We need to make sure we have a reference to the original user input.
		// We need this variable because the userInput will be altered later in a program.
		String originalISBN = stringISBN;
		
		// Stores the 9th digit of user input multiplied by 9.
		int ninethProduct = Integer.parseInt(stringISBN.substring(8, 9)) * 9;
		
		// Stores the 8th digit of user input multiplied by 8.
		int eighthProduct = Integer.parseInt(stringISBN.substring(7, 8)) * 8;
		
		// Stores the 7th digit of user input multiplied by 7.
		int seventhProduct = Integer.parseInt(stringISBN.substring(6, 7)) * 7;
		
		// Stores the 6th digit of user input multiplied by 6.
		int sixthProduct = Integer.parseInt(stringISBN.substring(5, 6)) * 6;
				
		// Stores the 5th digit of user input multiplied by 5.
		int fifthProduct = Integer.parseInt(stringISBN.substring(4, 5)) * 5;
		
		// Stores the 4th digit of user input multiplied by 4.
		int forthProduct = Integer.parseInt(stringISBN.substring(3, 4)) * 4;
		
		// Stores the 3rd digit of user input multiplied by 3.
		int thirdProduct = Integer.parseInt(stringISBN.substring(2, 3)) * 3;
		
		// Stores the 2nd digit of user input multiplied by 2.
		int secondProduct = Integer.parseInt(stringISBN.substring(1, 2)) * 2;
		
		// The sum of all eight products.
		int sumOfProducts = secondProduct + thirdProduct + forthProduct + fifthProduct
		+ sixthProduct + seventhProduct + eighthProduct + ninethProduct;
		
		// Holds the determiner value between 1 and 10.
		int determiner = sumOfProducts%11;
		
		System.out.print("The ISBN-10 number is " + originalISBN);
		
		if(determiner == 10)
			System.out.print("X");
		else
			System.out.print(determiner);
		}
		else 
			System.out.print("Make sure you enter nine digits starting with zero.");
		// Close scanner
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_4_18a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter two characters.
		System.out.print("Enter two characters : ");
		// Store user input.
		String characters = input.next();
		// Represent the string to be output on the console.
		String finalOutput;

		if(characters.equals("M1"))
			finalOutput = "Mathematics Freshman";
		else if(characters.equals("M2"))
			finalOutput = "Mathematics Sophomore";
		else if(characters.equals("M3"))
			finalOutput = "Mathematics Junior";
		else if(characters.equals("M3"))
			finalOutput = "Mathematics Senior";
		else if(characters.equals("C1"))
			finalOutput = "Computer Science Freshman";
		else if(characters.equals("C2"))
			finalOutput = "Computer Science Sophomore";
		else if(characters.equals("C3"))
			finalOutput = "Computer Science Junior";
		else if(characters.equals("C4"))
			finalOutput = "Computer Science Senior";
		else if(characters.equals("I1"))
			finalOutput = "Information Technology Freshman";
		else if(characters.equals("I2"))
			finalOutput = "Information Technology Sophomore";
		else if(characters.equals("I3"))
			finalOutput = "Information Technology Junior";
		else if(characters.equals("I4"))
			finalOutput = "Information Technology Junior";
		else
			finalOutput = "Invalid input";
		
		System.out.print(finalOutput);

		input.close();
	}

}

import java.util.Scanner;

public class Exercise_4_18c {
	// Student B over uses if else statements.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter two characters.
		System.out.print("Enter two characters : ");
		// Store user input.
		String characters = input.next();
		// Represent the string to be output on the console.
		String finalOutput = "";
		
		if(characters.length() == 2) {
			if((characters.charAt(0) == 'M' ||
			    characters.charAt(0) == 'C' ||
			    characters.charAt(0) == 'I') &&
			    (characters.charAt(1) == '1' ||
			    characters.charAt(1) == '2' ||
			    characters.charAt(1) == '3' ||
			    characters.charAt(1) == '4')
			  ) {
				if(characters.charAt(0) == 'M')
					finalOutput += "Mathematics ";
				else if(characters.charAt(0) == 'C')
					finalOutput += "Computer Science ";
				else
					finalOutput += "Information Technology ";
					
				switch(characters.charAt(1)) {
				case '1':
					finalOutput += "Freshman";
					break;
				case '2':
					finalOutput += "Sophomore";
					break;
				case '3' :
					finalOutput += "Junior";
					break;
				default :
					finalOutput += "Senior.";
					break;
				}
				System.out.print(finalOutput);
			}
			else
				System.out.print("Invalid input.");
		}
		else
			System.out.print("Error : Only two characters are allowed.");
		
		
		input.close();
	}

}

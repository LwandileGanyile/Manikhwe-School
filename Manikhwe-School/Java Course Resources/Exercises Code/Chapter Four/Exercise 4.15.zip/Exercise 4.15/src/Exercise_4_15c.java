import java.util.Scanner;

public class Exercise_4_15c {
	// Student B uses if else statements, which result is more than one print statement.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a number.
		System.out.print("Enter a letter : ");
		String userInput = input.next();
		
		if(userInput.length() != 1) {
			System.out.print("Error : Make sure you enter exactly one letter.");
			System.exit(0);
		}
		
		char userLetter = Character.toUpperCase(userInput.charAt(0));
		// Used to determine the corresponding number of a letter.
		byte number = 0;
		
		if(userLetter == 'A' || userLetter == 'B' || userLetter == 'C')
			number = 2;
		else if(userLetter == 'D' || userLetter == 'E' || userLetter == 'F')
			number = 3;
		else if(userLetter == 'G' || userLetter == 'H' || userLetter == 'I')
			number = 4;
		else if(userLetter == 'J' || userLetter == 'K' || userLetter == 'L')
			number = 5;
		else if(userLetter == 'M' || userLetter == 'N' || userLetter == 'O')
			number = 6;
		else if(userLetter == 'P' || userLetter == 'Q' || userLetter == 'R' || userLetter == 'S')
			number = 7;
		else if(userLetter == 'T' || userLetter == 'U' || userLetter == 'V')
			number = 8;
		else if(userLetter == 'W' || userLetter == 'X' || userLetter == 'Y' || userLetter == 'Z')
			number = 9;
		
		System.out.print((number != 0)?"The corresponding number is " + number + ".":userInput + " is an invalid input.");
			
		input.close();
	}

}

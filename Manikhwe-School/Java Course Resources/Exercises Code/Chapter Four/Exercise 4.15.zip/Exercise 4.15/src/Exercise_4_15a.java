import java.util.Scanner;

public class Exercise_4_15a {
	// Student A uses an integer data-type instead of a byte for number.
	// Student A isn't take advantage of the character class.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a number.
		System.out.print("Enter a letter : ");
		String userInput = input.next();
		
		if(userInput.length() != 1) {
			System.out.print("Error : Make sure you enter exactly one letter.");
			System.exit(0);
		}
		
		char userLetter = userInput.charAt(0);
		// Used to determine the corresponding number of a letter.
		byte number = 0;
		
		if(userLetter == 'A' || userLetter == 'B' || userLetter == 'C' ||
		userLetter == 'a' || userLetter == 'b' || userLetter == 'c')
			number = 2;
		else if(userLetter == 'D' || userLetter == 'E' || userLetter == 'F' ||
		userLetter == 'd' || userLetter == 'e' || userLetter == 'f')
			number = 3;
		else if(userLetter == 'G' || userLetter == 'H' || userLetter == 'I' ||
		userLetter == 'g' || userLetter == 'h' || userLetter == 'i')
			number = 4;
		else if(userLetter == 'J' || userLetter == 'K' || userLetter == 'L' ||
		userLetter == 'j' || userLetter == 'k' || userLetter == 'l')
			number = 5;
		else if(userLetter == 'M' || userLetter == 'N' || userLetter == 'O' ||
		userLetter == 'm' || userLetter == 'n' || userLetter == 'o')
			number = 6;
		else if(userLetter == 'P' || userLetter == 'Q' || userLetter == 'R' || 
		userLetter == 'S' || userLetter == 'p' || userLetter == 'q' || 
		userLetter == 'r' || userLetter == 's')
			number = 7;
		else if(userLetter == 'T' || userLetter == 'U' || userLetter == 'V' ||
		userLetter == 't' || userLetter == 'u' || userLetter == 'v')
			number = 8;
		else if(userLetter == 'W' || userLetter == 'X' || userLetter == 'Y' || 
		userLetter == 'Z' || userLetter == 'w' || userLetter == 'x' || 
		userLetter == 'y' || userLetter == 'z')
			number = 9;
		
		if(number != 0)
			System.out.print("The corresponding number is " + number + ".");
		else
			System.out.print(userInput + " is an invalid input.");
		input.close();
	}

}

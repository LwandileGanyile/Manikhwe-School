
public class Exercise_4_25b {
	// Student A isn't taking advantage of the ASCII codes for letters.
	public static void main(String[] args) {
		
		String output = "";
		
		// A random first letter.
		char firstCharacter = (char)(65+(int)(Math.random()*26));
		// A random second letter.
		char secondCharacter = (char)(65+(int)(Math.random()*26));
		// A random third letter.
		char thirdCharacter = (char)(65+(int)(Math.random()*26));
		
		/* If you perform the following three lines 
		 * in one step, a compiler will perform addition 
		 * instead of concatenation.*/
		output += firstCharacter;
		output += secondCharacter; 
		output += thirdCharacter;
		
		// Find first random digit form 0-9;
		int firstNumber = (int)(Math.random()*10);
		// Find second random digit form 0-9;
		int secondNumber = (int)(Math.random()*10);
		// Find third random digit form 0-9;
		int thirdNumber = (int)(Math.random()*10);
		// Find forth random digit form 0-9;
		int forthNumber = (int)(Math.random()*10);
		
		/* If you perform the following four lines 
		 * in one step, a compiler will perform addition 
		 * instead of concatenation.*/
		output += firstNumber;
		output += secondNumber;
		output += thirdNumber;
		output += forthNumber;
		
		System.out.print("A randomly generated number plate is " + output + ".");

	}

}

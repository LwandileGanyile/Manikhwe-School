
public class Exercise_4_25a {
	// Student A isn't taking advantage of the ASCII codes for letters.
	public static void main(String[] args) {
		
		String output = "";
		
		// A random first number representing first letter.
		int firstCharacterPresenter = 1+(int)(Math.random()*26);	
		// A random second number representing second letter.
		int secondCharacterPresenter = 1+(int)(Math.random()*26);
		// A random third number representing third letter.
		int thirdCharacterPresenter = 1+(int)(Math.random()*26);
		
		switch(firstCharacterPresenter) {
		case 1 : output += 'A'; break;
		case 2 : output += 'B'; break;
		case 3 : output += 'C'; break;
		case 4 : output += 'D'; break;
		case 5 : output += 'E'; break;
		case 6 : output += 'F'; break;
		case 7 : output += 'G'; break;
		case 8 : output += 'H'; break;
		case 9 : output += 'I'; break;
		case 10 : output += 'J'; break;
		case 11 : output += 'K'; break;
		case 12 : output += 'L'; break;
		case 13 : output += 'M'; break;
		case 14 : output += 'N'; break;
		case 15 : output += '0'; break;
		case 16 : output += 'P'; break;
		case 17 : output += 'Q'; break;
		case 18 : output += 'R'; break;
		case 19 : output += 'S'; break;
		case 20 : output += 'T'; break;
		case 21 : output += 'U'; break;
		case 22 : output += 'V'; break;
		case 23 : output += 'W'; break;
		case 24 : output += 'X'; break;
		case 25 : output += 'Y'; break;
		default : output += 'Z'; break;
		}
		
		switch(secondCharacterPresenter) {
		case 1 : output += 'A'; break;
		case 2 : output += 'B'; break;
		case 3 : output += 'C'; break;
		case 4 : output += 'D'; break;
		case 5 : output += 'E'; break;
		case 6 : output += 'F'; break;
		case 7 : output += 'G'; break;
		case 8 : output += 'H'; break;
		case 9 : output += 'I'; break;
		case 10 : output += 'J'; break;
		case 11 : output += 'K'; break;
		case 12 : output += 'L'; break;
		case 13 : output += 'M'; break;
		case 14 : output += 'N'; break;
		case 15 : output += '0'; break;
		case 16 : output += 'P'; break;
		case 17 : output += 'Q'; break;
		case 18 : output += 'R'; break;
		case 19 : output += 'S'; break;
		case 20 : output += 'T'; break;
		case 21 : output += 'U'; break;
		case 22 : output += 'V'; break;
		case 23 : output += 'W'; break;
		case 24 : output += 'X'; break;
		case 25 : output += 'Y'; break;
		default : output += 'Z'; break;
		}
		
		switch(thirdCharacterPresenter) {
		case 1 : output += 'A'; break;
		case 2 : output += 'B'; break;
		case 3 : output += 'C'; break;
		case 4 : output += 'D'; break;
		case 5 : output += 'E'; break;
		case 6 : output += 'F'; break;
		case 7 : output += 'G'; break;
		case 8 : output += 'H'; break;
		case 9 : output += 'I'; break;
		case 10 : output += 'J'; break;
		case 11 : output += 'K'; break;
		case 12 : output += 'L'; break;
		case 13 : output += 'M'; break;
		case 14 : output += 'N'; break;
		case 15 : output += '0'; break;
		case 16 : output += 'P'; break;
		case 17 : output += 'Q'; break;
		case 18 : output += 'R'; break;
		case 19 : output += 'S'; break;
		case 20 : output += 'T'; break;
		case 21 : output += 'U'; break;
		case 22 : output += 'V'; break;
		case 23 : output += 'W'; break;
		case 24 : output += 'X'; break;
		case 25 : output += 'Y'; break;
		default : output += 'Z'; break;
		}
		
		// Find first random digit form 0-9;
		int firstNumber = (int)(Math.random()*10);
		// Find second random digit form 0-9;
		int secondNumber = (int)(Math.random()*10);
		// Find third random digit form 0-9;
		int thirdNumber = (int)(Math.random()*10);
		// Find forth random digit form 0-9;
		int forthNumber = (int)(Math.random()*10);
		
		/* If you perform the following four lines 
		 * in one step, a compiler will perform addition 
		 * instead of concatenation.*/
		output += firstNumber;
		output += secondNumber;
		output += thirdNumber;
		output += forthNumber;
		
		System.out.print("A randomly generated number plate is " + output + ".");

	}

}

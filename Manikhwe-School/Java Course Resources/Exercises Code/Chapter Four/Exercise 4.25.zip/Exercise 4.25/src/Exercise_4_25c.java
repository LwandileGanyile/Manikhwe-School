
public class Exercise_4_25c {
	// Student B uses many variables unnecessarily.
	public static void main(String[] args) {
		
		String output = "";
		
		// A random first letter.
		char randomCharacter = (char)(65+(int)(Math.random()*26));
		output += randomCharacter;
		
		// A random second letter.
		randomCharacter = (char)(65+(int)(Math.random()*26));
		output += randomCharacter;
		
		// A random third letter.
		randomCharacter = (char)(65+(int)(Math.random()*26));
		output += randomCharacter;
		
		// Find first random digit form 0-9;
		int randomNumber = (int)(Math.random()*10);
		output += randomNumber;
		
		// Find second random digit form 0-9;
		randomNumber = (int)(Math.random()*10);
		output += randomNumber;
		
		// Find third random digit form 0-9;
		randomNumber = (int)(Math.random()*10);
		output += randomNumber;
		
		// Find forth random digit form 0-9;
		randomNumber = (int)(Math.random()*10);
		output += randomNumber;
		
		System.out.print("A randomly generated number plate is " + output + ".");

	}

}

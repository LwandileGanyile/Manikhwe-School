import java.util.Scanner;

public class Exercise_4_20c {
	/* Student B over used if else statements, 
	which resulted on many print statements.*/
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a word/sentence.
		System.out.print("Enter a word or sentence : ");
		
		// Store user input.
		String userInput = input.nextLine();
		
		if(userInput.length() > 0)
			System.out.print(((userInput.indexOf(' ')<0)?"The word " :"The sentence ") + 
			userInput + " has length " + userInput.length() + " and the first character is " + userInput.charAt(0) + ".");
		else
			System.out.print("Make sure you enter a word.");
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_4_20a {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a word/sentence.
		System.out.print("Enter a word or sentence : ");
		
		// Store user input.
		String userInput = input.nextLine();
			
		if(userInput.indexOf(' ')<0)
				System.out.print("The word ");
		else
			System.out.print("The sentence ");
			
		System.out.print(userInput + " has length " + userInput.length() + 
		" and the first character is " + userInput.charAt(0) + ".");
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_4_20b {
	/* Student A doesn't take care of the case 
	 * where a user enters nothing. And this gives 
	 * and exception.*/
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a word/sentence.
		System.out.print("Enter a word or sentence : ");
		
		// Store user input.
		String userInput = input.nextLine();
		
		if(userInput.length() > 0) {
			if(userInput.indexOf(' ')<0)
					System.out.print("The word ");
			else
				System.out.print("The sentence ");
			
			System.out.print(userInput + " has length " + userInput.length() + 
			" and the first character is " + userInput.charAt(0) + ".");
		}
		else
			System.out.print("Make sure you enter a word.");
		input.close();
	}

}

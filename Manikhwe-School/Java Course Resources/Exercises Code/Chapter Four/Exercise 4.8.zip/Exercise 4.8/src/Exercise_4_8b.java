import java.util.Scanner;

public class Exercise_4_8b {

	public static void main(String[] args) {
		
		// Create scanner
		Scanner input = new Scanner(System.in);

		// Prompt a user to enter an ASCII code.
		System.out.print("Enter an ASCII code : ");
		
		String userInput = input.next();
		
		if(Integer.parseInt(userInput)>=0 && 
		Integer.parseInt(userInput) <= 127) 	
			System.out.print((char)Byte.parseByte(userInput));
		else {
			System.out.print("Make sure you enter a number between (0-127).");
			System.exit(0);
		}
		
		input.close();
	}

}

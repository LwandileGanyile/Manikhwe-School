import java.util.Scanner;

public class Exercise_4_7a {
	
	// I doubt my solution for exercise 4.7
	public static void main(String[] args) {
		
		// Create scanner to get radius from user.
		Scanner input = new Scanner(System.in);
		// Prompt user to enter a circle's radius.
		System.out.print("Enter the radius(>0) of the bounding circle: ");
		double radius = input.nextDouble();
		
		if(radius <= 0) {
			System.out.print("Make sure the radius is more than zero.");
			System.exit(0);
		}

		// Angle for the first point.
		double angle = Math.PI/4;
		
		// Use a random angle between 0 and 90 to get the first point.
		double p1XCoordinate = radius*Math.cos(angle);
		double p1YCoordinate = radius*Math.sin(angle);
		String point1 = "(" + p1XCoordinate + " , " + p1YCoordinate + ")\n";
		
		// Point of the 0 clock.
		double p2XCoordinate = radius*Math.cos(Math.PI/2);
		double p2YCoordinate = radius*Math.sin(Math.PI/2);
		String point2 = "(" + p2XCoordinate + " , " + p2YCoordinate + ")\n";
		
		// Use 180-randomAngle or 90+random angle to find third point
		double p3XCoordinate = radius*Math.cos(Math.PI-angle);
		double p3YCoordinate = radius*Math.sin(Math.PI-angle);
		String point3 = "(" + p3XCoordinate + " , " + p3YCoordinate + ")\n";
		
		// Use 180+randomAngle or 270-random angle to find forth point.
		double p4XCoordinate = radius*Math.cos(Math.PI+angle);
		double p4YCoordinate = radius*Math.sin(Math.PI+angle);
		String point4 = "(" + p4XCoordinate + " , " + p4YCoordinate + ")\n";
		
		// Use 360-randomAngle or 270+random angle to find fifth point
		double p5XCoordinate = radius*Math.cos(2*Math.PI-angle);
		double p5YCoordinate = radius*Math.sin(2*Math.PI-angle);
		String point5 = "(" + p5XCoordinate + " , " + p5YCoordinate + ")";
		
		System.out.println("The coordinates of five points on the pentagon are");
		// A \n is used to make each point be displayed in a new line.
		System.out.print(point1 + point2 + point3 + point4 + point5);
		
		
		input.close();
	}

}

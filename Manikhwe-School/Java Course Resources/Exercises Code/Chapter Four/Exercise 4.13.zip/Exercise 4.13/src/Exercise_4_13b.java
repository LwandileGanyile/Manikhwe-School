import java.util.Scanner;

public class Exercise_4_13b {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a letter.
		System.out.print("Enter a letter : ");
		String userInput = input.nextLine();
		
		if(!Character.isLetter(userInput.charAt(0))) 
			System.out.print(userInput + " is an invalid input.");
		else {
			char originalCharacter = userInput.charAt(0);
			char character = Character.toUpperCase(originalCharacter);
			
			if(character == 'A' || character == 'E' || character == 'I' ||
			character == 'O' || character == 'U')
				System.out.print(originalCharacter + " is a vowel.");
			else 
				System.out.print(originalCharacter + " is a consonant.");
		}
		
		input.close();
	}

}

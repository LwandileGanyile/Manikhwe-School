import java.util.Scanner;

public class Exercise_4_21b {

	// Student A over used if else statements unnecessarily.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter an SSN.
		System.out.print("Enter a SSN : ");
		
		// Store user input.
		String ssn = input.next();
		
		// Store a determinant of whether a not an input is valid or not.
		boolean isValid = true;
		
		// Store the part of the message to be displayed if the ssn is invalid.
		String invalidInput = ssn + " is an invalid";
		// Store the part of the message to be displayed if the ssn is valid.
		String validInput = ssn + " is a valid";
		// Store the part of the message to be displayed regardless of the validity..
		String partOfMessage = " social security number.";
		
		if(ssn.length()>0) {
			if(
				ssn.length()!=11 || 
				!Character.isDigit(ssn.charAt(0)) || 
				!Character.isDigit(ssn.charAt(1)) ||
				!Character.isDigit(ssn.charAt(2)) ||
				ssn.charAt(3) != '-' ||
				!Character.isDigit(ssn.charAt(4)) ||
				!Character.isDigit(ssn.charAt(5)) ||
				ssn.charAt(6) != '-' ||
				!Character.isDigit(ssn.charAt(7)) ||
				!Character.isDigit(ssn.charAt(8)) ||
				!Character.isDigit(ssn.charAt(9)) ||
				!Character.isDigit(ssn.charAt(10))
			)
				isValid = false;
			if(isValid) {
				validInput += partOfMessage;
				System.out.print(validInput);
			}
			else {
				invalidInput += partOfMessage;
				System.out.print(invalidInput);
			}
			
		}
		else
			System.out.print("Make sure you enter something.");
		
		input.close();
	}

}

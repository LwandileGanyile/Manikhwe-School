import java.util.Scanner;

public class Exercise_4_17a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input =  new Scanner(System.in);

		// Prompts a user to enter a year.
		System.out.print("Enter a year : ");
		// Store a year.
		int year = input.nextInt();
		
		// Prompts a user to enter a month.
		System.out.print("Enter a month : ");
		// Store a month.
		String month = input.next();
		
		// Make sure the month consist of only 3 letter
		if(month.length() != 3) {
			System.out.print("Application terminated : Make sure you enter the first three letters of the month only.");
			System.exit(1);
		}
		
		if(!Character.isUpperCase(month.charAt(0))) {
			System.out.print("Application terminated : Make sure the first letter is a capital letter.");
			System.exit(2);
		}
		
		
		int numberOfDays;
		
		if(month.equals("Jan") || month.equals("Mar") ||
		month.equals("May") || month.equals("Jul") ||
		month.equals("Aug") || month.equals("Oct") ||
		month.equals("Dec"))
			numberOfDays = 31;
		else if(month.equals("Feb")) {
			if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
				numberOfDays = 29;
			else
				numberOfDays = 28;
		}
		else
			numberOfDays = 30;
		
		System.out.print(month + " " + year + " has " + numberOfDays + " days.");
		
		input.close();
	}

}

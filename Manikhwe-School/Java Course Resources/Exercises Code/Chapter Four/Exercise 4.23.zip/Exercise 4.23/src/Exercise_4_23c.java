import java.util.Scanner;

public class Exercise_4_23c {

	// Student B did not use the minimum amount of variables possible.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter his data.
		System.out.print("Enter employee's name : ");
		//Store employee's name.
		// Some people have names consisting of spaces in between.
		String name = input.nextLine();
		
		System.out.print("Enter number of hours worked in a week : ");
		// Store a person's worked hours.
		double workedHours = input.nextDouble();
		
		if(workedHours < 0) {
			System.out.print("Application terminated : Worked hours cannot be less than zero.");
			System.exit(0);
		}
		
		System.out.print("Enter hourly pay rate : ");
		// Store hourly pay rate.
		double hourlyPayRate = input.nextDouble();
		
		if(hourlyPayRate <= 0) {
			System.out.print("Application terminated : Hourly pay rate cannot be less or equal to zero.");
			System.exit(1);
		}
		
		System.out.print("Enter federal tax withholding rate : ");
		// Store federal tax withholding rate.
		double federalTaxWithholdingRate = input.nextDouble();
		
		if(federalTaxWithholdingRate < 0) {
			System.out.print("Application terminated : Federal tax withholding rate cannot be less than zero.");
			System.exit(1);
		}
		
		System.out.print("Enter state tax withholding rate:");
		// Store state tax withholding rate.
		double stateTaxWithholdingRate = input.nextDouble();
		
		if(stateTaxWithholdingRate < 0) {
			System.out.print("Application terminated : State tax withholding rate cannot be less than zero.");
			System.exit(1);
		}
		
		// The final output to be displayed of screen.
		String formatedOutput = "\n\n";
		
		formatedOutput += "Employee Name : " + name + "\n";
		formatedOutput += "Hours Worked : " + workedHours + "\n" ;
		formatedOutput += "Pay Rate : $" + hourlyPayRate + "\n" ;
		formatedOutput += "Gross Pay : $ " + (workedHours*hourlyPayRate) + "\n" ;
		formatedOutput += "Deductions :\n\tFederal Withholding (" 
			+ (federalTaxWithholdingRate*100) + "%) : $" + 
			(workedHours*hourlyPayRate*federalTaxWithholdingRate) + 
			"\n\tState Withholding (" + (stateTaxWithholdingRate*100) + "%) : $" + 
			(workedHours*hourlyPayRate*stateTaxWithholdingRate) + 
			"\n\tTotal Deductions : $" + (workedHours*hourlyPayRate*federalTaxWithholdingRate 
			+ workedHours*hourlyPayRate*stateTaxWithholdingRate) + "\nNet Pay : $" + 
			(workedHours*hourlyPayRate-workedHours*hourlyPayRate*federalTaxWithholdingRate-
			workedHours*hourlyPayRate*stateTaxWithholdingRate);
		
		System.out.print(formatedOutput);
		
		input.close();
	}

}

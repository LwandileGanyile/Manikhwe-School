import java.util.Scanner;

public class Exercise_4_24a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter the first city.
		System.out.print("Enter the first city : ");
		String firstCity = input.next();
		
		// Prompts a user to enter the second city.
		System.out.print("Enter the second city : ");
		String secondCity = input.next();
		
		// Prompts a user to enter the second city.
		System.out.print("Enter the third city : ");
		String thirdCity = input.next();
		
		if(firstCity.length() == 0 || secondCity.length() == 0
		|| thirdCity.length() == 0) {
			System.out.print("Error : All cities must have a name.");
			System.exit(0);
		}
		
		String orderedCities = "";
		
		if(firstCity.compareTo(secondCity) < 0) {
			if(firstCity.compareTo(thirdCity) < 0) {
				orderedCities += firstCity + " ";
				if(secondCity.compareTo(thirdCity) < 0) 
					orderedCities += secondCity + " " + thirdCity;			
				else
					orderedCities += thirdCity + " " + secondCity;	
			}
			else
				orderedCities += thirdCity + " " + firstCity + " " + secondCity; 								
		}
		else if(firstCity.compareTo(secondCity) > 0) {
			if(secondCity.compareTo(thirdCity) < 0) {
				orderedCities += secondCity + " ";
				if(firstCity.compareTo(thirdCity) < 0) 
					orderedCities += firstCity + " " + thirdCity;			
				else
					orderedCities += thirdCity + " " + firstCity;	
			}
			else
				orderedCities +=  thirdCity + " " + secondCity + " " + firstCity;
		}
		else {
			if(secondCity.compareTo(thirdCity) < 0) 
				orderedCities +=  thirdCity + " " + secondCity + " " + firstCity;		
			else
				orderedCities += secondCity + " " + firstCity + " " + thirdCity;
		}
		
		System.out.print("The three cities in alphabetical order are " + orderedCities);
		
		input.close();
	}

}

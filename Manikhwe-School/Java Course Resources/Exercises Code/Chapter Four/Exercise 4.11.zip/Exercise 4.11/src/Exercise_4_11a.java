import java.util.Scanner;

public class Exercise_4_11a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a decimal number.
		System.out.print("Enter a decimal value (0 to 15) : ");
		int decimalValue = input.nextInt();
		String hexValue= " ";
		
		if(decimalValue <= 15 && decimalValue >= 0) {
			if(decimalValue < 10 && decimalValue >= 0)
				hexValue = String.valueOf(decimalValue);
			else if(decimalValue == 10)
				hexValue = "A";
			else if(decimalValue == 11)
				hexValue = "B";
			else if(decimalValue == 12)
				hexValue = "C";
			else if(decimalValue == 13)
				hexValue = "D";
			else if(decimalValue == 14)
				hexValue = "E";
			else
				hexValue = "F";
			System.out.print("The hex value is " + hexValue + ".");
		}
		else 
			System.out.print(decimalValue + " is an invalid input.");
		input.close();
	}

}

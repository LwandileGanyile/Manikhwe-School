import java.util.Scanner;

public class Exercise_4_11b {
	// Student A's solution doesn't take advantage of the ASCII codes.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a decimal number.
		System.out.print("Enter a decimal value (0 to 15) : ");
		int decimalValue = input.nextInt();
		String hexValue;
		
		if(decimalValue <= 15 && decimalValue >= 0) {
			if(decimalValue < 10 && decimalValue >= 0)
				hexValue = String.valueOf(decimalValue);
			else 
				hexValue = String.valueOf((char)(55+decimalValue));
			System.out.print("The hex value is " + hexValue + ".");
		}
		else 
			System.out.print(decimalValue + " is an invalid input.");
		input.close();
	}

}

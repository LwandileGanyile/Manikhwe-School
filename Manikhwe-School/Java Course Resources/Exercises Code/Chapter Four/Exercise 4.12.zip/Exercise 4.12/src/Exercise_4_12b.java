import java.util.Scanner;

public class Exercise_4_12b {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompt a user to enter a hex value.
		System.out.print("Enter a hex digit : ");
		String hexDigit = input.nextLine();
		
		if(hexDigit.length() != 1) 
			System.out.print(hexDigit + " is an invalid input.");
		else {
			if(Character.isLetter(hexDigit.charAt(0))) {
				if(hexDigit.charAt(0) <= 'F' && hexDigit.charAt(0) >= 'A')
					switch(hexDigit.charAt(0)) {
					case 'A' :
					System.out.print("The binary value is 1010.");
					break;
					case 'B' :
						System.out.print("The binary value is 1011.");
						break;
					case 'C' :
						System.out.print("The binary value is 1100.");
						break;
					case 'D' :
						System.out.print("The binary value is 1101.");
						break;
					case 'E' :
						System.out.print("The binary value is 1110.");
						break;
					default :
						System.out.print("The binary value is 1111.");
						break;
					}
				else
					System.out.print(hexDigit + " is an invalid input.");
			}
			else if(Character.isDigit(hexDigit.charAt(0))) {
				switch(hexDigit.charAt(0)) {
				case '1' : System.out.print("The binary value is 0001.");
					break;
				case '2' : System.out.print("The binary value is 0010.");
					break;
				case '3' : System.out.print("The binary value is 0011.");
					break;
				case '4' : System.out.print("The binary value is 0100.");
					break;
				case '5' : System.out.print("The binary value is 0101.");
					break;
				case '6' : System.out.print("The binary value is 0110.");
					break;
				case '7' : System.out.print("The binary value is 0111.");
					break;
				case '8' : System.out.print("The binary value is 1000.");
					break;
				case '9' : System.out.print("The binary value is 1001.");
					break;
				default : System.out.print("The binary value is 0000.");
					break;
				}
			}
		}
		

		input.close();
	}

}

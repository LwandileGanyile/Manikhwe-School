import java.util.Scanner;

public class Exercise_4_22a {
	/* Student A doesn't think about the possibility 
	 * of s2 having a greater length than s1.*/
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter the first string.
		System.out.print("Enter string s1 : ");
		String s1 = input.nextLine();
		
		// Prompts a user to enter the second string.
		System.out.print("Enter string s2 : ");
		String s2 = input.nextLine();
		
		if(s1.length() < s2.length()) {
			System.out.print("Error : Make sure s2 has a length less than that of s1.");
			System.exit(0);
		}
		
		if(s1.contains(s2))
			System.out.print(s2 + " is a substring of " + s1 + ".");
		else
			System.out.print(s2 + " is not a substring of " + s1 + ".");
			
		
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_4_22b {
	/* Student A validated unnecessarily.*/
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter the first string.
		System.out.print("Enter string s1 : ");
		String s1 = input.nextLine();
		
		// Prompts a user to enter the second string.
		System.out.print("Enter string s2 : ");
		String s2 = input.nextLine();
		
		if(s1.contains(s2))
			System.out.print(s2 + " is a substring of " + s1 + ".");
		else
			System.out.print(s2 + " is not a substring of " + s1 + ".");
			
		
		input.close();
	}

}

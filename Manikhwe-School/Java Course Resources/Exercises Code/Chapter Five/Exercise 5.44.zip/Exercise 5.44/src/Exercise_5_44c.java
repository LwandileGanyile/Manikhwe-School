import java.util.Scanner;

public class Exercise_5_44c {
	/* Student C realized that some of the code can be 
	 * replaced by a single line using a string builder.
	 * That way less variables will be used, thus less
	 * memory will be used.*/
	public static void main(String[] args) {

		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompt a user to enter a number.
		System.out.print("Enter an integer : ");
		short number = input.nextShort();
		
		/* Determines on which category does a 
		 * number belong to. 4-bits, 8-eight, 
		 * 12-bit or 16-bit.*/
		short category = 0;
		
		// Determines whether a number has been classified to number of bits representation.
		boolean categorized = false;
		
		// Bits representation
		String bits = "";
		
		// Starting index on the 16-bit string.
		int startingIndex = 15;
		
		// Deal will numbers that can be represented by four bits.
		for(int i = 0; i <= 3;i++)
			category += Math.pow(2, i);
		
		if(Math.abs(number) >= 0 && Math.abs(number) <= category) {
			bits += "000000000000";
			startingIndex = 3;
			categorized = true;
		}
		
		// Deal will numbers that can be represented by eight bits.
		for(int i = 4; i <= 7 && categorized==false;i++)
			category += Math.pow(2, i);
		
		if(number <= category && categorized==false) {
			bits += "00000000";
			startingIndex = 7;
			categorized = true;
		}
		
		// Deal will numbers that can be represented by twelve bits.
		for(int i = 8; i <= 11 && categorized==false;i++)
			category += Math.pow(2, i);
		
		if(number <= category && categorized==false) {
			bits += "0000";
			startingIndex = 11;	
		}
		
		// Hold to determine which bits are 1's and which ones are 0's.
		int sum = 0;
		
		// Deal with the bits of the sixteen bits starting from the left.
		for(int i = startingIndex; i >= 0;i--) {
			if(sum + Math.pow(2, i) <= Math.abs(number)) {
				sum += Math.pow(2, i);
				bits += "1";
			}
			else 
				bits += "0";
		}
		
	    // Deal with a negative number.
		if(number < 0) {
				
			// Represent the negation of a bits making up a number.
			String negatedBits = "";
					
			// Find the negation of bits representing a number.
			for(int i = 0; i < bits.length();i++) 
				if(bits.charAt(i) == '0')
					negatedBits += "1";
				else
					negatedBits += "0";
	
			// Represent a two's complement bits in a reverse order.
			String reversedTwosComplementBits = "";
					
			// Determines whether or not a one has been added to the negated bits.
			boolean isOneInserted = false;
			
			for(int bitIndex = negatedBits.length()-1; bitIndex >= 0; bitIndex--)
				if(negatedBits.charAt(bitIndex) == '0' && !isOneInserted) {
					reversedTwosComplementBits += 1;
					isOneInserted = true;
				}
				else if(negatedBits.charAt(bitIndex) == '1' && !isOneInserted)
					reversedTwosComplementBits += 0;
				else 
					reversedTwosComplementBits += negatedBits.charAt(bitIndex);
			
			 
			/* We don't need to create a variable to hold a string builder because 
			 * it is only used once. The reverse method defined in the string builder
			 * class returns a string builder, however we can a string from that 
			 * returned string builder using the to string method defined in the 
			 * string builder class.*/
			bits = new StringBuilder(reversedTwosComplementBits).reverse().toString();
			
		}
		System.out.print("Decimal value : " + number + " has a 16-bits value : " + bits);
		
		input.close();
	}
}

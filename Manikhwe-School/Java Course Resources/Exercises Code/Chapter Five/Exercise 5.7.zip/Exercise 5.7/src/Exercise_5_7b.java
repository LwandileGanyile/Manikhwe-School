
public class Exercise_5_7b {
	
	/*Student A's solution has variables with names, 
	 *that are hard to read. Further more to that
	 *the output is not user friendly.*/
	public static void main(String[] args) {
		
		final double INCREASE_RATE = 0.05;
		
		
		double currentYearTuition = 10000;
		int yearNumber = 0;
		
		do {
			
			yearNumber++;
			currentYearTuition = currentYearTuition + currentYearTuition*INCREASE_RATE;
			
		}while(yearNumber < 10);

		double tenthYearTuition = currentYearTuition;
		
		// Total tuition worth of four years after ten years.
		double totalTuition = 0;
		
		for(yearNumber = 1; yearNumber <= 4; yearNumber++) {
			currentYearTuition = currentYearTuition + currentYearTuition*INCREASE_RATE;
			totalTuition += currentYearTuition;
		}
		
		System.out.printf("The tuition fee after ten years is $%8.2f.\nThe four years' "
		+ "worth tuition after ten years is $%8.2f.", tenthYearTuition, totalTuition);
	}

}

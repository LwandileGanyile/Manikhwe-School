import java.util.Scanner;

public class Exercise_5_7c {
	/* Student C want a program to let the 
	 * user enter the increase rate and the 
	 * initial tuition fee. Student C also 
	 * realize that a for loop is a good 
	 * choice for computing the four years' 
	 * worth tuition.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an initial amount.
		System.out.print("Enter the initial tuition amount : ");
		double currentYearTuition = input.nextDouble();
		
		if(currentYearTuition <= 0) {
			System.out.print("Error : Make sure the tuition amount is greater than zero.");
			System.exit(0);
		}
	
		// Prompts a user to enter an initial amount.
		System.out.print("Enter year increase rate : ");
		double increaseRate = input.nextDouble()/100;
		
		if(increaseRate < 0) {
			System.out.print("Error : Make sure the year increase rate is at least zero.");
			System.exit(0);
		}
		
		int yearNumber = 0;
		
		do {
			
			yearNumber++;
			currentYearTuition = currentYearTuition + currentYearTuition*increaseRate;
			
		}while(yearNumber < 10);

		double tenthYearTuition = currentYearTuition;
		
		// Total tuition worth of four years after ten years.
		double totalTuition = 0;
		yearNumber = 1;
		
		while(yearNumber <= 4) {
			currentYearTuition = currentYearTuition + currentYearTuition*increaseRate;
			totalTuition += currentYearTuition;
			yearNumber++;
		}
		
		System.out.printf("The tuition fee after ten years is $%8.2f.\nThe four years' "
		+ "worth tuition after ten years is $%8.2f.", tenthYearTuition, totalTuition);
		
		input.close();
	}

}

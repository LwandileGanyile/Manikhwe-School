
public class Exercise_5_24c {
	// Student C realize that a for loop will do it.
	/* Student C also realize the importance of 
	 * descriptive variable names.*/
	public static void main(String[] args) {
		
		double sum = 0;
		
		for(int numerator = 1; numerator <= 97;numerator +=2) 
			sum += numerator/(numerator+2.0);
		
		System.out.print("The sum of the series is " + sum + ".");

	}

}

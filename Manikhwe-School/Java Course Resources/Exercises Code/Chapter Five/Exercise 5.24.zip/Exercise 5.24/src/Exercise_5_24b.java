
public class Exercise_5_24b {
	/* Student B realize that the solution 
	doesn't need two variables to hold a denominator 
	and a numerator. Instead a single variable is 
	effective and efficient.*/
	public static void main(String[] args) {
		
		double sum = 0;
		int i = 1;
		
		while( i <= 97) {
			sum += i/(i+2.0);
			i +=2;
		}
		System.out.print("The sum of the series is " + sum + ".");

	}

}

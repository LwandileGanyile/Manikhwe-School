
public class Exercise_5_24a {
	public static void main(String[] args) {
		
		double sum = 0;
		int denominator = 1;
		int numerator = 1;
		
		while( numerator <= 97 && denominator <= 99) {
			sum += numerator/(denominator+2.0);
			numerator += 2;
			denominator += 2;
		}
		System.out.print("The sum of the series is " + sum + ".");

	}

}

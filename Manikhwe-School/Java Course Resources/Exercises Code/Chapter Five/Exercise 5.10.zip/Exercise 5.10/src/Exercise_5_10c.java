
public class Exercise_5_10c {
	// Student C realize that there is no need for if else statements.
	public static void main(String[] args) {
		
		/* Used to determine whether a number should 
		 * be displayed on the current line or the new one.*/
		int count = 1;
		
		for(int number = 100; number <= 1000; number++) {
			if(number%5 == 0 && number%6 == 0) {
				System.out.print(number + ((count%10 ==0)?"\n":" " ));
				count++;
			}
		}
			
	}

}


public class Exercise_5_10b {
	/* Student B realize that a while loop is 
	 * not a good way to go. Furthermore to that 
	 * he realize there is no for the two constants.
	 * The space issue might be neglected for java
	 * programs, however it plays a huge for on other
	 * programming languages like C++.*/
	public static void main(String[] args) {
		
		/* Used to determine whether a number should 
		 * be displayed on the current line or the new one.*/
		int count = 1;
		
		for(int number = 100; number <= 1000; number++) {
			if(number%5 == 0 && number%6 == 0) {
				
				if(count%10 == 0)
					System.out.print(number + "\n");
				else
					System.out.print(number + " " );
				count++;
			}
		}
			
	}

}

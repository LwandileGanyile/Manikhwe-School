import java.util.Scanner;

public class Exercise_5_49c {
	/* Student B realize that using a while loop
	 * is not a good choice. Furthermore he realize, 
	 * the string output has to be user friendly.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a string work with.
		System.out.print("Enter a word or sentence : ");
		String userInput = input.nextLine();
		
		//The number of vowels in a string.
		int numberOfVowels = 0;
		
		//The number of consonants in a string.
		int numberOfConsonants = 0;
	
		for(int characterIndex = 0;characterIndex < userInput.length();characterIndex++) {
			char character = userInput.charAt(characterIndex);
			if(Character.isLetter(character)) {
				if(character == 'A' || character == 'a')
					numberOfVowels++;
				else if(character == 'E' || character == 'e')
					numberOfVowels++;
				else if(character == 'I' || character == 'i')
					numberOfVowels++;
				else if(character == 'O' || character == 'o')
					numberOfVowels++;
				else if(character == 'U' || character == 'u')
					numberOfVowels++;
				else
					numberOfConsonants++;
			}
		}
		
		System.out.print(userInput + " has ");
		
		if(numberOfVowels == 0)
			System.out.print("no vowels");
		else if(numberOfVowels == 1)
			System.out.print("only 1 vowel");
		else
			System.out.print(numberOfVowels + " vowels");
		
		System.out.print(" and ");
		
		if(numberOfConsonants == 0)
			System.out.print("no consonants.");
		else if(numberOfConsonants == 1)
			System.out.print("only 1 consonant.");
		else
			System.out.print(numberOfConsonants + " consonants.");

		input.close();
	}

}

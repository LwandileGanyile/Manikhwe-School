import java.util.Scanner;

public class Exercise_5_49a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a string work with.
		System.out.print("Enter a word or sentence : ");
		String userInput = input.nextLine();
		
		//The number of vowels in a string.
		int numberOfVowels = 0;
		
		//The number of consonants in a string.
		int numberOfConsonants = 0;
		
		int characterIndex = 0;
		
		while(characterIndex < userInput.length()) {
			char character = userInput.charAt(characterIndex);
			if(Character.isLetter(character)) {
				switch(String.valueOf(character).toUpperCase()) {
				case "A" : numberOfVowels++; break;
				case "E" : numberOfVowels++; break;
				case "I" : numberOfVowels++; break;
				case "O" : numberOfVowels++; break;
				case "U" : numberOfVowels++; break;
				default : numberOfConsonants++;
				}
			}
			
			characterIndex++;
		}
		
		System.out.println("Number of vowels : " + numberOfVowels);
		System.out.println("Number of consonants : " + numberOfConsonants);

		input.close();
	}

}

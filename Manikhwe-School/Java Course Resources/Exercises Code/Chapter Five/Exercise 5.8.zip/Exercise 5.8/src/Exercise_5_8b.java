import java.util.Scanner;

public class Exercise_5_8b {
	// Student A's solution has variable names that are not descriptive.
	// Secondly, student A did not border about the comments.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter the number of student.
		System.out.print("Enter number of students : ");
		int numberOfStudents = input.nextInt();
		
		// The name of a current high performing student.
		String highStudent = null;
		// The score of a current high performing student.
		double highScore = Double.MIN_VALUE;
		
		// Holds a list of student names.
		String studentNames = "";
		// Holds a list of student scores.
		String studentScores = ""; 
		
		// Create a list of student names and the one for student scores.
		while(numberOfStudents > 0) {
			System.out.print("Enter a student's name and score : ");
			studentNames += input.next() + " ";
			studentScores += input.next() + " ";
			numberOfStudents--;	
		}
		
		// Name of the current student.
		// We assign null to student name in order to avoid a compile error in line 63.
		String studentName = null;
		// Score of the current student.
		// We assign null to student score in order to avoid a compile error in line 64.
		double studentScore = Double.MIN_VALUE;
		
		while(studentNames.contains(" ") && studentScores.contains(" ")) {
			// Read the first name of the list of students.
			studentName = studentNames.substring(0,studentNames.indexOf(" "));
			// Read a student score from a list of students and convert it to a double.
			studentScore = Double.parseDouble(studentScores.substring(0,studentScores.indexOf(" ")));

			// Compare the current high performing student with a new student.
			if(highScore < studentScore) {
				highStudent = studentName;
				highScore = studentScore;
			}

			// Remove the first student name of the current list of student names.
			studentNames = studentNames.substring(studentNames.indexOf(" ")+1);
			// Remove the first student score of the current list of student scores.
			studentScores = studentScores.substring(studentScores.indexOf(" ")+1);

		}
				
		// Compare the last student's score with the current student one's score.
		if(highScore < studentScore) {
			highStudent = studentName;
			highScore = studentScore;
		}
		
		// Display the high performing student if exist.
		if(highStudent != null && highScore != Double.MIN_VALUE)
			System.out.print("\nStudent Name : " 
			+ highStudent + "\tHigh Score : " 
			+ highScore);
		else
			System.out.print("Error : Make sure there is at least one student "
			+ "and students all have both a name and a score.");
		 
		// Close a scanner
		input.close();
	}

}

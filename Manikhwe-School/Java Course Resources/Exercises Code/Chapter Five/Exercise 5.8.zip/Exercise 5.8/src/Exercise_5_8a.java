import java.util.Scanner;

public class Exercise_5_8a {
	// Student A's solution has variable name that are not descriptive.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter the number of student.
		System.out.print("Enter number of students : ");
		int numOfStu = input.nextInt();
		
		// The name of a current high performing student.
		String hStu = null;
		// The score of a current high performing student.
		double hScore = -100000000;
		
		// Holds a list of student names.
		String stuNames = "";
		// Holds a list of student scores.
		String stuScores = ""; 
		
		// Create a list of student names and the one for student scores.
		while(numOfStu > 0) {
			System.out.print("Enter a student's name and score : ");
			stuNames += input.next() + " ";
			stuScores += input.next() + " ";
			numOfStu--;	
		}
		
		// Name of the current student.
		// We assign null to student name in order to avoid a compile error in line 63.
		String stuName = null;
		// Score of the current student.
		// We assign null to student score in order to avoid a compile error in line 64.
		double stuScore = Double.MIN_VALUE;
		
		while(stuNames.contains(" ") && stuScores.contains(" ")) {
			// Read the first name of the list of students.
			stuName = stuNames.substring(0,stuNames.indexOf(" "));
			// Read a student score from a list of students and convert it to a double.
			stuScore = Double.parseDouble(stuScores.substring(0,stuScores.indexOf(" ")));

			// Compare the current high performing student with a new student.
			if(hScore < stuScore) {
				hStu = stuName;
				hScore = stuScore;
			}

			// Remove the first student name of the current list of student names.
			stuNames = stuNames.substring(stuNames.indexOf(" ")+1);
			// Remove the first student score of the current list of student scores.
			stuScores = stuScores.substring(stuScores.indexOf(" ")+1);

		}
				
		// Compare the last student's score with the current student one's score.
		if(hScore < stuScore) {
			hStu = stuName;
			hScore = stuScore;
		}
		
		// Display the high performing student if exist.
		if(hStu != null && hScore != Double.MIN_VALUE)
			System.out.print("\nStudent Name : " 
			+ hStu + "\tHigh Score : " 
			+ hScore);
		else
			System.out.print("Error : Make sure there is at least one student "
			+ "and students all have both a name and a score.");
		 
		// Close a scanner
		input.close();
	}

}

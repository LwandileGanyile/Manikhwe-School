import java.util.Scanner;

public class Exercise_5_8c {
	// Student B's solution is inefficient.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter the number of student.
		System.out.print("Enter number of students : ");
		int numberOfStudents = input.nextInt();
		
		String highStudent = null;
		double highScore = Double.MIN_VALUE;
		
		String studentName;
		double studentScore; 
		
		// Process each and every student.
		while(numberOfStudents > 0) {
			System.out.print("Enter a student's name and score : ");
			studentName = input.next();
			studentScore = input.nextDouble();
			
			if(studentScore < 0) {
				System.out.print("Try again : A mark cannot be negative.");
				System.exit(0);
			}
			
			if(studentName.length() == 0) {
				System.out.print("Try again : A name has to have at least one letter.");
				System.exit(1);
			}
			
			// Compare the current student's score with the current high score.
			if(highScore < studentScore) {
				highStudent = studentName;
				highScore = studentScore;
			}
			numberOfStudents--;	
		}
		
		// Display a student name with the high score if one exist.
		if(highStudent != null && highScore != Double.MIN_VALUE)
			System.out.print("\nStudent Name : " 
			+ highStudent + "\tHigh Score : " 
			+ highScore);
		else
			System.out.print("Error : Make sure there is at least one student "
			+ "and students all have both a name and a score.");
		
		input.close();
	}

}

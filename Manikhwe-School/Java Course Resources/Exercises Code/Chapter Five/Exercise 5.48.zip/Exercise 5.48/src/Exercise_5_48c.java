import java.util.Scanner;

public class Exercise_5_48c {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a string.
		System.out.print("Enter a word or a sentence : ");
		
		// Store user input.
		String userInput = input.nextLine();
		
		// Traverse user input and check each character whether or not it has to be displayed.
		for(int characterIndex = 0; characterIndex < userInput.length();characterIndex++)
			if((characterIndex+1)%2 != 0)
				System.out.print(userInput.charAt(characterIndex));
			
		// Close a scanner.
		input.close();
	}

}

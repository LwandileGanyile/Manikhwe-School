import java.util.Scanner;

public class Exercise_5_48a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a string.
		System.out.print("Enter a word or a sentence : ");
		
		// Store user input.
		String ui = input.nextLine();
		
		// The index of a current character plus one.
		int i = 1;
		
		// Traverse user input and check each character whether or not it has to be displayed.
		while( i < ui.length()) {
			if(i%2 != 0)
				System.out.print(ui.charAt(i-1));
			i++;
		}
			
		// Close a scanner.
		input.close();
	}

}

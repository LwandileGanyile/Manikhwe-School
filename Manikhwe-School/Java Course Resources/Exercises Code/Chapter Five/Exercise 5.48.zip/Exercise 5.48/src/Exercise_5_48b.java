import java.util.Scanner;

public class Exercise_5_48b {
	// Student B realize that it necessary to write a readable code.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a string.
		System.out.print("Enter a word or a sentence : ");
		
		// Store user input.
		String userInput = input.nextLine();
		
		// The index of a current character plus one.
		int index = 1;
		
		// Traverse user input and check each character whether or not it has to be displayed.
		while( index < userInput.length()) {
			if(index%2 != 0)
				System.out.print(userInput.charAt(index-1));
			index++;
		}
			
		// Close a scanner.
		input.close();
	}

}


public class Exercise_5_33a {

	public static void main(String[] args) {
		
		// Used to determine whether or not a number is a perfect number.
		int sumOfDivisors;
		
		for(int numberToCheck = 10000; numberToCheck >= 6; numberToCheck--) {
			sumOfDivisors = 0;
			for(int divisor = numberToCheck/2; divisor >= 1; divisor--) {
				if(numberToCheck%divisor == 0)
					sumOfDivisors += divisor;
			}
			
			if(numberToCheck == sumOfDivisors) 
				System.out.print(numberToCheck + "\t");
		}

	}

}

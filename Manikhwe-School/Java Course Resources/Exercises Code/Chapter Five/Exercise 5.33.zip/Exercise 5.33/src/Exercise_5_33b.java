
public class Exercise_5_33b {
	// Student A's solution is not user friendly.
	public static void main(String[] args) {
		
		// Used to determine whether or not a number is a perfect number.
		int sumOfDivisors;
		
		String perfectNumbers = "";
		
		for(int numberToCheck = 10000; numberToCheck >= 6; numberToCheck--) {
			sumOfDivisors = 0;
			for(int divisor = numberToCheck/2; divisor >= 1; divisor--) {
				if(numberToCheck%divisor == 0)
					sumOfDivisors += divisor;
			}
			
			if(numberToCheck == sumOfDivisors) {
				perfectNumbers += numberToCheck + "\t";
			}
		}
		
		System.out.println("Below is the list of perfect numbers less than 10000.");
		System.out.print("\t" + perfectNumbers);

	}

}


public class Exercise_5_33c {
	/* Student B's solution is inefficient.Student C 
	 * realize that once we find the forth 
	 * perfect number starting from 1, there is no 
	 * need to keep looking. Hence a while loop is used.*/
	public static void main(String[] args) {
		
		// Used to determine whether or not a number is a perfect number.
		int sumOfDivisors;
		
		// Count number of perfect numbers.
		int numberOfPerfectNumbers = 0;
		
		String perfectNumbers = "";
		
		final int MAXIMUM_BOUNDARY = 10000;
		
		int numberToCheck = 1; 
		
		while(numberToCheck <= MAXIMUM_BOUNDARY && numberOfPerfectNumbers < 4) {
			sumOfDivisors = 0;
			for(int divisor = numberToCheck/2; divisor >= 1; divisor--) {
				if(numberToCheck%divisor == 0)
					sumOfDivisors += divisor;
			}
			
			if(numberToCheck == sumOfDivisors) {
				perfectNumbers += numberToCheck + "\t";
				numberOfPerfectNumbers++;
			}
			
			numberToCheck++;
		}

		System.out.println("Below is the list of perfect numbers less than 10000.");
		System.out.print("\t" + perfectNumbers);
	}

}

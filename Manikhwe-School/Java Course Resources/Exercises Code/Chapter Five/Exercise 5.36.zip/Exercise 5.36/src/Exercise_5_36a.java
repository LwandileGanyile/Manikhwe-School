import java.util.Scanner;

public class Exercise_5_36a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.		
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter nine digits.
		System.out.print("Enter the first 9 digits of an ISBN as integer: ");
		
		// Store user input into a variable for later use.
		int userInput = input.nextInt();
		
		// We need to make sure we have a reference to the original user input.
		// We need this variable because the userInput will be altered later in a program.
		int originalISBN = userInput;
		
int sumOfProducts = 0; // (d1 * 1 + d2 * 2 + ...+d9 * 9)
		
		int i = 9; // Last digit multiplier.
		
		while( i > 1) {
			
			sumOfProducts += i*(userInput % 10);
			userInput /= 10;
			i--;
		}
	
		// We don't need the product using the first digit because it value is zero.
		
		// Holds the determiner value between 1 and 10.
		int determiner = sumOfProducts%11;
		
		System.out.print("The ISBN-10 number is 0" + originalISBN);
		
		if(determiner == 10)
			System.out.print("X");
		else
			System.out.print(determiner);
		
		// Close scanner
		input.close();
	}

}

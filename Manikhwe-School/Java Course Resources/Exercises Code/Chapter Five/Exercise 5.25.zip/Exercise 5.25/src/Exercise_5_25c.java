
public class Exercise_5_25c {
	// Student B used a wrong choice for the inner loop even though the solution is correct.
	public static void main(String[] args) {
		
		// Iterate for all i values (10000, 20000,...100000)
		for(int i = 10000; i <= 100000; i += 10000) {
			
			// The sum of the number inside bracket;
			double sum = 0;
			
			// Used to decide whether to add or subtract a quotient.
			int count = 1;
			
			// Iterate from 1, 3, 5...2*i
			for(int j = 1; j <= 2*i-1;j+=2) {
				
				if(j < 2*i-1) {
					if(count%2 == 0)
						sum -= 1.0/j; // Equivalent to sum = sum - 1/j.
					else 
						sum += 1.0/j; // Equivalent to sum = sum + 1/j.
				
					count++;
				}
				else
					sum += Math.pow(-1, i+1)/j;
			}
			
			System.out.println("The PI approximation for i = " + i + " is " + 4.0*sum);
		}

	}

}

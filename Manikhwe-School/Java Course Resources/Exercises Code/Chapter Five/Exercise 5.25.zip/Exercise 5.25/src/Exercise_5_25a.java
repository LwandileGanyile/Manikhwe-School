
public class Exercise_5_25a {

	public static void main(String[] args) {
		
		int i = 10000;
		// Iterate for all i values (10000, 20000,...100000)
		while(i <= 100000) {
			
			// The sum of the number inside bracket;
			double sum = 0;
			
			// Used to decide whether to add or subtract a quotient.
			int count = 1;
			int j = 1;
			
			// Iterate from 1, 3, 5...2*i
			while(j <= 2*i-1) {
				
				if(j < 2*i-1) {
					if(count%2 == 0)
						sum -= 1.0/j; // Equivalent to sum = sum - 1/j.
					else 
						sum += 1.0/j; // Equivalent to sum = sum + 1/j.
				
					count++;
				}
				else
					sum += Math.pow(-1, i+1)/j;
				j+=2;
			}
			
			System.out.println("The PI approximation for i = " + i + " is " + 4.0*sum);
			i += 10000;
		}

	}

}

import java.util.Scanner;

public class Exercise_5_30b {
	// Student A's solutions has variables that are less descriptive.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an amount.
		System.out.print("Enter an amount : ");
		double amount = input.nextDouble();
		
		// Prompts a user to enter an annual interest rate.
		System.out.print("Enter annual interest rate : ");
		double annualInterestRate = input.nextDouble();
		
		// Prompts a user to enter number of months.
		System.out.print("Enter number of month : ");
		int numberOfMonths = input.nextInt();
		
		// Avoid negative number of months.
		if(numberOfMonths < 0) {
			System.out.print("Try again : Make sure number of months is a positive number.");
			System.exit(2);
		}
		
		// We need to keep a copy of the initial amount.
		double initialAmount = amount;
		
		/* We initialize the final amount in order to 
		 * avoid a compile error in case the number of 
		 * months is zero.*/
		double finalAmount = amount;
		
		int monthNumber = 1;
		
		while(monthNumber <= numberOfMonths) {
			finalAmount = amount*(1 + (annualInterestRate/1200));
			amount = initialAmount + finalAmount;
			monthNumber++;
		}
		
		System.out.printf("The amount after %d %s is %6.3f", numberOfMonths,  (numberOfMonths > 1)? "months":"month", finalAmount);
		
		input.close();
	}
}

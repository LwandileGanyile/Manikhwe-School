import java.util.Scanner;

public class Exercise_5_30c {
	// Student B did not validate user input.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an amount.
		System.out.print("Enter an amount : ");
		double amount = input.nextDouble();
		
		// Avoid negative amount.
		if(amount < 0) {
			System.out.print("Try again : Make sure the amount is a positive number.");
			System.exit(0);
		}
		
		// Prompts a user to enter an annual interest rate.
		System.out.print("Enter annual interest rate : ");
		double annualInterestRate = input.nextDouble();
		
		// Avoid negative interest
		if(annualInterestRate < 0) {
			System.out.print("Try again : Make sure the interest rate is a positive number.");
			System.exit(1);
		}
		
		// Prompts a user to enter number of months.
		System.out.print("Enter number of month : ");
		int numberOfMonths = input.nextInt();
		
		// Avoid negative number of months.
		if(numberOfMonths < 0) {
			System.out.print("Try again : Make sure number of months is a positive number.");
			System.exit(2);
		}
		
		// We need to keep a copy of the initial amount.
		double initialAmount = amount;
		
		/* We initialize the final amount in order to 
		 * avoid a compile error in case the number of 
		 * months is zero.*/
		double finalAmount = amount;
		
		for(int monthNumber = 1; monthNumber <= numberOfMonths;monthNumber++) {
			finalAmount = amount*(1 + (annualInterestRate/1200));
			amount = initialAmount + finalAmount;
		}
		
		System.out.printf("The amount after %d %s is %6.3f", numberOfMonths,  (numberOfMonths > 1)? "months":"month", finalAmount);
		
		input.close();
	}
}

import java.util.Scanner;

public class Exercise_5_30a {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an amount.
		System.out.print("Enter an amount : ");
		double amt = input.nextDouble();
		
		// Prompts a user to enter an annual interest rate.
		System.out.print("Enter annual interest rate : ");
		double annIntRate = input.nextDouble();
		
		// Prompts a user to enter number of months.
		System.out.print("Enter number of month : ");
		int numOfMon = input.nextInt();
		
		// We need to keep a copy of the initial amount.
		double iAmount = amt;
		
		/* We initialize the final amount in order to 
		 * avoid a compile error in case the number of 
		 * months is zero.*/
		double fAmount = amt;
		
		int monNum = 1; 
		
		while(monNum <= numOfMon) {
			fAmount = amt*(1 + (annIntRate/100)/12);
			amt = iAmount + fAmount;
			monNum++;
		}
		
		System.out.print("The amount after " + numOfMon + ((numOfMon > 1)? "months":"month") + " is " + fAmount);
		
		input.close();
	}
}

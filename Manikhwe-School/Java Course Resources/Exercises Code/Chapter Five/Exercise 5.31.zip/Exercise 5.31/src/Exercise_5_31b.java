import java.util.Scanner;

public class Exercise_5_31b {
	// Student A's solutions has variables that are less descriptive.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an amount.
		System.out.print("Enter the initial deposit amount : ");
		double amount = input.nextDouble();
		
		// Prompts a user to enter an annual interest rate.
		System.out.print("Enter annual percentage yield : ");
		double annualInterestRate = input.nextDouble();
		
		// Prompts a user to enter number of months.
		System.out.print("Enter maturity period (number of months) : ");
		int numberOfMonths = input.nextInt();
		
		// Avoid negative number of months.
		if(numberOfMonths < 0) {
			System.out.print("Try again : Make sure number of months is a positive number.");
			System.exit(2);
		}

		/* We initialize the final amount in order to 
		 * avoid a compile error in case the number of 
		 * months is zero.*/
		double finalAmount = amount;
		
		int monthNumber = 1;
		
		System.out.println("\nMonth\tCD Value");
		while(monthNumber <= numberOfMonths) {
			finalAmount = amount+amount*annualInterestRate/1200;
			System.out.printf("%d\t%5.2f\n", monthNumber, finalAmount);
			amount = finalAmount;
			monthNumber++;
		}
		
		
		input.close();
	}
}

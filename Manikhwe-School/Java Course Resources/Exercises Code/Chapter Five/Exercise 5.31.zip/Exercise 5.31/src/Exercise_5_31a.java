import java.util.Scanner;

public class Exercise_5_31a {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an amount.
		System.out.print("Enter the initial deposit amount : ");
		double amt = input.nextDouble();
		
		// Prompts a user to enter an annual interest rate.
		System.out.print("Enter annual percentage yield : ");
		double annIntRate = input.nextDouble();
		
		// Prompts a user to enter number of months.
		System.out.print("Enter maturity period (number of months) : ");
		int numOfMon = input.nextInt();
		
		/* We initialize the final amount in order to 
		 * avoid a compile error in case the number of 
		 * months is zero.*/
		double fAmount = amt;
		
		int monNum = 1; 
		
		System.out.println("\nMonth\tCD Value");
		while(monNum <= numOfMon) {
			fAmount = amt+amt*annIntRate/1200;
			System.out.printf("%d\t%5.2f\n", monNum, fAmount);
			amt = fAmount;
			monNum++;
		}
	
		input.close();
	}
}

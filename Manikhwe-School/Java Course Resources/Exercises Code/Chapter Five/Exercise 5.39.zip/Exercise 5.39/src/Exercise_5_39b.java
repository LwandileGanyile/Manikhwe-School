
public class Exercise_5_39b {

	public static void main(String[] args) {
		
		final double FIRST_COMMISSION_RATE = 0.08;
		final double SECOND_COMMISSION_RATE = 0.1;
		final double THIRD_COMMISSION_RATE = 0.12;
		
		double salesAmount  = 0;
		double commissionAmount = 0;
		
		do {
				
			if(salesAmount <= 5000 && salesAmount >= 0.01)
				commissionAmount = salesAmount* FIRST_COMMISSION_RATE;
			else if(salesAmount <= 10000 && salesAmount >= 5000.01)
				commissionAmount = 5000* FIRST_COMMISSION_RATE + 
				(salesAmount-5000)*SECOND_COMMISSION_RATE;
			else 
				commissionAmount = 5000* FIRST_COMMISSION_RATE + 
				5000*SECOND_COMMISSION_RATE +
				(salesAmount-10000)*THIRD_COMMISSION_RATE;
			salesAmount += 0.01;
		}while(commissionAmount < 30000);
		System.out.print("The minimun sales amount needed to earn a commission of $30000 is $" + (salesAmount-0.01));
	}

}

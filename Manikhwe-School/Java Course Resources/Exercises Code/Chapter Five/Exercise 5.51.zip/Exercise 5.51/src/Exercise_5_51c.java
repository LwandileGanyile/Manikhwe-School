import java.util.Scanner;

public class Exercise_5_51c {

	public static void main(String[] args) {
		/* Firstly student A did not realize that a minimum 
		 * length of the two strings is the only thing that 
		 * is needed, hence the minimum length can be stored 
		 * in a variable.
		 * Secondly, student A used a for loop as if he knows 
		 * in advance the number of times a loop will execute.*/
		Scanner input = new Scanner(System.in);
		
		// Prompts the user to enter the first sentence/word.
		System.out.print("Enter the first string : ");
		String firstString = input.nextLine();
		
		// Prompts the user to enter the second sentence/word.
		System.out.print("Enter the second string : ");
		String secondString = input.nextLine();
		
		// Common prefix
		String commonPrefix = "";
		
		int minumuLength = (firstString.length() < secondString.length())? 
		firstString.length() : secondString.length();
		
		// Index of current letters to be compared.
		int index = 0;
		
		while(index < minumuLength && 
		firstString.charAt(index) == secondString.charAt(index)) 		
			commonPrefix += firstString.charAt(index++);
		
		
		if(commonPrefix.length() == 0)
			System.out.print(firstString + " and " + secondString + " have no common prifix.");
		else 
			System.out.print("The common prefix is " + commonPrefix);
		
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_5_51a {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompts the user to enter the first sentence/word.
		System.out.print("Enter the first string : ");
		String firstString = input.nextLine();
		
		// Prompts the user to enter the second sentence/word.
		System.out.print("Enter the second string : ");
		String secondString = input.nextLine();
		
		// Common prefix
		String commonPrefix = "";
		
		// Index of current letters to be compared.
		int index = 0;
		
		for(index = 0; index < firstString.length() && index < secondString.length() 
		&& firstString.charAt(index)==secondString.charAt(index);) 	
			commonPrefix += firstString.charAt(index++);
		
		if(commonPrefix.length() == 0)
			System.out.print(firstString + " and " + secondString + " have no common prifix.");
		else 
			System.out.print("The common prefix is " + commonPrefix);
		
		input.close();
	}

}


public class Exercise_5_6a {
	
	public static void main(String[] args) {
		
		final double KILOMETERS_PER_MILE = 1.609;
		final int MAXIMUM_MILES = 10;
		final int MAXIMUM_KILOMETERS = 65;
		
		int fromKilometers = 20;
		double toKilometers;
		
		int fromMiles = 1;
		double toMiles;
		
		System.out.println("Miles\tKilometers\t|\tKilometers\tMiles");
		
		do {
			toMiles = fromMiles*KILOMETERS_PER_MILE;
			toKilometers = fromKilometers/KILOMETERS_PER_MILE;
			System.out.printf("%d\t\t%5.3f\t|\t%d\t%6.3f\n", fromMiles,toMiles,fromKilometers,toKilometers);
			
			fromKilometers += 5;
			fromMiles += 1;
			
		}while(fromMiles <= MAXIMUM_MILES && fromKilometers <= MAXIMUM_KILOMETERS);
	}

}

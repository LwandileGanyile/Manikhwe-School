import java.util.Scanner;

public class Exercise_5_6c {
	/* Student C want the number of kilograms 
	 * and grams to convert to be dynamic.*/
	public static void main(String[] args) {
		
		final double MILES_PER_KILOMETER = 1.609;
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter minimum and maximum kilometers to convert.
		System.out.print("Enter minimum and maximum kilometers to convert : ");
		int minimumKilometers = input.nextInt();
		int maximumKilometers = input.nextInt();
		
		if(minimumKilometers > maximumKilometers) {
			System.out.print("Error : Make sure that minimum kilometers to convert is less than maximum kilometers to convert.");
			System.exit(0);
		}
		
		if(minimumKilometers < 0){
			System.out.print("Error : Make sure that minimum kilometers to convert is atleast zero.");
			System.exit(1);
		}
			
		
		double toKilometers;
		
		// Prompts a user to enter minimum and maximum pounds to convert.
		System.out.print("Enter minimum and maximum miles to convert : ");
		int minimumMiles = input.nextInt();
		int maximumMiles = input.nextInt();
		
		if(minimumMiles > maximumMiles) {
			System.out.print("Error : Make sure that minimum miles to convert is less than maximum pounds to convert.");
			System.exit(2);
		}
		
		if(minimumMiles < 0) {
			System.out.print("Error : Make sure that minimum miles to convert is atleast zero.");
			System.exit(3);
		}
		
		double toMiles;
		
		System.out.println("\nMiles\tKilometers\t|\tKilometers\tMiles");
		
		/* Note if the number of conversions from kilograms to 
		 * pounds and pounds to kilograms is not the same. Some 
		 * of the conversions will not be performed.*/
		do {
			toKilometers = minimumKilometers/MILES_PER_KILOMETER;
			toMiles = minimumMiles*MILES_PER_KILOMETER;
			System.out.printf("%d\t%5.3f\t\t|\t%d\t\t%6.3f\n",minimumMiles,toMiles, minimumKilometers,toKilometers);
			
			minimumKilometers += 5;
			minimumMiles += 1;
			
		}while(minimumMiles <= maximumMiles && minimumKilometers <= maximumKilometers);
		
		input.close();
	}

}

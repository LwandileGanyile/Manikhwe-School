
public class Exercise_5_12b {

	/* Student A did not use descriptive names for variables.*/
	public static void main(String[] args) {
		
		// A number we are looking for.
		int number = 1;
		
		// The number we are looking for to the exponent of three.
		int nCube = (int)Math.pow(number,2);
	
		final int MAXIMUM = 12000;
		
		while(nCube < MAXIMUM) {
			number = number +1;
			nCube = (int)Math.pow(number,2);
		}
		
		System.out.print("The value of n is " + 
		number + " and n cube is " + (int)Math.pow(number, 2) + ".");
	}

}

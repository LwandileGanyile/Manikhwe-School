
public class Exercise_5_12a {

	public static void main(String[] args) {
		
		// The number we looking for.
		int n = 1;
		// The number we looking for to the exponent of three.
		int nc = (int)Math.pow(n,2);
	
		final int MAX = 12000;
		
		while(nc < MAX) {
			n = n +1;
			nc = (int)Math.pow(n,2);
		}
		
		System.out.print("The value of n is " + 
		n + " and n cube is " + (int)Math.pow(n, 2) + ".");
	}

}

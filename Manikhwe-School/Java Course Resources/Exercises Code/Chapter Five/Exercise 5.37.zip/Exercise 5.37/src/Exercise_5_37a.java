import java.util.Scanner;

public class Exercise_5_37a {
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a number to convert.
		System.out.print("Enter a decimal number : ");
		
		// Decimal number.
		int dec = input.nextInt();
		
		// We need to keep a copy of the user input for later use.
		// This is because the user input will be modified.
		int decCopy = dec;
		
		if(dec < 0) {
			System.out.print("Try again : The application only convert positive decimal numbers.");
			System.exit(0);
		}
		
		// Used to store zero's and one's of a decimal number in a reverse order.
		String revBits = "";
		
		// Remainder of a current number divided by 2, it's either zero or one.
		int rem;
		
		while(dec>0) {
			rem = dec%2;
			revBits += rem;
			dec = dec/2;
			
		}
		// Converted decimal to binary.
		String toBinary = "";
		
		for(int i = revBits.length()-1; i >=0 ; i--)
			toBinary += revBits.charAt(i);
		
		System.out.print("Decimal : " + decCopy + "\tBinary Number : " + toBinary);
		
		input.close();
	}

}

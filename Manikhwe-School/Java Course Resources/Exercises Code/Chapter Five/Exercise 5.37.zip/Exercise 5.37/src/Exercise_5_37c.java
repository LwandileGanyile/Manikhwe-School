import java.util.Scanner;

public class Exercise_5_37c {
	/* Student C uses a string builder, 
	 * a class which is more flexible that 
	 * a string class.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a number to convert.
		System.out.print("Enter a decimal number : ");
		int decimalNumber = input.nextInt();
		
		// We need to keep a copy of the user input for later use.
		// This is because the user input will be modified.
		int originalDecimalNumber = decimalNumber;
		
		if(decimalNumber < 0) {
			System.out.print("Try again : The application only convert positive decimal numbers.");
			System.exit(0);
		}
		
		// Used to store zero's and one's of a decimal number in a reverse order.
		String reversedBinary = "";
		
		// Remainder of a current number divided by 2, it's either zero or one.
		byte remainder;
		
		do {
			remainder = (byte) (decimalNumber%2);
			reversedBinary += remainder;
			decimalNumber /= 2;
			
		}while(decimalNumber>0);
		
		// Strings are immutable, so we create a string builder to easily work with strings.
		StringBuilder stringBuilder = new StringBuilder(reversedBinary);
		
		String decimalToBinary = stringBuilder.reverse().toString();
		
		System.out.print("Decimal : " + originalDecimalNumber + "\tBinary Number : " + decimalToBinary);
		
		input.close();
	}

}

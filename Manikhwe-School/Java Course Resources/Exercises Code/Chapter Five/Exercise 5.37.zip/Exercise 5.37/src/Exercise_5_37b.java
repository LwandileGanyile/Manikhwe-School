import java.util.Scanner;

public class Exercise_5_37b {
	/* Student B realize that the remainder 
	 * has to be store in a byte data type 
	 * in order to save memory space. Furthermore,
	 * student B realize that a do while loop is
	 * a good choice for this problem. It hard to
	 * read student A's solution.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter a number to convert.
		System.out.print("Enter a decimal number : ");
		int userInput = input.nextInt();
		
		// We need to keep a copy of the user input for later use.
		// This is because the user input will be modified.
		int userInputCopy = userInput;
		
		if(userInput < 0) {
			System.out.print("Try again : The application only convert positive decimal numbers.");
			System.exit(0);
		}
		
		// Used to store zero's and one's of a decimal number in a reverse order.
		String reversedBinary = "";
		
		// Remainder of a current number divided by 2, it's either zero or one.
		byte remainder;
		
		do {
			remainder = (byte) (userInput%2);
			reversedBinary += remainder;
			userInput /= 2;
			
		}while(userInput>0);
		
		String toBinary = "";
		
		for(int bitIndex = reversedBinary.length()-1; bitIndex >=0 ; bitIndex--)
			toBinary += reversedBinary.charAt(bitIndex);
		
		System.out.print("Decimal : " + userInputCopy + "\tBinary Number : " + toBinary);
		
		input.close();
	}

}

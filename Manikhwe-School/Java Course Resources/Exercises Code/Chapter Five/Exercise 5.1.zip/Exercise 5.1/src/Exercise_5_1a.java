import java.util.Scanner;

public class Exercise_5_1a {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a sequence of number.
		System.out.print("Enter an integer, the input ends if it is 0 : ");
		String sequence = input.nextLine();
		
		if(sequence.length() == 1 && sequence.endsWith("0")) {
			System.out.print("No numbers are entered except 0.");
			System.exit(1);
		}
			
		
		
		// Get a current number read from a string using a scanner.
		double number;
		
		// The number of positive numbers in a sequence of numbers.
		int numberOfPositiveNumbers = 0;
		// The number of negative numbers in a sequence of numbers.
		int numberOfNegativeNumbers = 0;	
		
		// The sum of all numbers.
		double total = 0;
		
		// The number of numbers in a sequence.
		int numberOfNumbers = 0;
		
		while(sequence.contains(" ")) {
			
			number = Double.parseDouble(sequence.substring(0, sequence.indexOf(" ")));
			sequence = sequence.substring(sequence.indexOf(" ") + 1);
			
			if(number < 0)
				numberOfNegativeNumbers++;
			else if(number > 0)
				numberOfPositiveNumbers++;
			
			total += number;
			numberOfNumbers++;
		}
		
		System.out.println("The number of positive is " + numberOfPositiveNumbers);
		System.out.println("The number of negative is " + numberOfNegativeNumbers);
		System.out.println("The total is " + total);
		System.out.printf("The average is %5.2f", total/numberOfNumbers);
		
		input.close();
		
	}

}

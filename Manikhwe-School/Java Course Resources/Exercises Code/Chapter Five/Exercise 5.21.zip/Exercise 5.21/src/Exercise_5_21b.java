import java.util.Scanner;

public class Exercise_5_21b {
	// Student A doesn't validate user input well.
	public static void main(String[] args) {
		// Create a Scanner
		Scanner input = new Scanner(System.in);
		
		// Obtain monthly interest rate
		double monthlyInterestRate;
		
		// Enter loan amount
		System.out.print("Loan amount : ");
		double loanAmount = input.nextDouble();
		
		if(loanAmount <=0) {
			System.out.print("Error : Loan amount "
			+ "cannot be less or equal to zero.");
			System.exit(0);
		}
		
		// Enter number of years
		System.out.print(
		"Number of years : ");
		int numberOfYears = input.nextInt();
		
		if(numberOfYears <=0) {
			System.out.print("Error : Number of years "
			+ "cannot be less or equal to zero.");
			System.exit(1);
		}
		
		// Used to calculate monthly payment.
		double monthlyPayment;
		// Used to calculate total payment.
		double totalPayment;
		
		// Used to hold annual interest rate.
		double annualInterestRate = 5.0;
		   
		System.out.println("\nInterest Rate\t\tMonthly Payment\t\tTotal Payment");
		
		while(annualInterestRate <= 8) {
			
			monthlyInterestRate = annualInterestRate / 1200;
			monthlyPayment = loanAmount * monthlyInterestRate / (1
			- 1 / Math.pow(1 + monthlyInterestRate, numberOfYears * 12));
			totalPayment = monthlyPayment*numberOfYears*12;
			
			System.out.printf("%5.3f%s\t\t\t%6.2f\t\t\t%5.2f\n",annualInterestRate,"%",monthlyPayment,totalPayment);
			annualInterestRate += 0.125;
		}
		
		input.close();
	}
}
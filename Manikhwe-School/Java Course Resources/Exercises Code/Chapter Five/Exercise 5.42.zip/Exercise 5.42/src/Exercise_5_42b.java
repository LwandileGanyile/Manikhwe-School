import java.util.Scanner;

public class Exercise_5_42b {

	public static void main(String[] args) {
		
		// Create scanner a scanner to read a user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts the user to enter all three commission rate.
		System.out.print("Enter all three commission rates sepated by white spaces : ");
		
		double firstCommissionRate = input.nextDouble();
		double secondCommissionRate = input.nextDouble();
		double thirdCommissionRate = input.nextDouble();
		
		if(firstCommissionRate < 0 || secondCommissionRate < 0 
		|| thirdCommissionRate < 0) {
			System.out.print("Error : Make sure your commission rates are non negetive.");
			System.exit(0);
		}
			
		double salesAmount  = 0;
		double commissionAmount = 0;

		for(;commissionAmount < 30000;) {
				
			if(salesAmount <= 5000 && salesAmount >= 0.01)
				commissionAmount = salesAmount*firstCommissionRate;
			else if(salesAmount <= 10000 && salesAmount >= 5000.01)
				commissionAmount = 5000*firstCommissionRate + 
				(salesAmount-5000)*secondCommissionRate;
			else 
				commissionAmount = 5000*firstCommissionRate + 
				5000*secondCommissionRate +
				(salesAmount-10000)*thirdCommissionRate;
			salesAmount += 0.01;
		}
		System.out.print("The minimun sales amount needed to earn a commission of $30000 is $" + (salesAmount-0.01));
		
		input.close();
	}

}


public class Exercise_5_43b {
	/*Student B realize a while loop is a bad choice.*/
	public static void main(String[] args) {

		int secondNumber;
		int count = 0;
		
		for(int firstNumber = 1;firstNumber <= 7;firstNumber++) {
			for(secondNumber = 1; secondNumber <=7;secondNumber++) {			
				if(firstNumber < secondNumber) {
					System.out.println(firstNumber + " " + secondNumber);
					count++;
				}
			}
		}

		System.out.println("\nThe total number of all combinations is " + count);
	}

}

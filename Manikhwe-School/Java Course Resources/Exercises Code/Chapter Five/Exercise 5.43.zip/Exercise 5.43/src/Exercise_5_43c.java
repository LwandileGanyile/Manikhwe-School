
public class Exercise_5_43c {
	/*Student C realize that the inner loop don't 
	 * have to start from zero, thus there won't be 
	 * a need to use an if statement inside a loop.*/
	public static void main(String[] args) {

		int secondNumber;
		int count = 0;
		
		for(int firstNumber = 1;firstNumber <= 7;firstNumber++) {
			for(secondNumber = firstNumber + 1; secondNumber <=7;secondNumber++) {			
				System.out.println(firstNumber + " " + secondNumber);
				count++;
			}
		}

		System.out.println("\nThe total number of all combinations is " + count);
	}

}


public class Exercise_5_43a {

	public static void main(String[] args) {
		
		int firstNumber = 1;
		int secondNumber;
		int count = 0;
		
		while(firstNumber <= 7) {
			secondNumber =  1;
			while(secondNumber <=7) {			
				if(firstNumber < secondNumber) {
					System.out.println(firstNumber + " " + secondNumber);
					count++;
				}
				secondNumber++;
			}
			
			firstNumber++;
		}

		System.out.println("\nThe total number of all combinations is " + count);
	}

}

import java.util.Scanner;

public class Exercise_5_47a {
	// Student B used more variables than needed.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter an ISBN-13 number.
		System.out.print("Enter the first 12 digits of an ISBN-13 as a string : ");
		
		// Store user input.
		String ISBN = input.nextLine();
		
		// Determines whether or not all characters a digits.
		boolean areAllDigits = true;
		
		if(ISBN.length() == 12) {
			int characterIndex;
			for(characterIndex = 0;characterIndex < ISBN.length();
			characterIndex++) {
				if(!Character.isDigit(ISBN.charAt(characterIndex)))
					areAllDigits = false;
			}
			
			if(characterIndex != 12 || !areAllDigits) {
				System.out.print(ISBN + " is an invalid input.");
				System.exit(0);
			}
			
			// The determinant.
			int lastDigit;
			// The sum of all numbers inside the curly brackets.
			int sum = 0;
			// The variable for the expression to the right of the minus sign.
			int term;
			
			
			for(characterIndex = 0; characterIndex < ISBN.length();characterIndex++)
				if(characterIndex%2 == 1)
					sum += 3*Integer.parseInt(String.valueOf(ISBN.charAt(characterIndex)));
				else
					sum += Integer.parseInt(String.valueOf(ISBN.charAt(characterIndex)));
			
			term = sum % 10;
			lastDigit = 10 - term;
			
			System.out.print("The ISBN-13 number is " + ISBN + ((lastDigit != 10)? lastDigit: 0));
		}
		else 
			System.out.print(ISBN + " is an invalid input.");
	
		input.close();
	}

}

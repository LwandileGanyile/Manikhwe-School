import java.util.Scanner;

public class Exercise_5_29c {

	/* Student C realize that the switch statement 
	 * for determining the starting index and number
	 * of spaces preceding day 1 can be replaced by 
	 * single line and a loop.*/
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter year : ");
		int year = input.nextInt();
		
		if(year < 0) {
			System.out.print("Error : Make sure the year is not negetive.");
			System.exit(0);
		}
		
		System.out.print("Enter day(1-7) : ");
		int day = input.nextInt();
		
		if(day < 1 || day>7) {
			System.out.print("Error : Make sure the day is between 1-7.");
			System.exit(1);
		}
		
		String monthName;
		
		for(int month = 1; month <= 12; month++) {
	
			switch(month) {
			case 1 :monthName = "January";break;
			case 2 :monthName = "February";break;
			case 3 :monthName = "March";break;
			case 4 :monthName = "April";break;
			case 5 :monthName = "May";break;
			case 6 :monthName = "June";break;
			case 7 :monthName = "July";break;
			case 8 :monthName = "August";break;
			case 9 :monthName = "September";break;
			case 10 :monthName = "October";break;
			case 11 :monthName = "November";break;
			default :monthName = "December";break;
			}
			
			System.out.println("\n  \t\t" + monthName + " " + year);
			System.out.println("-----------------------------------------------------");
			System.out.println("Sun\tMon\tTue\tWed\tThu\tFri\tSurt\n");
			
			// Days for the current month to display on a console.
			String days = "";
			
			// Used to keep track of the location of the 1st for the current month.
			int startingIndex = (day < 7)? day:0;
			
			// Used to leave an appropriate number of spaces before day 1 of the month.
			for(int numberOfTabs = 0; numberOfTabs < startingIndex; numberOfTabs++)
				days += "\t";
			
			// Used to keep track of the last day of the current month.
			int lastDayOfMonth;
			
			
			if(month==1 || month==3 || month==5 || 
			month==7 || month==8 || month==10 || month==12) 
				lastDayOfMonth = 31;	
			else if(month==2) 
				if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) 
					lastDayOfMonth = 29;	
				else 
					lastDayOfMonth = 28;
			else
				lastDayOfMonth = 30;
			
			// The days of the month, 1st, 2nd,...
			int dayOfMonth;
			
			for(dayOfMonth = 1;dayOfMonth <= lastDayOfMonth;dayOfMonth++, startingIndex++)
				days = days + dayOfMonth + (((startingIndex+1)%7==0)?"\n":"\t");
			
			System.out.println(days + "\n");
			day = 1 + (day +lastDayOfMonth-1)%7;
		}
		
		input.close();
	}

	

}


public class Exercise_5_19a {

	public static void main(String[] args) {
		
		final int NUMBER_OF_LINES = 8;
		int leftExponent;
		int rightExponent;
		
		/* Row 0 correspond to line 1, in general row i correspond 
		 * to line i plus 1.*/
		for(int row = 0; row < NUMBER_OF_LINES; row++) {
			leftExponent = 0;
			rightExponent = -1; // Initialized to avoid a compile error.
			/* Taking the center as a point of reference. We are concern 
			 * with a certain equal number of numbers to the left 
			 * and right of the center.*/
			for(int column = -NUMBER_OF_LINES+1; column < NUMBER_OF_LINES;column++) {
				/* The first line is a special case. It only has one number(1).*/
				/* When done printing numbers to the left of the middle number 
				 * inclusively,assign the left exponent to the right exponent.*/
				// Print the middle number of a line.
				if(column==0) {
					System.out.print((int)Math.pow(2,leftExponent)+ "\t");
					
					if(row==0)
						break;
					else {
						rightExponent = leftExponent;
						System.out.print((int)Math.pow(2,--rightExponent) + "\t");
					}
				}
				/* Line 2 example : we are concern with 2 1 2. So the inner loop 
				 * is active for the three numbers only. However it treats the numbers
				 * to the left of 1 as negative numbers inclusively. When it prints 
				 * though, it print them as positive numbers*/
				
				else if(row != 0 && column>-row-1 && column<row+1) {
					// Numbers to the right of the reference position(1).
					if(column > 0) {
						// Make sure you end with a last number of a line being 1.
						if(rightExponent==0)
							break;
						System.out.print((int)Math.pow(2,--rightExponent) + "\t");
					}
					// Numbers to the left of the reference position(1).
					else if(column < 0)
						System.out.print((int)Math.pow(2, leftExponent++) + "\t");
				}
				else
					// Leave enough space if there is no number to display.
					/* It is necessary to use not just a space or two, because
					 * if you do, the output won't look good.*/
					System.out.print("\t");
			}
			System.out.println();
		}
		
	}
}

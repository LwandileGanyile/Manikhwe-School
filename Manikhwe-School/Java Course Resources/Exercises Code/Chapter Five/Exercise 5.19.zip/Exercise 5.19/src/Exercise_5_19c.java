
public class Exercise_5_19c {

	public static void main(String[] args) {
		
		final int NUMBER_OF_LINES = 8;
		
							
		/* Row 0 correspond to line 1, in general row i correspond 
		* to line i plus 1.*/
		for(int row = 0; row < NUMBER_OF_LINES; row++) {	
			int exponent = 0;
			// Display left hand side of a line excluding 1.
			for(int leftIndex = NUMBER_OF_LINES; leftIndex > 1; leftIndex--) 
				if(leftIndex <= row + 1 )
					System.out.print((int)Math.pow(2, exponent++) + "\t");
				else
					System.out.print("\t");
			// Display right hand side of a line starting from 1.
			for(int rightIndex = 1; rightIndex <= row + 1; rightIndex++) 
				System.out.print((int)Math.pow(2, exponent--) + "\t");
							
			System.out.println();
				}
	}

}

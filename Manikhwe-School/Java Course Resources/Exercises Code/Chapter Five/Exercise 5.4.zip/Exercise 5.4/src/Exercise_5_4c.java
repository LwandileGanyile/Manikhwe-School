
public class Exercise_5_4c {
	// Student C realize that a variable miles contains values between -127 and 128.
	public static void main(String[] args) {
		
		final double KILOMETERS_PER_MILE = 1.609;
		
		
		byte miles = 1;
		
		System.out.println("Miles\t\tKilometers");
		for(miles = 1;miles <= 10;miles++) 
			System.out.printf("%d\t\t%5.3f\n",miles,miles*KILOMETERS_PER_MILE);
	}

}

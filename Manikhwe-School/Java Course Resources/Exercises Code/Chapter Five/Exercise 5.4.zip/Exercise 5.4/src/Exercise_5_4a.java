
public class Exercise_5_4a {

	public static void main(String[] args) {
		
		final double KILOMETERS_PER_MILE = 1.609;
		
		
		int miles = 1;
		
		System.out.println("Miles\t\tKilometers");
		while(miles <= 10) {
			System.out.printf("%d\t\t%5.3f\n",miles,miles*KILOMETERS_PER_MILE);
			miles++;
		}

	}

}

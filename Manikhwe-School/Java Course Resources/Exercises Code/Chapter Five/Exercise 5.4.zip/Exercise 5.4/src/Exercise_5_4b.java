
public class Exercise_5_4b {
	// Student B realize that a for loop is a good choice than a while loop.
	public static void main(String[] args) {
		
		final double KILOMETERS_PER_MILE = 1.609;
		
		
		int miles = 1;
		
		System.out.println("Miles\t\tKilometers");
		for(miles = 1;miles <= 10;miles++) 
			System.out.printf("%d\t\t%5.3f\n",miles,miles*KILOMETERS_PER_MILE);
	}

}

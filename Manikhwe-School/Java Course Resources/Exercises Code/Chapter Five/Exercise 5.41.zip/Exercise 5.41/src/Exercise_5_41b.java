import java.util.Scanner;

public class Exercise_5_41b {
	/* Student A's solution did not take care 
	 * of numbers with more than one digit.
	 * Student A's solution doesn't do validation
	 * completely. Student A's solution doesn't 
	 * consider possible white spaces be for the
	 * first number of the sequence.*/
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompt a user to enter a sequence of numbers.
		System.out.print("Enter numbers : ");
		// Hold the current sequence.
		// Make sure we eliminate any white spaces before and after the sequence.
		String sequence = input.nextLine().trim();
		
		
		// Validate user input.
		if(sequence.length() >= 2 && sequence.contains(" ") && sequence.charAt(sequence.length()-1) == '0') {
			// Index of a current character.
			int index = 0;
	
			while(sequence.charAt(++index) != '0') {
				if(!Character.isDigit(sequence.charAt(index))  && sequence.charAt(index) != ' ' ) {
					System.out.print("Error : Make sure a sequence is made up of numbers only.");
					System.exit(0);
				}
			}
		}
		
		// Count the number of occurrence of a maximum number.
		int count = 0;
		// Maximum of the sequence.
		int max = Integer.parseInt(sequence.substring(0, sequence.indexOf(" ")));
		
		int number;

		do{
			
			number = Integer.parseInt(sequence.substring(0, sequence.indexOf(" ")));
			
			if(max < number) {
				max = number;
				count = 1;
			}
			else if(max == number)
				count++;
			
			if(sequence.contains(" "))
				sequence = sequence.substring(sequence.indexOf(" ")+1);
			else 
				sequence = "0";
		}while(!sequence.equals("0"));
		
		System.out.println("The largest number is " + max);
		System.out.println("The occurrence count of the largest number is " + count);
		
		input.close();
	}

}

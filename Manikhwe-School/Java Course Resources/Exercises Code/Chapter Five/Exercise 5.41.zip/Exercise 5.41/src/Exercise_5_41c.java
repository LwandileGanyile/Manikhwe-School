import java.util.Scanner;

public class Exercise_5_41c {
	/*Student B's solution doesn't take care of numbers with decimal points.*/
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompt a user to enter a sequence of numbers.
		System.out.print("Enter numbers : ");
		// Hold the current sequence.
		// Make sure we eliminate any white spaces before and after the sequence.
		String sequence = input.nextLine();
				
			
		// Validate user input.
		if(sequence.length() >= 2 && sequence.contains(" ") && sequence.charAt(sequence.length()-1) == '0') {
			// Index of a current character.
			int index = 0;
			
			while(sequence.charAt(++index) != '0') {
				if(!Character.isDigit(sequence.charAt(index))  && sequence.charAt(index) != ' ' && sequence.charAt(index) != '.') {
					System.out.print("Error : Make sure a sequence is made up of numbers only.");
					System.exit(0);
				}
			}
		}
		
		/*Scanner does not only read from a keyboard, 
		 *it can also read a String or from a file.*/
		Scanner sequenceReader = new Scanner(sequence);
		
		// Count the number of occurrence of a maximum number.
		int count = 0;
		// Maximum of the sequence.
		String max = sequenceReader.next();
		
		String number;

		do{
			
			number = sequenceReader.next();
			
			if(max.compareTo(number) < 0) {
				max = number;
				count = 1;
			}
			else if(max.equals(number))
				count++;
			
		}while(sequenceReader.hasNext());
		
		System.out.println("The largest number is " + max);
		System.out.println("The occurrence count of the largest number is " + count);
		
		input.close();
		sequenceReader.close();
	}

}

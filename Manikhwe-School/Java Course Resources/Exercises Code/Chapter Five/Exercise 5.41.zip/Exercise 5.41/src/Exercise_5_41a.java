import java.util.Scanner;

public class Exercise_5_41a {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompt a user to enter a sequence of numbers.
		System.out.print("Enter numbers : ");
		String sequence = input.nextLine();
		
		// Count the number of occurrence of a maximum number.
		int count = 1;
		// Maximum of the sequence.
		// Recall you can perform inequality operations with characters.
		char max = sequence.charAt(0);
		// Index of the current number.
		int index = 0;
		
		if(sequence.length() >= 2 && sequence.charAt(sequence.length()-1) == '0') {
			while(sequence.charAt(++index) != '0') {
				if(max < sequence.charAt(index)) {
					max = sequence.charAt(index);
					count = 1;
				}
				else if(max == sequence.charAt(index))
					count++;
			}
			
			System.out.println("The largest number is " + max);
			System.out.println("The occurrence count of the largest number is " + count);
		}
		else {
			System.out.println("Error : Make sure you enter at least one number and zero.");
			System.exit(0);
		}
			
		
		input.close();
	}

}

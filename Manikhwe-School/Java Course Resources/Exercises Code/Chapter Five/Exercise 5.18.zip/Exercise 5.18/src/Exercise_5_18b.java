
public class Exercise_5_18b {
	// Student B displays pattern B.
	public static void main(String[] args) {
		
		System.out.println("Pattern B");
		
		for(int i = 6; i >= 0;i--) {
			for(int j = 1; j <= i;j++) 
				System.out.print(j + " ");
			System.out.println();
		}
	}
}

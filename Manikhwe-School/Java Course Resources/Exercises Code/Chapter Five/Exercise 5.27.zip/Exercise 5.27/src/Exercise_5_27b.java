
public class Exercise_5_27b {
	/* Student B realize we don't know in advance 
	 * the number of years. So a while loop is used.*/
	public static void main(String[] args) {
		
		// Count number of leap years from 101-2100.
		int numberOfLeapYears = 0;
		
		int year = 101;
		while(year <= 2100) {	
			if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
				System.out.print(year + (((numberOfLeapYears+1)%10 != 0)?" ":"\n"));
				numberOfLeapYears++;
				
			}
			year++;
		}
		System.out.print("\n\nThe number of leap years from year 101 to year 2100 is " + numberOfLeapYears + ".");
	}

}

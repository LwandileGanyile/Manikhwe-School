
public class Exercise_5_27a {

	public static void main(String[] args) {
		
		// Count number of leap years from 101-2100.
		int numberOfLeapYears = 0;
		
		for(int year = 101; year <= 2100;year++) {	
			if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
				System.out.print(year + (((numberOfLeapYears+1)%10 != 0)?" ":"\n"));
				numberOfLeapYears++;
			}
		}
		System.out.print("\n\nThe number of leap years from year 101 to year 2100 is " + numberOfLeapYears + ".");
	}

}

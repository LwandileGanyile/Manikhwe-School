import java.util.Scanner;

public class Exercise_5_28c {

	// Student C replaces a while loop with a for loop.
	// This is because we know the number of iterations.
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter year : ");
		int year = input.nextInt();
		
		if(year < 0) {
			System.out.print("Error : Make sure the year is not negetive.");
			System.exit(0);
		}
		
		System.out.print("Enter day(1-7) : ");
		int day = input.nextInt();
		
		if(day < 1 || day>7) {
			System.out.print("Error : Make sure the day is between 1-7.");
			System.exit(1);
		}
		
		String dayName;
		String monthName;
		
		for(int month = 1; month <= 12; month++) {
	
			switch(month) {
			case 1 :monthName = "January";break;
			case 2 :monthName = "February";break;
			case 3 :monthName = "March";break;
			case 4 :monthName = "April";break;
			case 5 :monthName = "May";break;
			case 6 :monthName = "June";break;
			case 7 :monthName = "July";break;
			case 8 :monthName = "August";break;
			case 9 :monthName = "September";break;
			case 10 :monthName = "October";break;
			case 11 :monthName = "November";break;
			default :monthName = "December";break;
			}
			
			switch(day) {
			case 1 :dayName = "Monday";break;
			case 2 :dayName = "Tueday";break;
			case 3 :dayName = "Wednesday";break;
			case 4 :dayName = "Thursday";break;
			case 5 : dayName = "Friday";break;
			case 6 :dayName = "Surtday";break;
			default :dayName = "Sunday";break;
			}
			
			System.out.println(monthName + " 1, " + year + " is " + dayName);
			
			// We add minus one, because we start counting from the second of the current month.
			// Meaning we don't count the first of the current month.
			if(month==1 || month==3 || month==5 || 
			month==7 || month==8 || month==10 || month==12)
				day = 1 + (day + 31-1)%7; 
			else if(month==2)
				if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
					day = 1 + (day +29-1)%7;
				else
					day = 1 + (day +28-1)%7;
			else
				day = 1 + (day + 30-1)%7;
		}
		
		input.close();
	}

}

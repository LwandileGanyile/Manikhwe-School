import java.util.Scanner;

public class Exercise_5_28b {

	// Student B replaces a bunch of if els statements with switch statement.
	// Student A did not validate user input.
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter year : ");
		int year = input.nextInt();
		
		if(year < 0) {
			System.out.print("Error : Make sure the year is not negetive.");
			System.exit(0);
		}
		
		System.out.print("Enter day(1-7) : ");
		int day = input.nextInt();
		
		if(day < 1 || day>7) {
			System.out.print("Error : Make sure the day is between 1-7.");
			System.exit(1);
		}
		
		String dayName;
		String monthName;
		int month = 1;
		
		while( month <= 12) {
	
			switch(month) {
			case 1 :monthName = "January";break;
			case 2 :monthName = "February";break;
			case 3 :monthName = "March";break;
			case 4 :monthName = "April";break;
			case 5 :monthName = "May";break;
			case 6 :monthName = "June";break;
			case 7 :monthName = "July";break;
			case 8 :monthName = "August";break;
			case 9 :monthName = "September";break;
			case 10 :monthName = "October";break;
			case 11 :monthName = "November";break;
			default :monthName = "December";break;
			}
			
			switch(day) {
			case 1 :dayName = "Monday";break;
			case 2 :dayName = "Tueday";break;
			case 3 :dayName = "Wednesday";break;
			case 4 :dayName = "Thursday";break;
			case 5 : dayName = "Friday";break;
			case 6 :dayName = "Surtday";break;
			default :dayName = "Sunday";break;
			}
			
			System.out.println(monthName + " 1, " + year + " is " + dayName);
			
			/* We subtract 1 on the number of days for a given month in order to 
			 * exclude the current day when calculating the number of days to be 
			 * added on the current day.*/
			if(month==1 || month==3 || month==5 || 
			month==7 || month==8 || month==10 || month==12)
				day = 1 + (day + 30)%7; 
			else if(month==2)
				if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
					day = 1 + (day +28)%7;
				else
					day = 1 + (day +27)%7;
			else
				day = 1 + (day + 29)%7;
			
			month++;
		}
		
		input.close();
	}

}

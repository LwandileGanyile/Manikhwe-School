import java.util.Scanner;

public class Exercise_5_28a {

	// Student B replaces a bunch of if els statements with switch statement.
	// Student A did not validate user input.
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter year : ");
		int year = input.nextInt();
		
		System.out.print("Enter day(1-7) : ");
		int day = input.nextInt();
		
		String dayName;
		String monthName;
		int month = 1;
		
		while( month <= 12) {
	
			
			if(month==1) monthName = "January";
			else if(month==1)monthName = "February";
			else if(month==1)monthName = "March";
			else if(month==1)monthName = "April";
			else if(month==1)monthName = "May";
			else if(month==1)monthName = "June";
			else if(month==1)monthName = "July";
			else if(month==1)monthName = "August";
			else if(month==1)monthName = "September";
			else if(month==1)monthName = "October";
			else if(month==1)monthName = "November";
			else monthName = "December";
			
			
			switch(day) {
			case 1 :dayName = "Monday";break;
			case 2 :dayName = "Tueday";break;
			case 3 :dayName = "Wednesday";break;
			case 4 :dayName = "Thursday";break;
			case 5 : dayName = "Friday";break;
			case 6 :dayName = "Surtday";break;
			default :dayName = "Sunday";break;
			}
			
			System.out.println(monthName + " 1, " + year + " is " + dayName);
			
			// We add minus one, because we start counting from the second of the current month.
			// Meaning we don't count the first of the current month.
			if(month==1 || month==3 || month==5 || 
			month==7 || month==8 || month==10 || month==12)
				day = 1 + (day + 31-1)%7; 
			else if(month==2)
				if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
					day = 1 + (day +29-1)%7;
				else
					day = 1 + (day +28-1)%7;
			else
				day = 1 + (day + 30-1)%7;
			
			month++;
		}
		
		input.close();
	}

}

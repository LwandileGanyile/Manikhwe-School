
public class Exercise_5_15b {
	/* Student B realize that it is crucial to 
	 * have descriptive names for you variables.
	 * Secondly, he realize that a while loop is
	 * not a good choice for the problem.*/
	public static void main(String[] args) {
		
		// Count number of characters already displayed.
		int count = 0;
		
		for(int characterIndex = 33; characterIndex <= 126; characterIndex++) {
			System.out.print(((char)(characterIndex) + (((count+1)%10 == 0)?"\n":" ")));
			count++;
		}

	}

}

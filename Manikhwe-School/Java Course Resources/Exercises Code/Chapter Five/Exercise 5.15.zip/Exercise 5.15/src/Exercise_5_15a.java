
public class Exercise_5_15a {

	public static void main(String[] args) {
		
		// Count number of characters already displayed.
		int c = 0;
		
		// The index that correspond to a certain character.
		int i = 33;
		
		while(i <= 126) {
			System.out.print(((char)(i) + (((c+1)%10 == 0)?"\n":" ")));
			c++;
			i++;
		}

	}

}

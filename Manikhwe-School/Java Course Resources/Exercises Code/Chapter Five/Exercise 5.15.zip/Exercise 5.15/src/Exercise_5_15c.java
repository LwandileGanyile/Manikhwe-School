
public class Exercise_5_15c {
	/* Student C realize that it is a good practice to 
	 * use the amount of space that is appropriate for  
	 * variables.*/
	public static void main(String[] args) {
		
		// Count number of characters already displayed.
		byte count = 0;
		
		for(byte characterIndex = 33; characterIndex <= 126; characterIndex++) {
			System.out.print(((char)(characterIndex) + (((count+1)%10 == 0)?"\n":" ")));
			count++;
		}

	}

}

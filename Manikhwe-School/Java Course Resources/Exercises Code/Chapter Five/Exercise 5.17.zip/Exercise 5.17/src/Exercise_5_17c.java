import java.util.Scanner;

public class Exercise_5_17c {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter number of lines.
		System.out.print("Enter the number of lines : ");
		int numberOfLines = input.nextInt();
				
		if(!(numberOfLines >=1 && numberOfLines <= 15)) {
			System.out.print("Error : Make sure the number of lines is between 1-15!!!");
			System.exit(0);
		}
					
		/* Row 0 correspond to line 1, in general row i correspond 
		* to line i plus 1.*/
		for(int row = 0; row < numberOfLines; row++) {			
			// Display left hand side of a line excluding 1.
			for(int leftIndex = numberOfLines; leftIndex > 1; leftIndex--) 
				if(leftIndex <= row + 1 )
					System.out.print(leftIndex + "\t");
				else
					System.out.print("\t");
			
			// Display right hand side of a line starting from 1.
			for(int rightIndex = 1; rightIndex <= row + 1; rightIndex++) 
				System.out.print(rightIndex + "\t");
					
			System.out.println();
		}

		input.close();
	}

}

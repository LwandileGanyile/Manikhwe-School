import java.util.Scanner;

public class Exercise_5_17a {

	// All three students have different approach to the problem.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter number of lines.
		System.out.print("Enter the number of lines : ");
		int numberOfLines = input.nextInt();
		
		if(!(numberOfLines >=1 && numberOfLines <= 15)) {
			System.out.print("Error : Make sure the number of lines is between 1-15!!!");
			System.exit(0);
		}
			
		/* Row 0 correspond to line 1, in general row i correspond 
		 * to line i plus 1.*/
		for(int row = 0; row < numberOfLines; row++) {
			/* Taking 1 as a point of reference. We are concern 
			 * with a certain equal number of numbers to the left 
			 * and right of 1.*/
			for(int column = -numberOfLines; column <= numberOfLines;column++) {
				/* The first line is a special case. It only has one number(1).*/
				// Print 1 then break the inner loop.
				if(column==-1 && row == 0) {
					System.out.print(row+1);
					break;
				}
				/* Line 2 example : we are concern with 2 1 2. So the inner loop 
				 * is active for the three numbers only. However it treats the numbers
				 * to the left of 1 as negative numbers inclusively. When it prints 
				 * though, it print them as positive numbers*/
				
				else if(row != 0 && column>=-row-1 && column<=row+1) {
					// Numbers to the right of the reference position(1).
					if(column > 0)
						System.out.print(column + "\t");
					// Numbers to the left of the reference position(1).
					else if(column < 0)
						if(column != -1)
							System.out.print(Math.abs(column) + "\t");						
				}
				else
					// Leave enough space if there is no number to display.
					/* It is necessary to use not just a space or two, because
					 * if you do, the output won't look good.*/
					System.out.print("\t");
			}
			System.out.println();
		}
		
		input.close();
	}

}

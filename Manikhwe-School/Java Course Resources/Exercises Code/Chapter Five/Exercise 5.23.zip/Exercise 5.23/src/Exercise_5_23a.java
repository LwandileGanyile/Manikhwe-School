
public class Exercise_5_23a {
	public static void main(String[] args) {
		
		// The sum from right to left.
		double rightToLeftSum = 0;
		
		// The sum from left to right.
		double leftToRightSum = 0;
		
		// The denominator of each term.
		int n = 50000;;
		
		while(n >= 1) {
			rightToLeftSum += 1.0/n;
			n--;
		}
		
		n++;
		
		while( n <= 50000) {
			leftToRightSum += 1.0/n;
			 n++;
		}
		
		System.out.println("The sum of the series from right to left is " + rightToLeftSum);
		System.out.println("The sum of the series from left to right is " + leftToRightSum);

	}

}


public class Exercise_5_23c {
	// Student C realize only for loops should be used.
	public static void main(String[] args) {
		
		// The sum from right to left.
		double rightToLeftSum = 0;
		
		// The sum from left to right.
		double leftToRightSum = 0;
		
		for(int n = 50000; n >= 1; n--)
			rightToLeftSum += 1.0/n;
		
		System.out.println("The sum of the series from right to left is " + rightToLeftSum);
		
		for(int n = 1; n <= 50000; n++)
			leftToRightSum += 1.0/n;
		
		System.out.println("The sum of the series from left to right is " + leftToRightSum);

	}

}

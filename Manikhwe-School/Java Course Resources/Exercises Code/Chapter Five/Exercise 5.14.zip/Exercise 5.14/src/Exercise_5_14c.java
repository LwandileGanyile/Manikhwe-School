import java.util.Scanner;

public class Exercise_5_14c {
	/* Student C decided to use a break statement to 
	 * minimize number of variables to use on a program.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter two integers.
		System.out.print("Enter two integers : ");
		int firstNumber = input.nextInt();
		int secondNumber = input.nextInt();
		
		if(firstNumber == 0 || secondNumber == 0)
			System.out.print(firstNumber + " and " + secondNumber + " have no GCD.");
		else {
			
			int divisor = (firstNumber < secondNumber)? firstNumber : secondNumber;
			
			while(divisor >= 1) {
				
				if(firstNumber%divisor==0 && secondNumber%divisor==0) {
					System.out.print("The GCD of " + firstNumber + 
					" and " + secondNumber + " is " + divisor + ".");
					break;
				}
				divisor--;
			}
		}
		
		// Close a scanner to release any sources used by it.
		input.close();
	}
}

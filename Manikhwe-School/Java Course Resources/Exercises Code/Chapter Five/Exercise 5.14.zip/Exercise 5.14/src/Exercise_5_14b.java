import java.util.Scanner;

public class Exercise_5_14b {
	/* Student B realize that a program has to be commented.
	 * Secondly, a while loop has to be used instead of a for
	 * loop.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter two integers.
		System.out.print("Enter two integers : ");
		int firstNumber = input.nextInt();
		int secondNumber = input.nextInt();
		
		if(firstNumber == 0 || secondNumber == 0)
			System.out.print(firstNumber + " and " + secondNumber + " have no GCD.");
		else {
			
			int divisor = (firstNumber < secondNumber)? firstNumber : secondNumber;
			
			// Tells us whether of or not a divisor is found.
			boolean divisorFound = false;
			
			while(!divisorFound) {
				
				if(firstNumber%divisor==0 && secondNumber%divisor==0) {
					System.out.print("The GCD of " + firstNumber + 
					" and " + secondNumber + " is " + divisor + ".");
					divisorFound = true;
				}
				divisor--;
			}
		}
		
		// Close a scanner to release any sources used by it.
		input.close();
	}
}

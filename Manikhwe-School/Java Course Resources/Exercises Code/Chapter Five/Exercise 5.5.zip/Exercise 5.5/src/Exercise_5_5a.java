
public class Exercise_5_5a {
	
	public static void main(String[] args) {
		
		final double POUNDS_PER_KILOGRAM = 2.2;
		final int MAXIMUM_KILOGRAMS = 199;
		final int MAXIMUM_POUNDS = 515;
		
		int fromPounds = 20;
		double toPounds;
		
		int fromKilograms = 1;
		double toKilograms;
		
		System.out.println("Kilograms\tPounds\t|\tPounds\tKilograms");
		
		do {
			toKilograms = fromKilograms*POUNDS_PER_KILOGRAM;
			toPounds = fromPounds/POUNDS_PER_KILOGRAM;
			System.out.printf("%d\t\t%3.1f\t|\t%d\t%3.2f\n", fromKilograms,toKilograms,fromPounds,toPounds);
			
			fromKilograms += 2;
			fromPounds += 5;
			
		}while(fromPounds <= MAXIMUM_POUNDS && fromKilograms <= MAXIMUM_KILOGRAMS);
	}

}

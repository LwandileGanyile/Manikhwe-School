import java.util.Scanner;

public class Exercise_5_5c {
	/* Student C want the number of kilograms 
	 * and grams to convert to be dynamic.*/
	public static void main(String[] args) {
		
		final double POUNDS_PER_KILOGRAM = 2.2;
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter minimum and maximum kilometers to convert.
		System.out.print("Enter minimum and maximum kilograms to convert : ");
		int minimumKilograms = input.nextInt();
		int maximumKilograms = input.nextInt();
		
		if(minimumKilograms > maximumKilograms) {
			System.out.print("Error : Make sure that minimum kilograms to convert is less than maximum kilometers to convert.");
			System.exit(0);
		}
		
		if(minimumKilograms < 0){
			System.out.print("Error : Make sure that minimum kilograms to convert is atleast zero.");
			System.exit(1);
		}
			
		
		double toKilograms;
		
		// Prompts a user to enter minimum and maximum pounds to convert.
		System.out.print("Enter minimum and maximum pounds to convert : ");
		int minimumPounds = input.nextInt();
		int maximumPounds = input.nextInt();
		
		if(minimumPounds > maximumPounds) {
			System.out.print("Error : Make sure that minimum pounds to convert is less than maximum pounds to convert.");
			System.exit(2);
		}
		
		if(minimumPounds < 0) {
			System.out.print("Error : Make sure that minimum pounds to convert is atleast zero.");
			System.exit(3);
		}
		
		double toPounds;
		
		System.out.println("\nKilograms\tPounds\t|\tPounds\tKilograms");
		
		/* Note if the number of conversions from kilograms to 
		 * pounds and pounds to kilograms is not the same. Some 
		 * of the conversions will not be performed.*/
		do {
			toKilograms = minimumKilograms*POUNDS_PER_KILOGRAM;
			toPounds = minimumPounds/POUNDS_PER_KILOGRAM;
			System.out.printf("%d\t\t%3.1f\t|\t%d\t%3.2f\n", minimumKilograms,toKilograms,minimumPounds,toPounds);
			
			minimumKilograms += 2;
			minimumPounds += 5;
			
		}while(minimumPounds <= maximumPounds && minimumKilograms <= maximumKilograms);
		
		input.close();
	}

}

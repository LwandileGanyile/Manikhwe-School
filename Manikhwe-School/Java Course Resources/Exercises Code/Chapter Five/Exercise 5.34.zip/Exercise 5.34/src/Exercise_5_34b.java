import java.util.Scanner;

public class Exercise_5_34b {

		// Second student realize that the user input has to be validated.
		// Second student also realize that a variable to track an answer will be useful.
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		// Declare and initialize a computers choice.
		int computerChoice;
		// The number of times a computer has won.
		int computerWins = 0;
		
		// A choice picked by a user.
		int userChoice;
		// The number of times a user has won.
		int userWins = 0;
		
		// Zero is a special case. We know any number multiplied by zero plus 1 is 1.
		// So we will use 3-0 as a stopping case, even though 3-1 is also a stopping case.
		// If we don't do this, the game will end immediately we get a 1-0 score.
		boolean canPlay = !((userWins == 0 && computerWins == 3) ||
				(userWins == 3 && computerWins == 0) ||
				((userWins != 0 && computerWins != 0 &&
				(userWins ==(2*computerWins+1) || computerWins == (2*userWins+1)))));
		
		// Loop while the neither a user nor a computer has wins two times the opponent.
		// However there is an exception, that is when either a user of a computer has no wins.
		while(canPlay) {
			
			computerChoice = (int)(Math.random()*3);			
			// Prompt user to enter his choice.
			System.out.print("scissor (0), rock (1), paper (2): ");			
			userChoice = scanner.nextInt();
			
			
			if(userChoice == 0 || userChoice == 1 || userChoice == 2) {
				// Scissor
				if(userChoice==0) {
					// Scissor
					if(computerChoice == 0) {
						System.out.println("The computer is scissor. You are scissor too. It is a draw");
						
					}
					// Rock
					else if(computerChoice == 1) {
						System.out.println("The computer is scissor. You are rock. You won");
						userWins++;
					}
					else {
						System.out.println("The computer is scissor. You are paper. You lost");
						computerWins++;
					}
				}
				// Rock
				else if(userChoice==1) {
					if(computerChoice == 0) {
						System.out.println("The computer is rock. You are scissor. You lost");
						computerWins++;
					}
					else if(computerChoice == 1) {
						System.out.println("The computer is rock. You are rock too. It is a draw");
					}
					else {
						System.out.println("The computer is rock. You are paper. You won");
						userWins++;
					}
				}
				// Paper
				else {
					if(computerChoice == 0) {
						System.out.println("The computer is paper. You are scissor. You won");
						userWins++;
					}
					else if(computerChoice == 1) {
						System.out.println("The computer is paper. You are rock. You lost");
						computerWins++;
					}
					else {
						System.out.println("The computer is paper. You are papper too. It is a draw");
					}
				}
				
				System.out.println("Computer Wins : " + computerWins + "\tPlayer Wins : " + userWins);
				
				canPlay = !((userWins == 0 && computerWins == 3) ||
						    (userWins == 3 && computerWins == 0) ||
						    ((userWins != 0 && computerWins != 0 &&
						    (userWins ==(2*computerWins+1) || 
						    computerWins == (2*userWins+1)))));
				if(!canPlay)
					System.out.println("----------------------Game Over---------------------");
				
			}
			else {
				System.out.println("Try again, make sure this time you enter 0, 1 or 2.");
			}
		}
		scanner.close();
	}

}


public class Exercise_5_35b {

	/* Student B realize that there is nothing that we need to do first before we loop.
	 * So he replaces a do while loop with a while loop.*/
	public static void main(String[] args) {
		
		// Hold the summation.
		double sum = 0;
		// A number that is within the square root.
		int number = 1;
		
		while( number <= 624) {
			sum += (1.0/(Math.sqrt(number) + Math.sqrt(number)+1));
			number++;
		}
		
		System.out.print("The summation is : " + sum + ".");
	}

}

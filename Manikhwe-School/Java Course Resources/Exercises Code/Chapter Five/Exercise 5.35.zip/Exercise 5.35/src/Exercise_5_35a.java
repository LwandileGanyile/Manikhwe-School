
public class Exercise_5_35a {

	public static void main(String[] args) {
		
		// Hold the summation.
		double sum = 0;
		// A number that is within the square root.
		int number = 1;
		
		 do{
			sum += (1.0/(Math.sqrt(number) + Math.sqrt(number)+1));
			number++;
		}while( number <= 624);
		
		System.out.print("The summation is : " + sum + ".");
	}

}


public class Exercise_5_35c {

	/* Student C realize that a for loop is the 
	 * best loop choice because we know how many 
	 * times a loop will execute.*/
	public static void main(String[] args) {
		
		// Hold the summation.
		double sum = 0;
		
		for(int number = 1; number <= 624; number++)
			sum += (1.0/(Math.sqrt(number) + Math.sqrt(number)+1));
		
		System.out.print("The summation is : " + sum + ".");
	}

}

import java.util.Scanner;

public class Exercise_5_22b {
	/*Student A did not validate user input*/
	public static void main(String[] args) {
		// Create a Scanner
		Scanner input = new Scanner(System.in);
		
		// Enter loan amount
		System.out.print("Loan amount : ");
		double loanAmount = input.nextDouble();
		
		if(loanAmount <=0) {
			System.out.print("Error : Loan amount "
			+ "cannot be less or equal to zero.");
			System.exit(0);
		}
		
		// Enter number of years
		System.out.print(
		"Number of years : ");
		int numberOfYears = input.nextInt();
		
		if(numberOfYears <=0) {
			System.out.print("Error : Number of years "
			+ "cannot be less or equal to zero.");
			System.exit(1);
		}
		
		System.out.print(
		"AnnualInterest Rate : ");
		// Used to hold annual interest rate.
		double annualInterestRate = input.nextDouble();
		
		if(annualInterestRate <0) {
			System.out.print("Error : Annual interest "
			+ "cannot be less than to zero.");
			System.exit(2);
		}
		
		// Used to store monthly interest rate.
		double monthlyInterestRate = annualInterestRate / 1200;
		
		// Used to calculate monthly payment.
		double monthlyPayment = loanAmount * monthlyInterestRate / (1
		- 1 / Math.pow(1 + monthlyInterestRate, numberOfYears * 12));
		// Used to calculate total payment.
		double totalPayment = monthlyPayment*numberOfYears*12;
		// Used to hold monthly interest.
		double interest;
		// Used to hold the principal paid for a month.
		double principal;
		// Used to store the outstanding balance.
		double balance = loanAmount;
		
		
		System.out.println("Monthly Payment : " + monthlyPayment);
		System.out.println("Total Payment : " + totalPayment);
		System.out.println("\nPayment#\t\tInterest\t\t\tPrincipal\t\t\tBalance");
		
		for (int i = 1; i <= numberOfYears * 12; i++) {
			interest = monthlyInterestRate * balance;
			principal = monthlyPayment - interest;
			balance = balance - principal;
			System.out.println(i + "\t\t\t" + interest
			+ "\t\t" + principal + "\t\t" + balance);
		}
		
		input.close();
	}
}
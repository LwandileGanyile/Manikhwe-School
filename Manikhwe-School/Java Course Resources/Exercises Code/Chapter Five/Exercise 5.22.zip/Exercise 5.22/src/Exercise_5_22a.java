import java.util.Scanner;

public class Exercise_5_22a {
	public static void main(String[] args) {
		// Create a Scanner
		Scanner input = new Scanner(System.in);
		
		// Enter loan amount
		System.out.print("Loan amount : ");
		double loanAmount = input.nextDouble();
		
		// Enter number of years
		System.out.print(
		"Number of years : ");
		int numberOfYears = input.nextInt();
		
		System.out.print(
		"AnnualInterest Rate : ");
		// Used to hold annual interest rate.
		double annualInterestRate = input.nextDouble();
		
		// Used to store monthly interest rate.
		double monthlyInterestRate = annualInterestRate / 1200;
		
		// Used to calculate monthly payment.
		double monthlyPayment = loanAmount * monthlyInterestRate / (1
		- 1 / Math.pow(1 + monthlyInterestRate, numberOfYears * 12));
		// Used to calculate total payment.
		double totalPayment = monthlyPayment*numberOfYears*12;
		// Used to hold monthly interest.
		double interest;
		// Used to hold the principal paid for a month.
		double principal;
		// Used to store the outstanding balance.
		double balance = loanAmount;
		
		
		System.out.println("Monthly Payment : " + monthlyPayment);
		System.out.println("Total Payment : " + totalPayment);
		System.out.println("\nPayment#\t\tInterest\t\t\tPrincipal\t\t\tBalance");
		
		for (int i = 1; i <= numberOfYears * 12; i++) {
			interest = monthlyInterestRate * balance;
			principal = monthlyPayment - interest;
			balance = balance - principal;
			System.out.println(i + "\t\t\t" + interest
			+ "\t\t" + principal + "\t\t" + balance);
		}
		
		input.close();
	}
}
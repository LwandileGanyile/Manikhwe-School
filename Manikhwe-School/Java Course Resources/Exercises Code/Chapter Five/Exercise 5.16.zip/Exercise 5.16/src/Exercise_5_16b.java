import java.util.Scanner;

public class Exercise_5_16b {
	/* Student A's solution is hard to read, because 
	 * it's variable are not meaningful and there are 
	 * not comments.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an input.
		System.out.print("Enter an integer : ");
		int number = input.nextInt();
		
		if(number == 1 || number == -1) {
			System.out.print("The factors of 1 is 1 only.");
			System.exit(0);
		}
		
		// The product is used to determine whether we should keep looping or not.
		int product = 1;
		
		// The number that can divide a given number.
		int divisor = 2;
		
		// All the divisor. Duplicates a re allowed.
		String factors = "";
		
		int positiveOriginalNumber = Math.abs(number);
		
		while(product < positiveOriginalNumber) {
			
			if(number % divisor == 0) {
				factors = factors + divisor + ",";
				number = number /divisor;
				product = product *divisor;
			}
			else
				divisor++;
				
		}
		
		// Remove the last ',' on the factors.
		factors = factors.substring(0,factors.length()-1);
		
		System.out.println("The factors of " + number 
		+ " are " + factors + ".");
		
		input.close();

	}

}

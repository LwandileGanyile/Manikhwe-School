import java.util.Scanner;

public class Exercise_5_16a {
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an input.
		System.out.print("Enter an integer : ");
		// A number to work with.
		int n = input.nextInt();
		
		if(n == 1 || n == -1) {
			System.out.print("The factors of 1 is 1 only.");
			System.exit(0);
		}
		
		// The product is used to determine whether we should keep looping or not.
		int p = 1;
		
		// The number that can divide a given number.
		int d = 2;
		
		// All the divisor. Duplicates a re allowed.
		String f = "";
		
		// Original number
		int on = Math.abs(n);
		
		while(p < on) {
			
			if(n % d == 0) {
				f += d + ",";
				n /= d;
				p *= d;
			}
			else
				d++;
		}
		
		System.out.println("The factors of " + on 
		+ " are " + f.substring(0,f.length()-1) + ".");
		
		input.close();

	}

}

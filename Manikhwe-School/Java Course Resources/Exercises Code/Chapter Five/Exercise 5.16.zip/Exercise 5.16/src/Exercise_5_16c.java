import java.util.Scanner;

public class Exercise_5_16c {
	/* 	One variable is used unnecessary on student's B solution.
	 *.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter an input.
		System.out.print("Enter an integer : ");
		int number = input.nextInt();
		
		if(Math.abs(number) == 1) {
			System.out.print("The factors of 1 is 1 only.");
			System.exit(0);
		}
		
		// The product is used to determine whether we should keep looping or not.
		int product = 1;
		
		// The number that can divide a given number.
		int divisor = 2;
		
		// All the divisor. Duplicates a re allowed.
		String factors = "";
		
		int originalNumber = number;
		
		if(number < 0)
			number = Math.abs(number);
		
		int positiveOriginalNumber = number;
		
		while(product < positiveOriginalNumber) {
			
			if(number % divisor == 0) {
				factors += divisor + ",";
				number /= divisor;
				product *= divisor;
			}
			else
				divisor++;
		}
		
		System.out.println("The factors of " + originalNumber 
		+ " are " + factors.substring(0,factors.length()-1) + ".");
		
		input.close();

	}

}

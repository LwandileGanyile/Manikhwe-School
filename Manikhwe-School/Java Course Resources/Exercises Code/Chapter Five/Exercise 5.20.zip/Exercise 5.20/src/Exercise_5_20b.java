
public class Exercise_5_20b {
	/* Student B realize that the inner loop 
	 * has to stop half way of the current number 
	 * that is being checked. That is to, there is
	 * no number above half of the current number
	 * being checked that can divide the current number.*/
	public static void main(String[] args) {
		
		// Determines whether a number is prime or not.
		boolean isPrime;
		// Counts the number of prime numbers.
		int count = 0;
		
		for(int i = 2; i <= 1000;i++) {
			isPrime = true;
			for(int j = 2; j <= i/2; j++) {
				if(i%j==0) {
					isPrime = false;
					break;
				}
			}
			
			if(isPrime) {
				count++;
				System.out.print(i + ((count%8==0)? "\n":" "));
			}
		}
	}

}

import java.util.Scanner;

public class Exercise_5_50a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner keyboardReader = new Scanner(System.in);

		// Prompts user to enter a sentence.
		System.out.print("Enter a string : ");
		String sentence = keyboardReader.nextLine();
		
		// Read a sentence the same way you would for a key board input.
		Scanner sentenceReader = new Scanner(sentence);
		
		// Counter of upper case letters.
		int count = 0;
		String word;
		
		// Read word by word of a sentence.
		while(sentenceReader.hasNext()) {
			word = sentenceReader.next();
		for(int characterIndex = 0; characterIndex < word.length(); characterIndex++)
			if(Character.isUpperCase(word.charAt(characterIndex)))
				count++;
		}
		System.out.print("The number of uppercase letters is " + count);
		
			
		keyboardReader.close();
		sentenceReader.close();
	}

}

import java.util.Scanner;

public class Exercise_5_50c {

	// Student A's solution is wasting memory by create a second scanner.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts user to enter a sentence.
		System.out.print("Enter a string : ");
		String sentence = input.nextLine();
		
		// Counter of upper case letters.
		int count = 0;
		
		for(int characterIndex = 0; characterIndex < sentence.length(); characterIndex++)
			if(Character.isUpperCase(sentence.charAt(characterIndex)))
				count++;
		System.out.print("The number of uppercase letters is " + count);
		
			
		input.close();
	}

}

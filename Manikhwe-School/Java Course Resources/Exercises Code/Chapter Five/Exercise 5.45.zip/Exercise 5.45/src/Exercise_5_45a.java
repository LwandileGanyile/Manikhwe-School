import java.util.Scanner;

public class Exercise_5_45a {
	// Student A used many variables.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a sequence of ten number.
		System.out.print("Enter ten numbers : ");
				
		// Store all ten numbers.
		String numbers = input.nextLine();
		
		// Count number of numbers in a sequence.
		int count = 0;
		// The sum of all numbers.
		double sum = 0;
		// The sum of squares.
		double sumOfSquares = 0;
		
		if(!numbers.contains(" ")) {
			System.out.print("Error : Make sure you enter ten numbers seperated by a space.");
			System.exit(0);
		}
				
		// Holds a single term of the sequence.
		double number;
		
		 do {
			number = Double.parseDouble(numbers.substring(0, numbers.indexOf(" ")));
			sumOfSquares += number*number;
			sum += number;
			count++;
			numbers = numbers.substring(numbers.indexOf(" ") + 1);
		}while(numbers.contains(" "));
		
		 if(count != 10) {
			System.out.print("Error : Make sure you enter ten numbers.");
			System.exit(0);
		}
		 
		 // Computed mean.
		double mean = sum/count;
		
		// Partial parts of the standard deviation formula.
		double variable1 = ((sum*sum)/count);
		double variable2 = sumOfSquares-variable1;
		double variable3 = variable2/(count-1);
		
		double standardDeviation = Math.sqrt(variable3);
			
		System.out.println("The mean is " + mean);
		System.out.printf("The standard deviation is %8.5f", standardDeviation);
		 
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_5_45c {

	// Student C simplified things by using a scanner to read a string.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter ten number.
		System.out.print("Enter ten numbers : ");
		
		// Store all ten numbers.
		String numbers = input.nextLine();
		
		Scanner numbersReader = new Scanner(numbers);
		
		// Count number of numbers in a sequence.
		int count = 0;
		// The sum of all numbers.
		double sum = 0;
		// The sum of squares.
		double sumOfSquares = 0;
		
		// Holds a single term of the sequence.
		double number;
		
		while(numbersReader.hasNext()) {
			number = numbersReader.nextDouble();
			sumOfSquares += number*number;
			sum += number;
			count++;
		}
		
		if(count != 10) {
			System.out.print("Error : Make sure you enter ten numbers.");
			System.exit(0);
		}
		
		double mean = sum/count;
		double standardDeviation = Math.sqrt((sumOfSquares-((sum*sum)/count))/(count-1));
		
		System.out.println("The mean is " + mean);
		System.out.printf("The standard deviation is %8.5f", standardDeviation);
		
		input.close();
		numbersReader.close();
	}

}


public class Exercise_5_3c {

	/* Student C realize that a for loop
	 * is suited for the problem compare 
	 * to the while loop. 
	 */
	public static void main(String[] args) {
		
		final double POUNDS_PER_KILOGRAMS = 2.2;
		
		int kilograms;
		
		System.out.println("Kilograms\tPounds\n");
		
		for(kilograms = 1;kilograms < 201; kilograms += 2) {
			System.out.printf("%d\t\t%5.1f\n",kilograms,kilograms*POUNDS_PER_KILOGRAMS);
			
		}

	}

}


public class Exercise_5_3a {

	public static void main(String[] args) {
		
		final double POUNDS_PER_KILOGRAMS = 2.2;
		
		
		int kilograms = 1;
		
		System.out.println("Kilograms\tPounds\n");
		
		while(kilograms <= 199) {
			System.out.printf("%d\t\t%5.1f\n",kilograms,kilograms*POUNDS_PER_KILOGRAMS);
			kilograms += 2;
		}

	}

}


public class Exercise_5_13c {

	/* Student C knows that 10 cube is 1000. 
	 * So his program start searching numbers 
	 * from 10, this will obviously make the 
	 * program run faster compare to the one 
	 * started the search from a number less 
	 * than 10. Furthermore, student C sees
	 * MAXIMUM as a redundant variable.*/
	public static void main(String[] args) {
		
		int number = 10;
		int nCube = (int)Math.pow(number,3);
		
		while(nCube < 12000) {
			number = number +1;
			nCube = (int)Math.pow(number,3);
		}
		
		System.out.print("The value of n is " + 
		(number-1) + " and n cube is " + (int)Math.pow(number-1, 3) + ".");
	}

}


public class Exercise_5_13b {

	/* Student A did not use descriptive names for variables.*/
	public static void main(String[] args) {
		
		int number = 1;
		int nCube = (int)Math.pow(number,3);
	
		final int MAXIMUM = 12000;
		
		while(nCube < MAXIMUM) {
			number = number +1;
			nCube = (int)Math.pow(number,3);
		}
		
		System.out.print("The value of n is " + 
		(number-1) + " and n cube is " + (int)Math.pow(number-1, 3) + ".");
	}

}

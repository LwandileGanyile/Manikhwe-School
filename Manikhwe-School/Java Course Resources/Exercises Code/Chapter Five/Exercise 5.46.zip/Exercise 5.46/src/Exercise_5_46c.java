import java.util.Scanner;

public class Exercise_5_46c {
	/* Student C did a little bit of research 
	 * and found the StringBuilder class with 
	 * a method for reversing a string. Note,
	 * using methods that are already defined
	 * in the java API is something I don't 
	 * recommend because you don't get to learn
	 * the way you suppose to.*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a string.
		System.out.print("Enter a string : ");
		// Store user input.
		String userInput = input.nextLine();
		StringBuilder flexibleUserInput = new StringBuilder(userInput);
		
		System.out.print("The reversed string is " + flexibleUserInput.reverse());
		
		
		input.close();
	}

}

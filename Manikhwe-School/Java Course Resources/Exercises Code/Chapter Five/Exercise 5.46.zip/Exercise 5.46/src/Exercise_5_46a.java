import java.util.Scanner;

public class Exercise_5_46a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a string.
		System.out.print("Enter a string : ");
		// Store user input.
		String userInput = input.nextLine();
		String reversedString = "";
		
		
		for(int i = userInput.length()-1; i >=0; i--)
			reversedString += userInput.charAt(i);
			System.out.print("The reversed string is " + reversedString);
		
		input.close();
	}

}

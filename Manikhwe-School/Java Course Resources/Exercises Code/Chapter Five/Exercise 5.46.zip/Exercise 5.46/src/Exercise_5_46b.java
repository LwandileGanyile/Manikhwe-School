import java.util.Scanner;

public class Exercise_5_46b {
	/* Student A used a string to hold the reversed characters.
	 * The creation of a new String takes memory, hence student
	 * A over used memory space.
	*/
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a string.
		System.out.print("Enter a string : ");
		// Store user input.
		String userInput = input.nextLine();
		
		System.out.print("The reversed string is ");
		for(int i = userInput.length()-1; i >=0; i--)
			System.out.print(userInput.charAt(i));
		
		input.close();
	}

}

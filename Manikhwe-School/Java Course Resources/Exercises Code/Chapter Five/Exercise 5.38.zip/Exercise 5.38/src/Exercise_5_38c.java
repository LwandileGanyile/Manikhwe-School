import java.util.Scanner;

public class Exercise_5_38c {

	/* Student C realize that a for loop isn't
	 * a good choice for validation, because
	 * we don't know how many times a loop will
	 * execute.*/
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a decimal value;
		
		System.out.print("Enter a decimal value : ");
		String decimalValue = input.nextLine();
		
		boolean isNumber = true;
		int characterIndex = 0;
		
		// Check whether each character of a user input is a number or not.
		// The input is invalid if it is not a digit.
		while(isNumber && characterIndex < decimalValue.length()) {
			if(!Character.isDigit(decimalValue.charAt(characterIndex++)))
				isNumber = false;
		}
		
		if(!isNumber) {
			System.out.print("Error : Make sure your input is a number.");
			System.exit(0);
		}
		
		String octalValue = "";
		
		int number = Integer.parseInt(String.valueOf(decimalValue));
		double temp;
		
		double remainder;
		
		do {
			temp = number/8.0;
			remainder = ((temp - (int)temp)*8);
			octalValue += (int)remainder;;
			number = (int)temp;
			
		}while(number != 0);
		
		for(int i = octalValue.length()-1; i >= 0 ; i--)
			System.out.print(octalValue.charAt(i));
		
		input.close();

	}

}

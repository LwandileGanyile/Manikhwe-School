import java.util.Scanner;

public class Exercise_5_38b {
	/* Student B realize that a do while loop is
	 * a good choice compared to a while loop for
	 * the logic of conversion. This is because
	 * we need to take care of the case where a 
	 * user input is 0. Student A didn't validate
	 * user input.*/
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a decimal value;
		
		System.out.print("Enter a decimal value : ");
		String decimalValue = input.nextLine();
		
		boolean isNumber = true;
		int characterIndex;
		
		// Check whether each character of a user input is a number or not.
		// The input is invalid if it is not a digit.
		for(characterIndex = 0;isNumber && characterIndex < decimalValue.length();characterIndex++) {
			if(!Character.isDigit(decimalValue.charAt(characterIndex)))
				isNumber = false;
		}
		
		if(!isNumber) {
			System.out.print("Error : Make sure your input is a number.");
			System.exit(0);
		}
		
		String octalValue = "";
		
		int number = Integer.parseInt(String.valueOf(decimalValue));
		double temp;
		
		double remainder;
		
		do {
			temp = number/8.0;
			remainder = ((temp - (int)temp)*8);
			octalValue += (int)remainder;;
			number = (int)temp;
			
		}while(number != 0);
		
		for(int i = octalValue.length()-1; i >= 0 ; i--)
			System.out.print(octalValue.charAt(i));
		
		input.close();

	}

}

import java.util.Scanner;

public class Exercise_5_38a {
	/* Student B realize that a do while loop is
	 * a good choice compared to a while loop for
	 * the logic of conversion. This is because
	 * we need to take care of the case where a 
	 * user input is 0*/
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter a decimal value;		
		System.out.print("Enter a decimal value : ");
		String decimalValue = input.nextLine();
		
		String octalValue = "";
		
		int number = Integer.parseInt(String.valueOf(decimalValue));
		double temp;
		
		double remainder;
		
		while(number != 0); {
			temp = number/8.0;
			remainder = ((temp - (int)temp)*8);
			octalValue += (int)remainder;;
			number = (int)temp;
			
		}
		
		for(int i = octalValue.length()-1; i >= 0 ; i--)
			System.out.print(octalValue.charAt(i));
		
		input.close();

	}

}

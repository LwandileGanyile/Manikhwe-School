
public class Exercise_5_40c {
	// From memory point of view, student C is using a little RAM as possible.
	// Student B used a while loop as if he does't how many time a loop will execute.
	public static void main(String[] args) {
		
		// Number of heads.
		int heads = 0;
		
		for(int tossNumber = 1; tossNumber <= 1000000;tossNumber++) 
			if((int)(Math.random()*2) == 0)
				heads++;
		
		
		System.out.println("The number of heads is " + heads + ".");
		System.out.println("The number of tails is " + (1000000-heads) + ".");
	}

}

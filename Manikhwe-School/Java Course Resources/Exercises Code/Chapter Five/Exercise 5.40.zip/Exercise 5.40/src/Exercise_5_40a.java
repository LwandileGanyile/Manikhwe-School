
public class Exercise_5_40a {
	/* Student B realize that he needs to only 
	keep track of one coin face, either head or tail.*/
	public static void main(String[] args) {
		
		// The total number of tosses.
		int numOfTrials = 1000000;
		
		// The number of heads out of a million toss.
		int numOfHeads = 0;
		// The number of tails out of a million toss.
		int numOfTails = 0;
		
		// The number of tosses made so far.
		int numOfTimes = 1;
		
		while( numOfTimes <= numOfTrials) {
			if((int)(Math.random()*2) == 0) 
				numOfHeads++;
			else
				numOfTails++;
			numOfTimes++;
			
		}
		
		System.out.print("Heads : " 
		+ numOfHeads + "\nTails : " + numOfTails);
		
	}

}

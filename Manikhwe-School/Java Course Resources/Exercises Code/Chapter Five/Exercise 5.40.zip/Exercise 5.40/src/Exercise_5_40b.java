
public class Exercise_5_40b {
	/* Student B realize that he needs to only 
	keep track of one coin face, either head or tail.*/
	public static void main(String[] args) {
		
		final int NUMBER_OF_TRIALS = 1000000;
		
		// The number of heads out of a million toss.
		int numberOfHeads = 0;
		
		// Toss number
		int numberOfTimes = 1;
		
		while( numberOfTimes <= NUMBER_OF_TRIALS) {
			if((int)(Math.random()*2) == 0) 
				numberOfHeads++;
			numberOfTimes++;
			
		}
		
		System.out.println("Out of 1000000 tosses there are " 
		+ numberOfHeads + " heads and " + (NUMBER_OF_TRIALS-numberOfHeads) + " tails.");
	}

}


public class Exercise_5_11a {
	/* Student B realize that a while loop is 
	 * not a good way to go. Furthermore to that 
	 * he realize there is no for the two constants.
	 * The space issue might be neglected for java
	 * programs, however it plays a huge for on other
	 * programming languages like C++.*/
	public static void main(String[] args) {
		
		/* Used to determine whether a number should 
		 * be displayed on the current line or the new one.*/
		int count = 1;
		
		int MINIMUM = 100;
		int MAXIMUM = 200;
		
		int number = MINIMUM;
		
		while(number <= MAXIMUM) {
			if(number%5 == 0 ^ number%6 == 0) {
				
				if(count%10 == 0)
					System.out.print(number + "\n");
				else
					System.out.print(number + " " );
				count++;
			}
			number++;
		}
			
	}

}

import java.util.Scanner;

public class Exercise_5_9b {
	// Student B's solution is inefficient.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompts a user to enter the number of student.
		System.out.print("Enter number of students : ");
		int numberOfStudents = input.nextInt();
		
		// Highest student name.
		String highStudent = null;
		// Highest student score.
		double highScore = Double.MIN_VALUE;
		
		// Current student name.
		String studentName = null;
		// Current student score.
		double studentScore = Double.MIN_VALUE; 
		
		// List of student scores.
		String studentScores = "";
		// List of student names.
		String studentNames = "";
		
		/*************************Deal With Highest Student***************/
		// Process each and every student.
		while(numberOfStudents > 0) {
			System.out.print("Enter a student's name and score : ");
			studentName = input.next();
			studentScore = input.nextDouble();
			
			studentNames += studentName + " ";
			studentScores += studentScore + " ";
			
			if(studentScore < 0) {
				System.out.print("Try again : A mark cannot be negative.");
				System.exit(0);
			}
			
			if(studentName.length() == 0) {
				System.out.print("Try again : A name has to have at least one letter.");
				System.exit(1);
			}
			
			// Compare the current student's score with the current high score.
			if(highScore < studentScore) {
				highStudent = studentName;
				highScore = studentScore;
			}
			
			numberOfStudents--;	
		}
		/*-------------------------Done With Highest Student--------------------*/
		
		String secondHighStudent = null;
		double secondHighScore = Double.MIN_VALUE;
		
		/*************************Deal With The Second Highest Student***************/
		while(studentNames.contains(" ") && studentScores.contains(" ")) {
			// Read the first name of the list of students.
			studentName = studentNames.substring(0,studentNames.indexOf(" "));
			// Read a student score from a list of students and convert it to a double.
			studentScore = Double.parseDouble(studentScores.substring(0,studentScores.indexOf(" ")));

			// Compare the current high performing student with a new student.
			if(studentScore != highScore && secondHighScore < studentScore) {
				secondHighStudent = studentName;
				secondHighScore = studentScore;
			}

			// Remove the first student name of the current list of student names.
			studentNames = studentNames.substring(studentNames.indexOf(" ")+1);
			// Remove the first student score of the current list of student scores.
			studentScores = studentScores.substring(studentScores.indexOf(" ")+1);

		}
				
		// Compare the last student's score with the current student one's score.
		if(highScore < studentScore) {
			highStudent = studentName;
			highScore = studentScore;
		}
		/*-------------------------Done With The Second Highest Student--------------------*/
		
		
		// Display a student name with the high score if one exist.
		if(highStudent != null && highScore != Double.MIN_VALUE &&
		secondHighStudent != null && secondHighScore != Double.MIN_VALUE)
			System.out.print("\nStudent Name : " 
			+ highStudent + "\tHigh Score : " 
			+ highScore + "\nStudent Name : " 
			+ secondHighStudent + "\tSecond High Score : " 
			+ secondHighScore);
		else
			System.out.print("Error : Make sure there is at least one student "
			+ "and students all have both a name and a score.");
		
		
		
		input.close();
	}

}

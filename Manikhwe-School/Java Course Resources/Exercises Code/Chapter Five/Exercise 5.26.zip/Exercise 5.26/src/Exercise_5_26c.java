
public class Exercise_5_26c {
	/* Student A realize that we know the 
	 * number of times both loops will 
	 * execute hence he chose to use for 
	 * loops only.*/
	public static void main(String[] args) {
		
		double e;
		double item;
		
		for(int j = 10000; j <= 100000; j+=10000) {
			e = 1;
			item = 1;
			for(int i = 2; i <= j; i++) {
				item /= i;
				e += item;	
			}
			
			System.out.println("The e approximate for j = " + j + " is " + e);
		}
	}
}

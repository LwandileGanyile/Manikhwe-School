
public class Exercise_5_26a {
	/* Student A doesn't use a hint.*/
	public static void main(String[] args) {
		
		double e;
		
		for(int i = 10000; i <= 100000; i+=10000) {
			e = 0;
			for(int j = 1; j <= i; j++) {
				double dinomenator = 1;
				for(int k = j; k >= 1; k--)
					dinomenator *= k;
				e += 1.0/dinomenator;
			}
			
			System.out.println("The e approximate for j = " + i + " is " + e);
		}
	}
}

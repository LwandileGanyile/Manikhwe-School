
public class Exercise_5_26b {
	/* Student B realize that it better
	 * to use a hint in order to minimize
	 * the time it takes for the application 
	 * to finish displaying.
	 * */
	public static void main(String[] args) {
		
		double e;
		double item;
		
		for(int j = 10000; j <= 100000; j+=10000) {
			e = 1;
			item = 1;
			int i = 2;
			while( i <= j) {
				item /= i;
				e += item;	
				i++;
			}
			
			System.out.println("The e approximate for j = " + j + " is " + e);
		}
	}
}

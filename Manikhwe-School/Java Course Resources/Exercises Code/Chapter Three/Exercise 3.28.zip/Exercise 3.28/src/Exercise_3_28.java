import java.util.Scanner;

public class Exercise_3_28 {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Prompt user to enter second rectangle input.
		System.out.print("Enter r1's center x-, y-coordinates, width, and height:");
		// Store user input to corresponding r1 variables.
		double r1XCoordinate = input.nextDouble();
		double r1YCoordinate = input.nextDouble();
		double r1Width = input.nextDouble();
		double r1Height = input.nextDouble();
		
		// Find r1's area;
		double r1Area = r1Width*r1Height;
		
		// Prompt user to enter first rectangle input.
		// Store user input to corresponding r2 variables.
		System.out.print("Enter r1's center x-, y-coordinates, width, and height:");
		double r2XCoordinate = input.nextDouble();
		double r2YCoordinate = input.nextDouble();
		double r2Width = input.nextDouble();
		double r2Height = input.nextDouble();
		
		// Find r2's area;
		double r2Area = r2Width*r2Height;
		
		// The half of the width of r1.
		double r1WidthHalf = r1Width/2;
		// The half of the height of r1.
		double r1HeightHalf = r1Height/2;
		
		// The half of the width of r2.
		double r2WidthHalf = r2Width/2;
		// The half of the height of r2.
		double r2HeightHalf = r2Height/2;
		
		// Distance between a certain boundary of r2 and a certain boundary of r1.
		double boundaryDeltaX;
		// Distance between a certain boundary of r2 and a certain boundary of r1.
		double boundaryDeltaY;
		
		// More like +x +y on a Cartesian plane if we take r1's center as the origin.
		if(r1XCoordinate < r2XCoordinate && r1YCoordinate < r2YCoordinate) {
				System.out.println("Case : 6");
			if(r1Area != r2Area) {
				
				if((r2XCoordinate + r2WidthHalf) <= (
				r1XCoordinate + r1WidthHalf) && 
				(r2YCoordinate + r2HeightHalf) <= 
				(r1YCoordinate + r1HeightHalf)
				&& r1Area > r2Area) {
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the bottom boundary of r2 and the top boundary of r1.
					boundaryDeltaX = (r2XCoordinate - r2WidthHalf*0.5)-(r1XCoordinate + r1WidthHalf*0.5);
					// Distance between the left boundary of r2 and the right boundary of r1.
					boundaryDeltaY = (r2YCoordinate - r2HeightHalf*0.5) - (r1YCoordinate + r1HeightHalf*0.5);
					
					if(boundaryDeltaX <= 0 && boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
					
			}
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				else if((r2XCoordinate - r2WidthHalf) <= (
				r1XCoordinate + r1WidthHalf) || 
				(r2YCoordinate + r2HeightHalf) <= 
				(r1YCoordinate - r1HeightHalf))
					System.out.print("r2 overlaps r1");
				else
					System.out.print("r2 does not overlap r1");
			}
		}
		// More like +x -y on a Cartesian plane if we take r1's center as the origin.
		else if(r1XCoordinate < r2XCoordinate && r1YCoordinate > r2YCoordinate) {
			System.out.println("Case : 5");
			if(r1Area != r2Area) {
				
				if((r2XCoordinate + r2WidthHalf) <= (
				r1XCoordinate + r1WidthHalf) && 
				(r2YCoordinate - r2HeightHalf) <= 
				(r1YCoordinate - r1HeightHalf)
				&& r1Area > r2Area) {
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the bottom boundary of r1 and the top boundary of r2.
					boundaryDeltaX = (r2XCoordinate - r2WidthHalf*0.5)-(r1XCoordinate + r1WidthHalf*0.5);
					// Distance between the right boundary of r1 and the left boundary of r2.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r2YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaX <= 0 && boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				else {
					// Distance between the bottom boundary of r1 and the top boundary of r2.
					boundaryDeltaX = (r2XCoordinate - r2WidthHalf*0.5)-(r1XCoordinate + r1WidthHalf*0.5);
					// Distance between the right boundary of r1 and the left boundary of r2.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r2YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaX <= 0 && boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
		}
		// More like +x on a Cartesian plane if we take r1's center as the origin.
		else if(r1XCoordinate < r2XCoordinate && r1YCoordinate == r2YCoordinate) {
			System.out.println("Case : 8");
			if(r1Area != r2Area) {
				if((r2XCoordinate + r2WidthHalf) <= 
				(r1XCoordinate + r1WidthHalf) && 
				r1Area > r2Area && r1Height >= r2Height){
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the right boundary of r1 and the left boundary of r2.
					boundaryDeltaX = (r2XCoordinate - r2WidthHalf*0.5)-(r1XCoordinate + r1WidthHalf*0.5);
					
					if(boundaryDeltaX <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				else {
					// Distance between the right boundary of r1 and the left boundary of r2.
					boundaryDeltaX = (r2XCoordinate - r2WidthHalf*0.5)-(r1XCoordinate + r1WidthHalf*0.5);
					
					if(boundaryDeltaX <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
		}
		// More like -x +y on a Cartesian plane if we take r1's center as the origin.
		else if(r1XCoordinate > r2XCoordinate && r1YCoordinate < r2YCoordinate) {
			System.out.println("Case : 4");
			if(r1Area != r2Area) {
				if((r2XCoordinate - r2WidthHalf) >= (
				r1XCoordinate - r1WidthHalf) && 
				(r2YCoordinate + r2HeightHalf) <= 
				(r1YCoordinate + r1HeightHalf)
				&& r1Area > r2Area) {
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the bottom boundary of r2 and the top boundary of r1.
					boundaryDeltaX = (r1XCoordinate - r1WidthHalf*0.5)-(r2XCoordinate + r2WidthHalf*0.5);
					// Distance between the right boundary of r2 and the left boundary of r1.
					boundaryDeltaY = (r2YCoordinate - r2HeightHalf*0.5) - (r1YCoordinate + r1HeightHalf*0.5);
					
					if(boundaryDeltaX <= 0 && boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				else {
					// Distance between the bottom boundary of r2 and the top boundary of r1.
					boundaryDeltaX = (r1XCoordinate - r1WidthHalf*0.5)-(r2XCoordinate + r2WidthHalf*0.5);
					// Distance between the right boundary of r2 and the left boundary of r1.
					boundaryDeltaY = (r2YCoordinate - r2HeightHalf*0.5) - (r1YCoordinate + r1HeightHalf*0.5);
					
					if(boundaryDeltaX <= 0 && boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
				
			}
		}
		// More like -x -y on a Cartesian plane if we take r1's center as the origin.
		else if(r1XCoordinate > r2XCoordinate && r1YCoordinate > r2YCoordinate) {
			System.out.println("Case : 7");
			if(r1Area != r2Area) {
				if((r2XCoordinate - r2WidthHalf) >= (
				r1XCoordinate - r1WidthHalf) && 
				(r2YCoordinate - r2HeightHalf) <= 
				(r1YCoordinate - r1HeightHalf)
				&& r1Area > r2Area) {
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the bottom boundary of r1 and the top boundary of r2.
					boundaryDeltaX = (r1XCoordinate - r1WidthHalf*0.5)-(r2XCoordinate + r2WidthHalf*0.5);
					// Distance between the right boundary of r2 and the left boundary of r1.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r2YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaX <= 0 && boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				else {
					// Distance between the bottom boundary of r1 and the top boundary of r2.
					boundaryDeltaX = (r1XCoordinate - r1WidthHalf*0.5)-(r2XCoordinate + r2WidthHalf*0.5);
					// Distance between the right boundary of r2 and the left boundary of r1.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r2YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaX <= 0 && boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
		}
		// More like -x on a Cartesian plane if we take r1's center as the origin.
		else if(r1XCoordinate > r2XCoordinate && r1YCoordinate == r2YCoordinate) {
			System.out.println("Case : 1");
			if(r1Area != r2Area) {
				if((r2XCoordinate - r2WidthHalf) >= 
				(r1XCoordinate - r1WidthHalf) && 
				r1Area > r2Area && r1Height >= r2Height){
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the left boundary of r1 and the right boundary of r2.
					boundaryDeltaX = (r1XCoordinate - r1WidthHalf*0.5)-(r2XCoordinate + r2WidthHalf*0.5);
					
					if(boundaryDeltaX <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				else {
					// Distance between the left boundary of r1 and the right boundary of r2.
					boundaryDeltaX = (r1XCoordinate - r1WidthHalf*0.5)-(r2XCoordinate + r2WidthHalf*0.5);
					
					if(boundaryDeltaX <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
		}
		// More like -y on a Cartesian plane if we take r1's center as the origin.
		else if(r1XCoordinate == r2XCoordinate && r1YCoordinate > r2YCoordinate) {
			System.out.println("Case : 3");
			if(r1Area != r2Area) {
				
				if((r2YCoordinate - r2HeightHalf) >= 
				(r1YCoordinate - r1HeightHalf) && 
				r1Area > r2Area && r1Width >= r2Width){
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the bottom boundary of r1 and the top boundary of r2.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r1YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
			
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				else {
					// Distance between the bottom boundary of r1 and the top boundary of r2.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r1YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
					
			}
		}
		// More like +y on a Cartesian plane if we take r1's center as the origin.
		else {
			System.out.println("Case : 2");
			if(r1Area != r2Area) {
				if((r2YCoordinate + r2HeightHalf) <= 
				(r1YCoordinate + r1HeightHalf) 
				&& r1Area > r2Area && r1Width >= r2Width){
					System.out.print("r2 is inside r1");
				}
				else {
					// Distance between the top boundary of r1 and the bottom boundary of r2.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r1YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
			else {
				if(r1XCoordinate==r2XCoordinate && r1YCoordinate==r2YCoordinate)
					System.out.print("r2 is inside r1");
				
				else {
					// Distance between the top boundary of r1 and the bottom boundary of r2.
					boundaryDeltaY = (r1YCoordinate + r1HeightHalf*0.5) - (r1YCoordinate + r2HeightHalf*0.5);
					
					if(boundaryDeltaY <= 0)		
						System.out.print("r2 overlaps r1");
					else
						System.out.print("r2 does not overlap r1");
				}
			}
		}
		
		input.close();

	}

}

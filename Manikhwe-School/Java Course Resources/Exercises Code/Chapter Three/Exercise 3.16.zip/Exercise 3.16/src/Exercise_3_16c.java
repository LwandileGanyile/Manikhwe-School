import java.util.Scanner;

public class Exercise_3_16c {

	public static void main(String[] args) {
		
		/* The second student wants a rectangle's width, height and position to be dynamic.
		*/
		
		// Read rectangle's width and height from a user.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts user to enter a rectangle's width and height.
		System.out.print("Enter a rectangle's width and height: ");
		double width = scanner.nextDouble();
		double height = scanner.nextDouble();
		// Prompts user to enter a rectangle's position .
		System.out.print("Enter a rectangle's center (x,y) : ");
		double x = scanner.nextDouble();
		double y = scanner.nextDouble();
		
		if(width>0 && height>0) {

			double xRandom = (Math.random()*width - width*0.5)+x;
			/* First find a random x value that is between 
			 * 0 and  2 times the boundary of a ractangle's height.
			 */
			double yRandom = (Math.random()*height - height*0.5)+y;
			
			System.out.printf("Random point of (x,y) is: (%2.2f,%2.2f)", xRandom,yRandom);
		}
		else
			System.out.printf("Make sure the width and the height are number greater than zero.");
		scanner.close();
	}

}

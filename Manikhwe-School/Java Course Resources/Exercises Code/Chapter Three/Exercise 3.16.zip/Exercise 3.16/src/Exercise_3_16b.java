import java.util.Scanner;

public class Exercise_3_16b {

	public static void main(String[] args) {
		
		/* The second student wants a rectangle's width height to be dynamic.
		*/
		
		// Read rectangle's width and height from a user.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts user to enter a rectangles width.
		System.out.print("Enter a rectangle's width and height: ");
		double width = scanner.nextDouble();
		double height = scanner.nextDouble();
		
		if(width>0 && height>0) {

			double xCoordinate = Math.random()*width - width*0.5;
			/* First find a random x value that is between 
			 * 0 and  2 times the boundary of a ractangle's height.
			 */
			double yCoordinate = Math.random()*height - height*0.5;
			
			System.out.printf("Random point of (x,y) is: (%2.2f,%2.2f)", xCoordinate,yCoordinate);
		}
		else
			System.out.printf("Make sure the width and the height are number greater than zero.");
		scanner.close();
	}

}

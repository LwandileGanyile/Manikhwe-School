
public class Exercise_3_16a {

	public static void main(String[] args) {
		
		/* First find a random y value that is between 
		 0 and 2 times the boundary of a ractangle's width.
		*/
		double xCoordinate = Math.random()*100 - 50;
		/* First find a random x value that is between 
		 * 0 and  2 times the boundary of a ractangle's height.
		 */
		double yCoordinate = Math.random()*200 - 100;
		
		System.out.printf("Random point of (x,y) is: (%2.2f,%2.2f)", xCoordinate,yCoordinate);

	}

}

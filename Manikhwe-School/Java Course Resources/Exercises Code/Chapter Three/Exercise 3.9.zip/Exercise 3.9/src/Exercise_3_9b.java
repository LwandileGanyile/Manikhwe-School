import java.util.Scanner;

public class Exercise_3_9b {

	// Student A did not validate user input.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.		
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter nine digits.
		System.out.print("Enter the first 9 digits of an ISBN as integer: ");
		
		// Store user input into a variable for later use.
		int userInput = input.nextInt();
		
		if(userInput<100000000 && userInput > 9999999) {
		// We need to make sure we have a reference to the original user input.
		// We need this variable because the userInput will be altered later in a program.
		int originalISBN = userInput;
		
		// Stores the 9th digit of user input multiplied by 9.
		int ninethProduct = (userInput%10) * 9;
		// Now userInput is made up of the first eight digits.
		userInput /= 10;
		
		// Stores the 8th digit of user input multiplied by 8.
		int eighthProduct = (userInput%10) * 8;
		// Now userInput is made up of the first seven digits.
		userInput /= 10;
		
		// Stores the 7th digit of user input multiplied by 7.
		int seventhProduct = (userInput%10) * 7;
		// Now userInput is made up of the first six digits.
		userInput /= 10;
		
		// Stores the 6th digit of user input multiplied by 6.
		int sixthProduct = (userInput%10) * 6;
		// Now userInput is made up of the first five digits.
		userInput /= 10;
				
		// Stores the 5th digit of user input multiplied by 5.
		int fifthProduct = (userInput%10) * 5;
		// Now userInput is made up of the first four digits.
		userInput /= 10;
		
		// Stores the 4th digit of user input multiplied by 4.
		int forthProduct = (userInput%10) * 4;
		// Now userInput is made up of the first three digits.
		userInput /= 10;
		
		// Stores the 3rd digit of user input multiplied by 3.
		int thirdProduct = (userInput%10) * 3;
		// Now userInput is made up of the first two digits.
		userInput /= 10;
		
		// Stores the 2nd digit of user input multiplied by 2.
		int secondProduct = (userInput%10) * 2;
	
		// We don't need the product using the first digit because it value is zero.
		
		// The sum of all eight products.
		int sumOfProducts = secondProduct + thirdProduct + forthProduct + fifthProduct
		+ sixthProduct + seventhProduct + eighthProduct + ninethProduct;
		
		// Holds the determiner value between 1 and 10.
		int determiner = sumOfProducts%11;
		
		System.out.print("The ISBN-10 number is 0" + originalISBN);
		
		if(determiner == 10)
			System.out.print("X");
		else
			System.out.print(determiner);
		}
		else 
			System.out.print("Make sure you enter nine digits.");
		// Close scanner
		input.close();
	}

}

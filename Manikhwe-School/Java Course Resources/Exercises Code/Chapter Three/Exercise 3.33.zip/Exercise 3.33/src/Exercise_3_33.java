import java.util.Scanner;

public class Exercise_3_33 {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts a user to enter package1  information.
		System.out.print("Enter weight and price for package 1: ");	
		// Store the weight and price for package 1.
		double packageOneWeight = scanner.nextDouble();
		double packageOnePrice = scanner.nextDouble();
		
		// Prompts a user to enter package2  information.
		System.out.print("Enter weight and price for package 2: ");				
		// Store the weight and price for package 12.
		double packageTwoWeight = scanner.nextDouble();
		double packageTwoPrice = scanner.nextDouble();

		/* This problem is equivalent to comparing two cars' speed 
		 * to see which one is slow given their 
		* distance they traveled and time each car took.
		* So you would say distance divided by time for each car's 
		* average velocity. The car with the smallest average velocity
		* will be the slowest one. */
		// We find the weight per 1 currency
		// The package with a big weight for 1 dollar for example is better.
		double packageOneAnswer = packageOneWeight/packageOnePrice;
		double packageTwoAnswer = packageTwoWeight/packageTwoPrice;
		
		if(packageOneAnswer < packageTwoAnswer)
			System.out.print("Package 2 has a better price.");
		else if(packageOneAnswer > packageTwoAnswer)
			System.out.print("Package 1 has a better price.");
		else
			System.out.print("Two packages have the same price.");
		// Close scanner.
		scanner.close();
	}

}

import java.util.Scanner;

public class Exercise_3_29b {

	// Student one didn't think about the amount of memory that will be taken by his program.
	// Hence he had many variables unnecessarily.
	public static void main(String[] args) {
		
		// Scanner to reader user input.
		Scanner input = new Scanner(System.in);

		// Prompt user to enter position and radius of first circle.
		System.out.print("Enter circle1's center x-, y-coordinates, and radius:");
		
		// Create a variable to hold circle1's x-coordinate.
		double circle1XCoordinate = input.nextDouble();
		
		// Create a variable to hold circle1's y-coordinate.
		double circle1YCoordinate = input.nextDouble();
		
		// Create a variable to hold circle1's radius.
		double circle1Radius = input.nextDouble();
		
		// Prompt user to enter position and radius of second circle.
		System.out.print("Enter circle2's center x-, y-coordinates, and radius:");
		
		// Create a variable to hold circle1's x-coordinate.
		double circle2XCoordinate = input.nextDouble();
		
		// Create a variable to hold circle2's y-coordinate.
		double circle2YCoordinate = input.nextDouble();
		
		// Create a variable to hold circle2's radius.
		double circle2Radius = input.nextDouble();
		
		// Calculate distance between circle1 and circle2.
		// Assign distance between circle1 and circle2 to a variable.
		double distance = Math.sqrt(Math.pow(circle2XCoordinate-circle1XCoordinate,2) + Math.pow(circle2YCoordinate-circle1YCoordinate,2));
		
		// Check whether the relationship between two circles.
		if(distance <= Math.abs(circle1Radius-circle2Radius))
			System.out.print("circle2 is inside circle1");
		else if(distance <= circle1Radius + circle2Radius)
			System.out.print("circle2 overlaps circle1");
		else
			System.out.print("circle2 does not overlap circle1");
		input.close();
	}

}

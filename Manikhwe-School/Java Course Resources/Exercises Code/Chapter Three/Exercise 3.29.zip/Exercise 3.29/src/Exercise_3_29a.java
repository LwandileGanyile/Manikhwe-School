import java.util.Scanner;

public class Exercise_3_29a {
	
	public static void main(String[] args) {
		
		// Scanner to reader user input.
		Scanner input = new Scanner(System.in);

		// Prompt user to enter position and radius of first circle.
		System.out.print("Enter circle1's center x-, y-coordinates, and radius:");
		
		// Create a variable to hold circle1's x-coordinate.
		double circle1XCoordinate = input.nextDouble();
		
		// Create a variable to hold circle1's y-coordinate.
		double circle1YCoordinate = input.nextDouble();
		
		// Create a variable to hold circle1's radius.
		double circle1Radius = input.nextDouble();
		
		// Prompt user to enter position and radius of second circle.
		System.out.print("Enter circle2's center x-, y-coordinates, and radius:");
		
		// Create a variable to hold circle1's x-coordinate.
		double circle2XCoordinate = input.nextDouble();
		
		// Create a variable to hold circle2's y-coordinate.
		double circle2YCoordinate = input.nextDouble();
		
		// Create a variable to hold circle2's radius.
		double circle2Radius = input.nextDouble();
		
		// Calculate distance between circle1 and circle2.
		// Calculate and store (x2-x1) squared.
		double firstPart = Math.pow(circle2XCoordinate-circle1XCoordinate,2);
		
		// Calculate and store (y2-y1) squared.
		double secondPart = Math.pow(circle2YCoordinate-circle1YCoordinate,2);
		
		// Calculate the part inside a square root and store it value;
		double thirdPart = firstPart + secondPart;
		
		// Assign distance between circle1 and circle2 to a variable.
		double distance = Math.sqrt(thirdPart);
		
		// Check whether the second circle is inside the first one.
		double difference = circle1Radius-circle2Radius;
		double sum = circle1Radius + circle2Radius;
		
		if(distance <= Math.abs(difference))
			System.out.print("circle2 is inside circle1");
		else if(distance <= sum)
			System.out.print("circle2 overlaps circle1");
		else
			System.out.print("circle2 does not overlap circle1");
		input.close();
	}

}

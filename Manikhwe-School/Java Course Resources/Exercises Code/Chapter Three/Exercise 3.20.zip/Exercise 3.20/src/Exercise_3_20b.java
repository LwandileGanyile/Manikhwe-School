import java.util.Scanner;

public class Exercise_3_20b {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts a user to enter temperature.
		System.out.print("Enter the temperature in Fahrenheit between -58�F and 41�F: ");

		// Assign user input into a variable.
		double temparatueInFahrenheit = scanner.nextDouble();
			
		if(temparatueInFahrenheit <= 41 && temparatueInFahrenheit>=-58) {
			
			// Prompts a user to enter wind speed.
			System.out.print("Enter the wind speed (>=2) in miles per hour: ");
			// Assign user input into a variable.
			double speedInMilesPerHour = scanner.nextDouble();
		
			if(speedInMilesPerHour >= 2) {
			
				// twc = 35.74 + 0.6215ta - 35.75v0.16 + 0.4275tav0.16
				double windChillTemperature  = 35.74 + 0.6215*temparatueInFahrenheit - 35.75*Math.pow(speedInMilesPerHour, 0.16) + 0.4275*temparatueInFahrenheit*Math.pow(speedInMilesPerHour, 0.16);
				
				// Display wind chill temperature.
				// Use printf to format the output.
				System.out.printf("The wind chill index is %2.5f", windChillTemperature);
			}
			else {
				System.out.println("Error : Make sure the wind speed is greater or equals to 2. ");
				System.exit(1);
			}
		}
		else {
			System.out.println("Error : Make sure the temperature is between -58�F and 41�F. ");
			System.exit(0);
		}
		// Close scanner.
		scanner.close();
	}

}

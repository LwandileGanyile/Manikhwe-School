import java.util.Scanner;

public class Exercise_3_31a {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompt user to enter exchange rate.
		System.out.print("Enter the exchange rate from dollars to RMB: ");
		
		// Store exchange rate.
		double exchangeRate = input.nextDouble();
		
		// Prompt user to enter 0 or 1 .
		System.out.print("Enter 0 to convert dollars to RMB and 1 vice versa: ");
		
		// Store exchange type. Either from dollars to yaun or the other way around.
		int zeroOrOne = input.nextInt();
		
		if(zeroOrOne<= 1 && zeroOrOne>=0)
		{
			// Store the amount to be converted.
			double amount;

			if(zeroOrOne==0) 
				System.out.print("Enter the dollar amount: ");
			else 
				System.out.print("Enter the RMB amount: ");
			
			// Store the amount to be converted in the variable.
			amount = input.nextDouble();
			
			// Store the convert amount in the correct currency.
			double convertedAmount;
			if(zeroOrOne==0) {
				convertedAmount = amount*exchangeRate;
				System.out.print("$" + amount + " is " + convertedAmount + " yuan");
			}
			else {
				convertedAmount = amount/exchangeRate;
				System.out.print(amount + " yuan is $" + convertedAmount);
			}			
			
		}
		else
			System.out.print("Incorrect input");
		
		input.close();
	}

}

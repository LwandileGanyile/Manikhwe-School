import java.util.Scanner;

public class Exercise_3_23 {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Declare the center point variables for later use.
		// We do this so that the program can be dynamic.
		// We want to be able to change the center if we want to later.
		double xCenter = 0;
		double yCenter = 0;
		
		// Declare the weight and height variables for later use.
		// We do this so that the program can be dynamic.
		// We want to be able to change the weight and height if we want to later.
		double weight = 10;
		double height = 5;
		
		// Prompts user to enter a point.
		System.out.print("Enter a point with two coordinates: ");
		
		// Store the x input into a variable;
		double xCoordinate = scanner.nextDouble();
		
		// Store the y input into a variable;
		double yCoordinate = scanner.nextDouble();
		
		// This way of doing it works regardless of the center, weight and the height of a rectangle.
		if(xCoordinate <= xCenter +weight/2 && yCoordinate <= yCenter + height/2)
			System.out.print("Point (" + xCoordinate + "," + yCoordinate + ") is in the rectangle");
		else
			System.out.print("Point (" + xCoordinate + "," + yCoordinate + ") is not in the rectangle");
		
		// close scanner
		scanner.close();
	}

}

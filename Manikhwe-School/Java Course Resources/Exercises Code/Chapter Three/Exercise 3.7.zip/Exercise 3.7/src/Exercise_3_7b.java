import java.util.Scanner;

public class Exercise_3_7b {
	
	// Student B is avoiding the repetition of code.
	public static void main(String[] args) {
		// Create a Scanner
		Scanner input = new Scanner(System.in);
		
		// Receive the amount
		System.out.print(
		"Enter an amount in double, for example 11.56: ");
		double amount = input.nextDouble();
		
		int remainingAmount = (int)(amount * 100);
		
		// Find the number of one dollars
		int numberOfOneDollars = remainingAmount / 100;
		remainingAmount = remainingAmount % 100;
		
		// Find the number of quarters in the remaining amount
		int numberOfQuarters = remainingAmount / 25;
		remainingAmount = remainingAmount % 25;
		
		// Find the number of dimes in the remaining amount
		int numberOfDimes = remainingAmount / 10;
		remainingAmount = remainingAmount % 10;
		
		// Find the number of nickels in the remaining amount
		int numberOfNickels = remainingAmount / 5;
		remainingAmount = remainingAmount % 5;
		
		// Find the number of pennies in the remaining amount
		int numberOfPennies = remainingAmount;
		
		// Display results
		System.out.println("Your amount " + amount + " consists of");
		
		if(numberOfOneDollars != 0) {
			System.out.print(" " + numberOfOneDollars);
			if(numberOfOneDollars > 1)
				System.out.println(" dollars");
			else
				System.out.println(" dollar");
		}
		
		if(numberOfQuarters != 0) {
			System.out.print(" " + numberOfQuarters);
			if(numberOfQuarters > 1)
				System.out.println(" quarters ");
			else
				System.out.println(" quarter ");
		}
		
		if(numberOfDimes != 0) {
			System.out.print(" " + numberOfDimes);
			if(numberOfDimes > 1)
				System.out.println(" dimes");
			else
				System.out.println(" dime");
		}
		
		if(numberOfNickels != 0) {
			System.out.print(" " + numberOfNickels);
			if(numberOfNickels > 1)
				System.out.println(" nickels");
			else
				System.out.println(" nickel");
		}
		
		if(numberOfPennies != 0) {
			System.out.print(" " + numberOfPennies);
			if(numberOfPennies > 1)
				System.out.println(" pennies");
			else
				System.out.println(" penny");
		}
		input.close();
	}
}
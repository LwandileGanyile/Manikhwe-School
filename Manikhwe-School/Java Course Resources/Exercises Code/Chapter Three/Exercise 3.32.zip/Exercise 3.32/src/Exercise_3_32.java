import java.util.Scanner;

public class Exercise_3_32 {

	public static void main(String[] args) {
		
		// Create scanner to read three points.
		Scanner scanner = new Scanner(System.in);

		// Prompts a user to enter three points
		System.out.print("Enter three points for p0, p1, and p2: ");
		
		// Declare and initialize variables for point0.
		double x0 = scanner.nextDouble();
		double y0 = scanner.nextDouble();
		
		// Declare and initialize variables for point1.
		double x1 = scanner.nextDouble();
		double y1 = scanner.nextDouble();
		
		// Declare and initialize variables for point0.
		double x2 = scanner.nextDouble();
		double y2 = scanner.nextDouble();
		
		// (x1 - x0)*(y2 - y0) - (x2 - x0)*(y1 - y0)
		double determinant = (x1 - x0)*(y2 - y0) - (x2 - x0)*(y1 - y0);
		
		if(determinant>0)
			System.out.print("(" + x2 + "," + y2 + ") is on the left side of the line from (" + x0 + "," + y0 + ") to (" + x1 + "," + y1 + ")");
		else if(determinant<0)
			System.out.print("(" + x2 + "," + y2 + ") is on the right side of the line from (" + x0 + "," + y0 + ") to (" + x1 + "," + y1 + ")");
		else
			System.out.print("(" + x2 + "," + y2 + ") is on the line from (" + x0 + "," + y0 + ") to (" + x1 + "," + y1 + ")");
		/*
		 * // The determinant should be zero.
		//And the x coordinate of p2 must be between the x coordinates of p0 and p1.
		//Lastly the y coordinate of p2 must be between the y coordinates of p0 and p1.
		if(determinant==0 && x2 <=x1 && x2>=x0 && y2 <=y1 && y2>=y0)
			System.out.print("(" + x2 + "," + y2 + ") is on the line segment from (" + x0 + "," + y0 + ") to (" + x1 + "," + y1 + ")");
		else
			System.out.print("(" + x2 + "," + y2 + ") is not on the line segment from (" + x0 + "," + y0 + ") to (" + x1 + "," + y1 + ")");
		 * */
		// Close scanner
		scanner.close();
	}

}

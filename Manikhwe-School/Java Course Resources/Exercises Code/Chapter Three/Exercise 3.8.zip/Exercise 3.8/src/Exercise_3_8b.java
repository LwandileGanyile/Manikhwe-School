import java.util.Scanner;

public class Exercise_3_8b {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts user to enter three lottery numbers.
		
		System.out.print("Enter three integers : ");
		int firstNumber = input.nextInt();
		int secondNumber = input.nextInt();
		int thirdNumber = input.nextInt();
		
		// Numbers are in decreasing order.
		if(firstNumber > secondNumber && secondNumber > thirdNumber) {
			
			// Used to determine a number to display first.
			int firstRandomPosition = (int)(Math.random()*3)+1;
			// Used to determine the second number to display;
			int x = (int)(Math.random()*2);
			
			if(firstRandomPosition == 1) 
				System.out.print(firstNumber +" " + thirdNumber + " " +secondNumber);
			
			else if(firstRandomPosition == 2) {
				
				System.out.print(secondNumber +" "); 
				
				if(x == 0)
					System.out.print(firstNumber +" " + thirdNumber);
				else
					System.out.print(thirdNumber +" " + firstNumber);
			}
				
			
			else {
				System.out.print(thirdNumber +" "); 
				
				if(x == 0)
					System.out.print(firstNumber +" " + secondNumber);
				else
					System.out.print(secondNumber +" " + firstNumber);
			}
		}	
		else
			System.out.print(firstNumber +" " + secondNumber + " " +thirdNumber);
		
		input.close();
	}

}

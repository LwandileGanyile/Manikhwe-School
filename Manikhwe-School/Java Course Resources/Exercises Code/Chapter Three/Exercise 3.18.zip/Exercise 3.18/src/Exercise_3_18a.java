import java.util.Scanner;

public class Exercise_3_18a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts the user to enter package weight.
		System.out.print("Enter the weight of the package: ");
		
		double weight = scanner.nextDouble();
		
		
		if( weight <=1 &&  weight>0)
			System.out.print("Cost is " + 3.5 + "$.");
		else if( weight <=3 &&  weight>1)
			System.out.print("Cost is " + 5.5 + "$.");
		else if( weight <=10 &&  weight>3)
			System.out.print("Cost is " + 8.5 + "$.");
		else if( weight <=20 &&  weight>10)
			System.out.print("Cost is " + 10.5 + "$.");
		else if(weight > 50)
			System.out.print("The package cannot be shipped.");
		scanner.close();

	}

}

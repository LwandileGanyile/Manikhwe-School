import java.util.Scanner;

public class Exercise_3_18b {

	// What if a user enters a zero or a package weight less than 50 and greater than 20?
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts the user to enter package weight.
		System.out.print("Enter the weight of the package: ");
		
		double weight = scanner.nextDouble();
		
		if(weight >0) {
			if( weight <=1 &&  weight>0)
				System.out.print("Cost is " + 3.5 + "$.");
			else if( weight <=3 &&  weight>1)
				System.out.print("Cost is " + 5.5 + "$.");
			else if( weight <=10 &&  weight>3)
				System.out.print("Cost is " + 8.5 + "$.");
			else if( weight <=20 &&  weight>10)
				System.out.print("Cost is " + 10.5 + "$.");
			else if(weight > 50)
				System.out.print("The package cannot be shipped.");		
			else
				System.out.println("The program doesn't process package\n "
				+ "weights greater than 20 and less than 50.");
		}
		else
			System.out.println("A package cannot have a weight less than or equalsl to zero.");
		scanner.close();
	}

}

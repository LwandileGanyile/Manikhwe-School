import java.util.Scanner;

public class Exercise_3_14c {
	// Student C's code is more user friendly.
	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Generated coin face.		
		int face = (int)(Math.random()*2);

		// Prompts a user to enter a guess.
		System.out.print("Enter your guess 0-head and 1-tail : ");
		
		// Store user's guess.
		int guess = input.nextInt();
		
		if(guess == 0 || guess == 1) {
			if(face == guess) {
				System.out.print("You're correct : "
				+ "Your guess was " + ((guess==0)?
				"head":"tail") + " and the computer "
				+ "generated " + ((face==0)?"head.":"tail."));
				
			}
			else {
				System.out.print("You're wrong : "
				+ "Your guess was " + ((guess==0)?
				"head":"tail") + " and the computer "
				+ "generated " + ((face==0)?"head.":"tail."));
			}
		}
		else {
			System.out.print("Make sure you enter 0 for head or 1 for tail.");
		}
		// Close scanner
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_3_14b {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner input = new Scanner(System.in);
		
		// Generated coin face.		
		int face = (int)(Math.random()*2);

		// Prompts a user to enter a guess.
		System.out.print("Enter your guess : ");
		
		// Store user's guess.
		int guess = input.nextInt();
		
		if(guess == 0 || guess == 1) {
			if(face == guess)
				System.out.print("Your guess was correct");
			else
				System.out.print("Your guess was incorrect");
		}
		else {
			System.out.print("Make sure you enter 0 for head or 1 for tail.");
		}

		// Close scanner
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_3_21a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts user to enter a year.
		System.out.print("Enter year: (e.g., 2012): ");
		int year = input.nextInt();

		// Prompts user to enter a month.
		System.out.print("Enter month: 1-12: ");
		int m = input.nextInt();
				
		// Prompts user to enter a day of the month.
		System.out.print("Enter the day of the month: 1-31: ");
		int q = input.nextInt();
		
		// Create variables to hold j, k, and the day of the week.
		// The way these variables are calculated is based on the month.
		int j = year/100;
		int k = year%100;
		int h;

		// Deal with January and February.
		if(m == 1 || m == 2) {
			j = (year-1)/100;
			k = (year-1)%100;
			
			if(m==1)
				h = (q + ((26*(13+1))/10) + k + k/4 + j/4 + 5*j)%7;	
			else 
				h = (q + ((26*(14+1))/10) + k + k/4 + j/4 + 5*j)%7;
		}
		else 			
			h = (q + ((26*(m+1))/10) + k + k/4 + j/4 + 5*j)%7;
		System.out.print("Day of the week is ");
		
		switch(h) {
		case 0 :
			System.out.print("Surtaday.");
			break;
		case 1 :
			System.out.print("Sunday.");
			break;
		case 2 :
			System.out.print("Monday.");
			break;
		case 3 :
			System.out.print("Tuesday.");
			break;
		case 4 :
			System.out.print("Wednesday.");
			break;
		case 5 :
			System.out.print("Thursday.");
			break;
		default :
			System.out.print("Friday.");
			break;
		}
		
		// Close scanner
		input.close();
	}
	
}

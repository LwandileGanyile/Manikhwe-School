import java.util.Scanner;

public class Exercise_3_25 {

	public static void main(String[] args) {
		
		// Create scanner to read user input.
		Scanner scanner = new Scanner(System.in);

		// Prompts a user to enter four points.
		System.out.print("Enter x1, y1, x2, y2, x3, y3, x4, y4: ");
		
		// Store point1 on two variables.
		double x1 = scanner.nextDouble();
		double y1 = scanner.nextDouble();
		
		// Store point2 on two variables.
		double x2 = scanner.nextDouble();
		double y2 = scanner.nextDouble();
		
		// Store point3 on two variables.
		double x3 = scanner.nextDouble();
		double y3 = scanner.nextDouble();
				
		// Store point4 on two variables.
		double x4 = scanner.nextDouble();
		double y4 = scanner.nextDouble();
		
		// The following is the same as the first equation in exercise 1.13.
		// (y1 - y2)x - (x1 - x2)y = (y1 - y2)x1 - (x1 - x2)y1
		// a = (y1 - y2), b = (x1 - x2), e = (y1 - y2)x1 - (x1 - x2)y1
		// The following is the same as the second equation in exercise 1.13.
		// (y3 - y4)x - (x3 - x4)y = (y3 - y4)x3 - (x3 - x4)y3
		// c = (y3 - y4), d = (x3 - x4), f = (y3 - y4)x3 - (x3 - x4)y3
		
		// We apply Cramer�s rule to solve for x and y on the given equations.
		// Let rearrange some of the terms of a, b, c, d, e, or f.
		// a = y1-y2, b = x2-x1, c = y3-y4, d = x4 - x3
		// e = x1(y1-y2)+y1(x2-x1), f = x3(y3-y4)+y3(x4-x3)
		
		// Declare and initialize a, b, c, d, e and f.
		double a = y1-y2;
		double b = x2-x1;
		double c = y3-y4;
		double d = x4 - x3;
		double e = x1*(y1-y2)+y1*(x2-x1);
		double f = x3*(y3-y4)+y3*(x4-x3);
		
		double denominator = a*d - b*c;
		
		if(denominator==0) {
			System.out.print("The two lines are parallel");
		}
		
		else {
			
			double x = (e*d - b*f)/denominator;
			double y = (a*f - e*c)/denominator;
			
			System.out.printf("The intersecting point is (%2.5f,%2.4f)", x, y);
		}
		
		// Close scanner
		scanner.close();
	}

}

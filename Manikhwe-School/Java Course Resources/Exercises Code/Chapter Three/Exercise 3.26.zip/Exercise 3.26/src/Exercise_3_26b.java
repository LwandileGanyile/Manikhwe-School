import java.util.Scanner;

public class Exercise_3_26b {

	// Student B realize that there is no need of a bunch of if/else statements.
	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter an integer to check.
		System.out.print("Enter an integer: ");
		
		// Store user input for later use.
		int userNumber = input.nextInt();
		
		// You can write the following in different ways.
		System.out.println("Is " + userNumber + " divisible by 5 and 6? " + (userNumber%5==0 && userNumber%6==0));
		System.out.println("Is " + userNumber + " divisible by 5 or 6? " + (userNumber%5==0 || userNumber%6==0));
		System.out.println("Is " + userNumber + " divisible by 5 or 6, but not both? " + (userNumber%5==0 ^ userNumber%6==0));
		input.close();
	}

}

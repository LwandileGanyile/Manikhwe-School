import java.util.Scanner;

public class Exercise_3_26a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Prompts a user to enter an integer to check.
		System.out.print("Enter an integer: ");
		
		// Store user input for later use.
		int userNumber = input.nextInt();
		
		
		// Check whether a number is divisible by either 5 or 6.
		// You can write the following in different ways.
		// userNumber%5==0 && userNumber%6==0
		if(userNumber%5!=0 || userNumber%6!=0) 
			System.out.println("Is " + userNumber + " divisible by 5 and 6? false");
		else
			System.out.println("Is " + userNumber + " divisible by 5 and 6? true");
		
		// Check whether a number is divisible by either 5 or 6.
		if(userNumber%5==0 || userNumber%6==0) 
			System.out.println("Is " + userNumber + " divisible by 5 or 6? true");
		else
			System.out.println("Is " + userNumber + " divisible by 5 or 6? false");
			
		// Check whether a number is divisible by exactly one number either 5 or 6 but not both.
		if(userNumber%5==0 ^ userNumber%6==0) 
			System.out.println("Is " + userNumber + " divisible by 5 or 6, but not both? true");
		else
			System.out.println("Is " + userNumber + " divisible by 5 or 6, but not both? false");
		
		input.close();
	}

}

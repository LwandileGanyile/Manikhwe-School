
/* Student C realize that it's better to use a 
 * variable instead of different values on the 
 * print statements. Suppose one had many cases,
 * if values are used rather than a single variable
 * a logical error might arise due to an incorrect value
 * put on a certain case. So a variable is independent of
 * the case, that is why is is better that different values.
 * Student C also realize that the output has to be informative.
 * */

public class Exercise_3_4c {

	public static void main(String[] args) {
		
		// A value between 0 and 11 is generated.
		int randomNumber = (int)(Math.random()*12);

		System.out.print("Random number : ");
		
		// Uses post increment.
		switch(++randomNumber) {
		case 1 :
			System.out.print(randomNumber + " Corresponding Month : January");
			break;
		case 2 :
			System.out.print(randomNumber + " Corresponding Month : February");
			break;
		case 3 :
			System.out.print(randomNumber + " Corresponding Month : March");
			break;
		case 4 :
			System.out.print(randomNumber + " Corresponding Month : April");
			break;
		case 5 :
			System.out.print(randomNumber + " Corresponding Month : May");
			break;
		case 6 :
			System.out.print(randomNumber + " Corresponding Month : June");
			break;
		case 7 :
			System.out.print(randomNumber + " Corresponding Month : July");
			break;
		case 8 :
			System.out.print(randomNumber + " Corresponding Month : August");
			break;
		case 9 :
			System.out.print(randomNumber + " Corresponding Month : September");
			break;
		case 10 :
			System.out.print(randomNumber + " Corresponding Month : October");
			break;
		case 11 :
			System.out.print(randomNumber + " Corresponding Month : November");
			break;
		default :
			System.out.print(randomNumber + " Corresponding Month : December");
			break;
		}
	}

}

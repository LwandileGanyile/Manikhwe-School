import java.util.Scanner;

public class Exercise_3_19b {

	// Student B realized that student A used many variables.
	public static void main(String[] args) {
		
		// Create scanner
		Scanner input = new Scanner(System.in);

		// Prompts user to enter first point of the triangle.
		System.out.print("Enter the first point(x and y) of a triangle : ");
		
		double x1 = input.nextDouble();
		double y1 = input.nextDouble();
		
		// Prompts user to enter second point of the triangle.
		System.out.print("Enter the second point(x and y) of a triangle : ");
				
		double x2 = input.nextDouble();
		double y2 = input.nextDouble();
		
		// Prompts user to enter third point of the triangle.
		System.out.print("Enter the third point(x and y) of a triangle : ");
						
		double x3 = input.nextDouble();
		double y3 = input.nextDouble();
		
		// Calculate what is inside the square root of the distance formula.
		// Calculate (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1)
		double withinSquareRoot1 = (Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2));
		// Calculate distance from first point to second point.
		double distance12 = Math.sqrt(withinSquareRoot1);
		
		// Calculate what is inside the square root of the distance formula.
		// Calculate (x3-x1)*(x3-x1) + (y3-y1)*(y3-y1)
		double withinSquareRoot2 = (Math.pow(x3-x1, 2) + Math.pow(y3-y1, 2));
		// Calculate distance from first point to third point.
		double distance13 = Math.sqrt(withinSquareRoot2);
		
		// Calculate what is inside the square root of the distance formula.
		// Calculate (x3-x2)*(x3-x2) + (y3-y2)*(y3-y2)
		double withinSquareRoot3 = (Math.pow(x3-x2, 2) + Math.pow(y3-y2, 2));
		// Calculate distance from second point to third point.
		double distance23 = Math.sqrt(withinSquareRoot3);
		
		if((distance12 + distance13 > distance23) &&
		(distance12 + distance23 > distance13) &&
		(distance23 + distance13 > distance12)) 
			System.out.printf("The perimeter of the triangle is %4.2f.", (distance12 + distance13 + distance23));
		else
			System.out.print("Make sure you enter valid points making up a triangle.");
		
		input.close();
	}

}

import java.util.Scanner;

/* Student C realize that there is no need to to 
 * have variable(s) holding root values because 
 * they are only used once.
 */
public class Exercise_3_1c {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Declare variables to hold a,b and c.
		// A different way of declaring variables of similar tyoe.
		double a,b,c;
		
		// Prompt a user to enter a, b, and c.
		System.out.print("Enter a, b, c:");
		
		// Initialize a, b, and c with user input.
		a = input.nextDouble();
		b = input.nextDouble();
		c = input.nextDouble();
		
		// Calculate the discriminant
		double discriminant = b*b - 4*a*c;
		System.out.print("The equation has ");
		
		if(discriminant>0) {		
		
			System.out.printf("two roots %2.6f and %2.5f",
			(-b + Math.pow(discriminant, 0.5))/(2*a), 
			(-b - Math.pow(discriminant, 0.5))/(2*a));
		}
		else if(discriminant == 0) 
			System.out.printf("one  root %2.5f", (-b)/(2*a));
		else {
			System.out.print("no real roots. ");
		}
			
		input.close();
	}

}

import java.util.Scanner;

public class Exercise_3_1a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner input = new Scanner(System.in);

		// Declare variables to hold a,b and c.
		double a;
		double b;
		double c;
		
		// Prompt a user to enter a, b, and c.
		System.out.print("Enter a, b, c:");
		
		// Initialize a, b, and c with user input.
		a = input.nextDouble();
		b = input.nextDouble();
		c = input.nextDouble();
		
		// Calculate the discriminant
		double discriminant = b*b - 4*a*c;
		
		if(discriminant>0) {		
			// Find two roots.
			double firstRoot = (-b + Math.pow(discriminant, 0.5))/(2*a);
			double secondRoot = (-b - Math.pow(discriminant, 0.5))/(2*a);
		
			System.out.printf("The equation has two roots %2.6f and %2.5f",firstRoot, secondRoot);
		}
		else if(discriminant == 0) {
			double root = (-b + Math.pow(discriminant, 0.5))/(2*a);
			System.out.printf("The equation has one  root %2.4f", root);
		}
		else {
			System.out.print("The equation has no real roots. ");
		}
			
		input.close();
	}

}

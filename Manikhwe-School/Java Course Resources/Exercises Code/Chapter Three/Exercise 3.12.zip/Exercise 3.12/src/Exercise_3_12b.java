import java.util.Scanner;

public class Exercise_3_12b {
	// Student one did not validate user input.
	public static void main(String[] args) {
		// Read user input
		
		Scanner scanner = new Scanner(System.in);

		// Prompts user to enter a 3 digit number.
		System.out.print("Enter a 3 digit number.");
		
		int number = scanner.nextInt();
		int originalNumber = number;
		
		// Retrieve last digit of number.
		int lastDigit = number%10;
		// Replace number with its first four digit.
		number /= 100;
		
		// Number is now first number.
		int firstDigit = number;
		
		if(firstDigit>=10)
			System.out.print("Try again, make sure you enter three digit.");
		else {
		
			if(firstDigit==lastDigit) 
				System.out.print(originalNumber + " is a palindrome");
			else
				System.out.print(originalNumber + " is not a palindrome");
		}
		scanner.close();
	}

}

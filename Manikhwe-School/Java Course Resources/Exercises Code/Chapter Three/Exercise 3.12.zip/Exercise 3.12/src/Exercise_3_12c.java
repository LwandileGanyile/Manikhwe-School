import java.util.Scanner;

public class Exercise_3_12c {

	// Student three is using five digits instead of three.
	public static void main(String[] args) {
		
		// Read user input
		Scanner scanner = new Scanner(System.in);

		// Prompts user to enter a 3 digit number.
		System.out.print("Enter a 3 digit number.");
		
		int number = scanner.nextInt();
		int originalNumber = number;
		
		// Retrieve last digit of number.
		int lastDigit = number%10;
		// Replace number with its first four digit.
		number /= 10;
		
		// Retrieve last digit of current number.
		int forthDigit = number%10;
		// Replace current number with its first three digit.
		number /= 100;
		
		// Retrieve last digit of current number.
		int secondDigit = number%10;
		// Replace number with its first digit.
		number /= 10;
		
		// Number is now first number.
		int firstDigit = number;
		
		if(firstDigit>=10)
			System.out.print("Try again, make sure you enter five digit.");
		else {
			if(firstDigit==lastDigit && secondDigit==forthDigit) 
				System.out.print(originalNumber + " is a palindrome");
			else
				System.out.print(originalNumber + " is not a palindrome");
		}
		scanner.close();
	}

}

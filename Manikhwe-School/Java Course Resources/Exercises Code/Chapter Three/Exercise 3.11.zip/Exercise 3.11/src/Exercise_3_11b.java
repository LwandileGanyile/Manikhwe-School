import java.util.Scanner;

public class Exercise_3_11b {
	// Stent B replaces a bunch of if else statements with the switch statement.
	public static void main(String[] args) {
		
		//Create scanner
		Scanner input = new Scanner(System.in);

		// Prompts user to enter month and the year.
		System.out.print("Enter month and a year : ");
		int month = input.nextInt();
		int year = input.nextInt();
		
		if(month > 0 && month < 13 && year > 0) {
				
			switch(month) {
			case 1 : 
				System.out.print("January " + year + " had " + 31 + " days.");
				break;
			case 2 : 
				boolean isLeapYear = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);			
				System.out.print("February " + year + " had " + ((isLeapYear)?29:28) + " days.");
				break;
			case 3 : 
				System.out.print("March " + year + " had " + 31 + " days.");
				break;
			case 4 : 
				System.out.print("April " + year + " had " + 30 + " days.");
				break;
			case 5 : 
				System.out.print("May " + year + " had " + 31 + " days.");
				break;
			case 6 : 
				System.out.print("June " + year + " had " + 30 + " days.");
				break;
			case 7 : 
				System.out.print("July " + year + " had " + 31 + " days.");
				break;
			case 8 : 
				System.out.print("August " + year + " had " + 31 + " days.");
				break;
			case 9 : 
				System.out.print("September " + year + " had " + 30 + " days.");
				break;
			case 10 : 
				System.out.print("October " + year + " had " + 31 + " days.");
				break;
			case 11 : 
				System.out.print("November " + year + " had " + 30 + " days.");
				break;
			default : 
				System.out.print("December " + year + " had " + 31 + " days.");
				break;
			}
		}
		
		input.close();
	}

}

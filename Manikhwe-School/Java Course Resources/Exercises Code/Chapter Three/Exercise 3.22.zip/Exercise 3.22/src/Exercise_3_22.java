import java.util.Scanner;

public class Exercise_3_22 {

	public static void main(String[] agrs) {
		
		// Create scanner to read user input.
		Scanner scanner = new Scanner(System.in);
				
		// Declare the center point variables for later use.
		// We do this so that the program can be dynamic.
		// We want to be able to change the center if we want to later.
		double xCenter = 0;
		double yCenter = 0;
				
		// Declare the radius variable  for later use.
		// We do this so that the program can be dynamic.
		// We want to be able to change the radius if we want to later.
		double radius = 10;
				
		// Prompts user to enter a point.
		System.out.print("Enter a point with two coordinates: ");
				
		// Store the x input into a variable;
		double xCoordinate = scanner.nextDouble();
				
		// Store the y input into a variable;
		double yCoordinate = scanner.nextDouble();
				
		/* Calculate the distance between the center an the point entered 
		by a user*/
				
		double distance = Math.sqrt(Math.pow(xCoordinate-xCenter, 2)+Math.pow(yCoordinate-yCenter, 2));
				
		/* This way of doing it works regardless of the center, weight and the 
		height of a rectangle.*/
		if(distance <= radius)
			System.out.print("Point (" + xCoordinate + "," + yCoordinate + ") is in the circle");
		else
			System.out.print("Point (" + xCoordinate + "," + yCoordinate + ") is not in the circular");
				
		// close scanner
		scanner.close();
	}
}

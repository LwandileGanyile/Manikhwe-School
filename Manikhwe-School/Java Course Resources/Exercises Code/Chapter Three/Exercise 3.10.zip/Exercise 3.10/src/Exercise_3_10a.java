import java.util.Scanner;

public class Exercise_3_10a {

	public static void main(String[] args) {
		
		// Create scanner to read user input
		Scanner input = new Scanner(System.in);

		int number1 = (int)(Math.random()*100);
		int number2 = (int)(Math.random()*100);
		int correctAnswer = number1 + number2;
		
		// Prompt user to enter first number.
		System.out.print("What is " + number1 + " + " + number2 + " ? ");
		int studentAnswer = input.nextInt();
		
		
		if(correctAnswer == studentAnswer)
			System.out.print("You are correct!");
		else {
			System.out.println("Your answer is wrong");
			System.out.print(number1 + " + " + number2 + " is " + correctAnswer);
		}
		
		input.close();
	}

}

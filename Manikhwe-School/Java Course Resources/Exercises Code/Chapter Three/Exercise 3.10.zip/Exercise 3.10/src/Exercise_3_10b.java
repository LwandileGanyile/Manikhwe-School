import java.util.Scanner;

public class Exercise_3_10b {

	// Student B realize there is no need to have a variable holding the correct answer.
	public static void main(String[] args) {
		
		// Create scanner to read user input
		Scanner input = new Scanner(System.in);

		int number1 = (int)(Math.random()*100);
		int number2 = (int)(Math.random()*100);
		
		// Prompt user to enter first number.
		System.out.print("What is " + number1 + " + " + number2 + " ? ");
		int studentAnswer = input.nextInt();
		
		if((number1 + number2) == studentAnswer)
			System.out.print("You are correct!");
		else {
			System.out.println("Your answer is wrong");
			System.out.print(number1 + " + " + number2 + " is " + (number1 + number2));
		}
		
		input.close();
	}

}

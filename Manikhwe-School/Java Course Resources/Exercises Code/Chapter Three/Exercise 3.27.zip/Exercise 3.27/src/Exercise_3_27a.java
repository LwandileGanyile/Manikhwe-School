import java.util.Scanner;

public class Exercise_3_27a {

	public static void main(String[] args) {
		
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Prompts a user to enter a point.
		System.out.print("Enter a point's x- and y-coordinates: ");
		
		// Store the x-coordinate in a variable
		double xCoordinate = scanner.nextDouble();
		
		// Store the y-coordinate in a variable
		double yCoordinate = scanner.nextDouble();
		
		// Determines whether the point is inside or not.
		boolean isPointInside = true;
		
		/* Check the x-coordinate of the input  
		 * whether or not it is on the right angle triangle.
		 */
		if( xCoordinate > 200 || xCoordinate < 0) 
			isPointInside = false;
		
		/* Execute the following code if the xCoordinate of the input 
		 * is on the right angle triangle.
		 */
		if(isPointInside) 	
			/* Check the x-coordinate of the input  
			 * whether or not it is on the right angle triangle.
			 */
			if(((yCoordinate > 100) || (yCoordinate < 0)))
				isPointInside = false;
	
		// Now we have determined whether or not a point is within the rectangle.
		/* Now we will use the formula (x1 - x0)*(y2 - y0) - (x2 - x0)*(y1 - y0) 
		 * to determine on which side of the line from first point to second point is the point.
		 * This will let us know whether or not a point is within the right angle triangle.
		 */
		if(isPointInside) {
			
			double determinant = (200-0)*(yCoordinate - 100)
					-((xCoordinate - 0)*(0-100));
			
			/* The y coordinate of the first point is greater than the y coordinate of the second point.
			* Because the direction is from first point to second point.
			* This implies we must change the inequality signs on the equation.*/
			if(determinant > 0) isPointInside = false;

		}
		
		
		if(isPointInside)
			System.out.print("The point is in the triangle.");
		else
			System.out.print("The point is not in the triangle.");
		
		// Close scanner
		scanner.close();
	}

}

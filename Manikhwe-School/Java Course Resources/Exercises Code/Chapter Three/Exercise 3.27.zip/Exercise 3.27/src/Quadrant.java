
public enum Quadrant {

	First_Quadrant,
	Second_Quadrant,
	Third_Quadrant,
	Forth_Quadrant
	
}

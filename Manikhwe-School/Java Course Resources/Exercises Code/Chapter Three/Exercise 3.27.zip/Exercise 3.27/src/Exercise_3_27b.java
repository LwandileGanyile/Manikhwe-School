import java.util.Scanner;

public class Exercise_3_27b {

	public static void main(String[] args) {
		
		// This is a more dynamic the the first right angle triangle.
		/* 
		 */
		/* Now you can you can reflect the original one about 
		 * the x-axis, y-axis, and the line y= x.
		 */
		// Create a scanner to read user input.
		Scanner scanner = new Scanner(System.in);
		
		// Declare and initialize position of the first point in a rectangle.
		// We do this because the position might change in future.
		// By doing this our right angle triangle will be flexible.
		double firstPointXCoordinate = 0;
		double firstPointYCoordinate  = -100;
		
		// Declare and initialize position of the second point in a rectangle.
		// We do this because the position might change in future.
		// By doing this our right angle triangle will be flexible.
		double secondPointXCoordinate = -200;
		double secondPointYCoordinate = 0;
		
		// Enums works the same as other data types.
		/* They are used if you want to have a finite number of values.
		// We could use integers, however thats not a good idea because 
		 * we only want four different values.*/
		
		// The quadrant the right angle triangle is on.
		Quadrant quadrant;
		
		// Determine on which quadrant is the right angle triangle located.
		if(secondPointXCoordinate > 0 && 
		firstPointYCoordinate > 0) {
		
			quadrant = Quadrant.First_Quadrant;
			//System.out.println("Rectangle triangle in First_Quadrant");
		}
		else if(secondPointXCoordinate < 0 && 
		firstPointYCoordinate > 0) {
			quadrant = Quadrant.Second_Quadrant;
			//System.out.println("Rectangle triangle in Second_Quadrant");
		}
		else if(secondPointXCoordinate < 0 && 
		firstPointYCoordinate < 0) {
			quadrant = Quadrant.Third_Quadrant;
			//System.out.println("Rectangle triangle in Third_Quadrant");
		}
		else {
			quadrant = Quadrant.Forth_Quadrant;
			//System.out.println("Rectangle triangle in Forth_Quadrant");
		}
		
		// Prompts a user to enter a point.
		System.out.print("Enter a point's x- and y-coordinates: ");
		
		// Store the x-coordinate in a variable
		double xCoordinate = scanner.nextDouble();
		
		// Store the y-coordinate in a variable
		double yCoordinate = scanner.nextDouble();
		
		// Determines whether the point is inside or not.
		boolean isPointInside = true;
		
		/* Check the x-coordinate of the input in the first and forth 
		 * quadrants whether or not it is on the right angle triangle.
		 */
		if((quadrant == Quadrant.First_Quadrant || 
		quadrant == Quadrant.Forth_Quadrant) && 
		(xCoordinate > secondPointXCoordinate || 
		xCoordinate < 0)) 
			isPointInside = false;
		
		/* Check the x-coordinate of the input in the second and third 
		 * quadrants whether or not it is on the right angle triangle.
		 */
		else if((quadrant == Quadrant.Second_Quadrant || 
		quadrant == Quadrant.Third_Quadrant) && 
		(xCoordinate < secondPointXCoordinate || 
		xCoordinate > 0))
			isPointInside = false;
		
		/* Execute the following code if the xCoordinate of the input 
		 * is on the right angle triangle.
		 */
		if(isPointInside) 	
			/* Check the y-coordinate of the input in the first and second 
			 * quadrants whether or not it is on the right angle triangle.
			 */
			if((quadrant == Quadrant.First_Quadrant || quadrant == 
			Quadrant.Second_Quadrant) && ((yCoordinate > 
			firstPointYCoordinate) || (yCoordinate < 0)))
				isPointInside = false;
		/* Check the y-coordinate of the input in the third and forth 
		 * quadrants whether or not it is on the right angle triangle.
		 */
			else if((quadrant == Quadrant.Third_Quadrant || quadrant == 
			Quadrant.Forth_Quadrant) && ((yCoordinate < 
			firstPointYCoordinate) || (yCoordinate > 0)))
				isPointInside = false;
		
		
		// Now we have determined whether or not a point is within the rectangle.
		/* Now we will use the formula (x1 - x0)*(y2 - y0) - (x2 - x0)*(y1 - y0) 
		 * to determine on which side of the line from first point to second point is the point.
		 * This will let us know whether or not a point is within the right angle triangle.
		 */
		if(isPointInside) {
			
			double determinant = (secondPointXCoordinate-firstPointXCoordinate)*(yCoordinate - firstPointYCoordinate)
					-((xCoordinate - firstPointXCoordinate)*(secondPointYCoordinate-firstPointYCoordinate));
			
			/* The y coordinate of the first point is greater than the y coordinate of the second point.
			* Because the direction is from first point to second point.
			* This implies we must change the inequality signs on the equation.*/
			if(quadrant == Quadrant.First_Quadrant) {
				if(determinant > 0) isPointInside = false;
			}
			
			/* The y coordinate of the first point is greater than the y coordinate of the second point.
			* Because the direction is from first point to second point.
			* This implies we must change the inequality signs on the equation.*/
			else if(quadrant == Quadrant.Second_Quadrant) {
				if(determinant < 0) isPointInside = false;
			}
			
			/* The y coordinate of the first point is smaller than the y coordinate of the second point.
			* Because the direction is from first point to second point.
			* This implies we must not change the inequality signs on the equation.*/ 
			else if(quadrant == Quadrant.Third_Quadrant) {
				if(determinant > 0) isPointInside = false;
			}
			
			/* The y coordinate of the first point is smaller than the y coordinate of the second point.
			* Because the direction is from first point to second point.
			* This implies we must not change the inequality signs on the equation.*/
			else {
				if(determinant < 0) isPointInside = false;
			}
		}
		
		
		if(isPointInside)
			System.out.print("The point is in the triangle.");
		else
			System.out.print("The point is not in the triangle.");
		
		// Close scanner
		scanner.close();
	}

}

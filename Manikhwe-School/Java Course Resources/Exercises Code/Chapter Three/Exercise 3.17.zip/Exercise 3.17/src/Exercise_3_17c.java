import java.util.Scanner;

public class Exercise_3_17c {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		// Declare and initialize a computers choice.
		/* The third student realized that you can group 
		 * certain conditions together to avoid a lot of 
		 * printing statements.
		*/
		int computerChoice = (int)(Math.random()*3);
		
		System.out.print("scissor (0), rock (1), paper (2): ");
		// Prompt user to enter his choice.
		int userChoice = scanner.nextInt();
		
		if(userChoice == 0 || userChoice == 1 || userChoice == 2) {
			
			if(computerChoice == 0) {
				System.out.print("The computer is scissor. You are ");
				if(userChoice==0) {
					System.out.print("sissor too. ");
				}
				else if(userChoice == 1) {
					System.out.print("rock. ");
				}
				else {
					System.out.print("papper. ");
				}
			}
			else if(computerChoice == 1) {
				System.out.println("The computer is rock. You are ");
				if(userChoice==0) {
					System.out.print("sissor. ");
				}
				else if(userChoice == 1) {
					System.out.print("rock too. ");
				}
				else {
					System.out.print("papper. ");
				}
			}
			else {
				System.out.print("The computer is paper. You are ");
				if(userChoice==0) {
					System.out.print("sissor. ");
				}
				else if(userChoice == 1) {
					System.out.print("rock. ");
				}
				else {
					System.out.print("papper too. ");
				}
			}
			
			if(userChoice==computerChoice)
				System.out.print("It is a draw");
			else if((computerChoice==0 && userChoice == 2) 
			|| (computerChoice==1 && userChoice == 0)
			|| (computerChoice==2 && userChoice == 1))
				System.out.print("You lost");
			else {
				System.out.print("You won");
			}
		}
		else {
			System.out.println("Try again, make sure this time you enter 0, 1 or 2.");
		}
		scanner.close();
	}

}

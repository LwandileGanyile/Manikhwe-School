import java.util.Scanner;

public class Exercise_3_17a {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		// Declare and initialize a computers choice.
		// Math.random gives a number between 0.0 and 1.0.
		// Now we will have a number between 0.0 and 3.0 excluding 3.0.
		// Suppose we got 2.8, the 2.8 is then casted to an integer to obtain 2.
		int computerChoice = (int)(Math.random()*3);
		
		System.out.print("scissor (0), rock (1), paper (2): ");
		// Prompt user to enter his choice.
		int userChoice = scanner.nextInt();
		
		// Scissor
		if(userChoice==0) {
			// Scissor
			if(computerChoice == 0) {
				System.out.println("The computer is scissor. You are scissor too. It is a draw");
				
			}
			// Rock
			else if(computerChoice == 1) {
				System.out.println("The computer is scissor. You are rock. You won");
			}
			else {
				System.out.println("The computer is scissor. You are paper. You lost");
			}
		}
		// Rock
		else if(userChoice==1) {
			if(computerChoice == 0) {
				System.out.println("The computer is rock. You are scissor. You lost");
			}
			else if(computerChoice == 1) {
				System.out.println("The computer is rock. You are rock too. It is a draw");
			}
			else {
				System.out.println("The computer is rock. You are paper. You won");
			}
		}
		// Paper
		else {
			if(computerChoice == 0) {
				System.out.println("The computer is paper. You are scissor. You won");
			}
			else if(computerChoice == 1) {
				System.out.println("The computer is paper. You are rock. You lost");
			}
			else {
				System.out.println("The computer is paper. You are papper too. It is a draw");
			}
		}
		
		scanner.close();
	}

}

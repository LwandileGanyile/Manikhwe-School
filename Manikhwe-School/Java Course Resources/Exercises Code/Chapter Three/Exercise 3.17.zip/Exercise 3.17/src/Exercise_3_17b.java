import java.util.Scanner;

public class Exercise_3_17b {

	// Second student realize that the user input has to be validated.
	// Second student also realize that a variable to track an answer will be useful.
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		// Declare and initialize a computers choice.
		int computerChoice = (int)(Math.random()*3);
		
		System.out.print("scissor (0), rock (1), paper (2): ");
		// Prompt user to enter his choice.
		int userChoice = scanner.nextInt();
		
		if(userChoice == 0 || userChoice == 1 || userChoice == 2) {
			// Scissor
			if(userChoice==0) {
				// Scissor
				if(computerChoice == 0) {
					System.out.println("The computer is scissor. You are scissor too. It is a draw");
					
				}
				// Rock
				else if(computerChoice == 1) {
					System.out.println("The computer is scissor. You are rock. You won");
				}
				else {
					System.out.println("The computer is scissor. You are paper. You lost");
				}
			}
			// Rock
			else if(userChoice==1) {
				if(computerChoice == 0) {
					System.out.println("The computer is rock. You are scissor. You lost");
				}
				else if(computerChoice == 1) {
					System.out.println("The computer is rock. You are rock too. It is a draw");
				}
				else {
					System.out.println("The computer is rock. You are paper. You won");
				}
			}
			// Paper
			else {
				if(computerChoice == 0) {
					System.out.println("The computer is paper. You are scissor. You won");
				}
				else if(computerChoice == 1) {
					System.out.println("The computer is paper. You are rock. You lost");
				}
				else {
					System.out.println("The computer is paper. You are papper too. It is a draw");
				}
			}
		}
		else {
			System.out.println("Try again, make sure this time you enter 0, 1 or 2.");
		}
		scanner.close();
	}

}
